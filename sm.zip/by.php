<?php
include "header.php";?>
<link rel="stylesheet" href="assets/css/main.css" />
<section id="contact" class="main style3 secondary">
	<div class="content">
<div class="box">
								<header>
									<title>О нас</title>
						<h2><font color="green">О нас</font></h2>
					</header>
					<p><font color="green">BUSINESS LIFE</font>-компания зарегистрировано в 2010 году.	<br />
						все права защишены, все схожие компаний, сайты, <br />иные обьекты является совпадением или подделанным<br />
						и не имеет никакого отношение к <font color="green">BUSINESS LIFE</font> и  <font color="green">DEPOSIT LIFE</font>.<br /> 
						Дочерная компания <font color="green">DEPOSIT LIFE</font> это акций  <font color="green">BUSINESS LIFE</font><br />
						<font color="green">DEPOSIT LIFE</font> - специальный, автоматизированный и совершенный <br />
						алгоритм для физических лиц - инвесторов.<br />
						<hr />
						<font size=2 color = 999999 face="times new roman">Подробную информацию вы можете найти на <a href="index.html">Главной странице</a> сайта.</font>
						<br />
	<br />
	<br />
	
		
					</p>
				
	</div></div>
	
				<a href="/index.html" class="button style2 down anchored">Next</a>
			</section>

			<?php include "foter.php";?>