﻿<?php include "header.php";?>
<link rel="stylesheet" href="assets/css/main.css" />
<section id="contact" class="main style3 secondary">
				<div class="content">
					<header>
						<h2><font color=green>Обратная связь</font></h2>
						<p>Уважаемый посетитель сайта, Мы благодарны Вам за то что 
						посетили Наш сайт и с радостю ответим ко всем интересующим 
						вопросам, отправьте Нам сообщение через форму "Обратная связь". 
						А также Вы можете оставить отзывы о программе <font color="green"><b>DEPOSIT LIFE</b></font> 
					</header>
					<div class="box">
						<form method="post" action="../send_support.php">
							<div class="field half first"><input type="text" name="name" placeholder="ФИО" /></div>
							<div class="field half"><input type="email" name="email" placeholder="Email" /></div>
							<div class="field"><textarea name="message" placeholder="Сообщение к Нам" rows="6"></textarea></div>
							<ul class="actions">
								<li><input type="submit" value="Отправить сообщение" /></li>
							</ul>
						</form>
					</div>
				</div>
				
			</section>	
					<?php include "foter.php";?>