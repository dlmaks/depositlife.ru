 
          <style>
 
          body {
        background:#f0f0f0;
        font-family: Tahoma, sans-serif;
        font-size:14px;
        line-height:135%;
        margin-left: 20%;
        margin-top: 10%;
       }
 
.Box {
    margin-bottom:15px;
        width:668px;
        height: 200px;
        background-color: #ffffff;
        position:relative;
        border: 2px solid #D4D4D4;
        border-radius: 10px;
        box-shadow: 0 0 15px #A9A9A9;
        padding:20px 40px;
}
 
.Box1 {
    margin-bottom:15px;
        width:668px;
        height: 200px;
        background-color: #ffffff;
        position:relative;
        border: 2px solid #D4D4D4;
        border-radius: 30px;
        box-shadow: 0 0 15px #A9A9A9;
        padding:20px 40px;
}
 
.Box2 {
    margin-bottom:15px;
        width:668px;
        height: 200px;
        background-color: #ffffff;
        position:relative;
        border: 2px solid #D4D4D4;
        border-radius: 50px;
        box-shadow: 0 0 15px #0099FF;
        padding:20px 40px;
}
 
</style>
 
        </head>
 
<body>
 
<div class="Box">Радиус углов 10px</div>
<div class="Box1">Радиус углов 30px</div>
<div class="Box2">Радиус углов 50px и с голубым цветов тени блока</div>
 
</body>
</html>