<link rel="stylesheet" href="/assets/css/main.css" />
	<title>Личный кабинет</title>

<center><h3>
	
	<font color="green" > Demo_User </font> |	<font color="blue" > <a href="https://depositlife.ru/">logout</a></font>
	
	</h3></center>
		<!-- Header -->

<section class="box">
<img src="/images/1.png"  ><br> <br />
<font size=2 color=000000  face="arial">Логин:</font><font color="green" > Demo_Login</font>
	<br />
		Статус:<font color="green" >Demo_ активирован до <?echo '[<font color="green" face="courier new">'.date('Y-m-d').'</font>]'?></font>
	<br />
	<li>Внесенная сумма подиски: <?echo '[<font color="green" >500.00</font>] руб.'?></li>
	<li>Процент вознаграждение: <font color="green" > 45% </font>от суммы подписки</li>
	<li> Сумма вознаграждение: <?echo '[<font color="green" >225.00</font>] руб.'?></li>
	<li>Всего <FONT COLOR=GREEN>DEPOSIT</FONT>: <?echo '[<font color="green" >725.00</font>] руб.'?></li>	
		<br />
	Дата регистраций пользователя: <?echo '[<font color="green" face="courier new">'.date('Y-m-d').'</font>]'?>

	<?php

		echo '<center><form name="sysmoney" action=""><input type= "button" name="export" value="Вывод средств"></form></center>';
		
	echo '<center>


			<img src="/images/ok.jpg" width="472" height="120"> <br> 
				<p class="buttond" style="text-align:center; "><a href="#" style=" cursor: pointer; font-size:16px;  text-decoration: none; padding:10px 20px; color:green; background-color:#ffffff; border-radius:10px; border: 1px solid green;"  >Подписка на один месяц </a></p>
			
	</center>					   
 <br /><center><font color=#777777>По окончанию акций Вы сможете вывести средство на свой счет</font></center>';
?>
	
	</section>	

							

<?php include "foter.php"?>