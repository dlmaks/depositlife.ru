﻿	<link rel="stylesheet" href="assets/css/main.css" />
	<footer id="footer">

				<ul class="actions">
						<li><a href="https://vk.com/depositlife" class="icon fa-vk" ><span class="label">VKontakte</span></a></li>
						<li><a href="https://twitter.com/MaksDlife/" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						
						<li><a href="https://www.facebook.com/DepositLife" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="https://www.instagram.com/SerebryakovM/" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="https://www.linkedin.com/in/maks-serebryakov-035680147/" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="https://www.youtube.com/channel/UCieEJ7qixdqSiVAd-XZpanA" class="icon fa-youtube" ><span class="label">Youtube</span></a></li>
						| <i class="icon fa-email"> </i> <font size=5>texdlifes@mail.ru</font>   
					</ul>

				<!-- Menu -->
					<ul class="menu">
					
						<li><br><br>&copy; Business Life</li><li>Design: <a href="mailto:texdlifes@inbox.ru">Global-content</a></li>
					</ul>

			</footer>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1647152541986410'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1647152541986410&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->