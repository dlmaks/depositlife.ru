<html>
<head>
	<script>
fbq('track', 'ViewContent', {
value: 3.50,
currency: 'USD'
});
</script>

<link rel="stylesheet" href="../assets/css/main.css" />
	<title>Регистрация</title>
	<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1647152541986410'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1647152541986410&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
</head>
<body>
<h5><a href="../"><FONT COLOR="green">DEPOSIT LIFE</font></a></h5>
		<center>
		<h2><font color=green>Регистрация</font></h2>
		
				<section id="contact"  class="main style3 secondary">
			
				<div class="content" >
		<form action="reg_auth.php" method="post">
			<div class="field half">
			<input type="email" class="text" name="logr" id="logr" placeholder="email реферала (не обьязательно)"/>
			<br /><input type="email" class="text" name="login" id="login" placeholder="email" />
			<br /><input type="password" class="text" name="password" id="password" placeholder="Пароль" />
	</div>
		<!-- Кнопка отправки данных формы -->
			<br /><input type="submit" name="submit" id="btn-submit" value="Зарегистрироваться" />
			</form>	
			
			</div>
				</div>
			</section>
		<p class="to_reg"><a href="../">Назад</a></p></center>

<?
require_once('../foter.php');
  ?>
</body>
</html>