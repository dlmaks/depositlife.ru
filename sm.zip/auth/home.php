<?php
session_start ();
require_once('database.php');
$start=date('Y-m-d');
if (!$_SESSION['login']) {
	echo " Вы не вошли в систему!";
header('location: login.php');
} 

  connect();
//интерфейс пользователя:	

	$sql = "SELECT * FROM `users` WHERE `login`='" . $_SESSION['login'] . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$row = mysql_fetch_array($query);

if ($row['deposit']=="") $m="00";
else  $m=$row['deposit'];
$b="225";
mysql_close();

?>
<html>
	<title>Личный кабинет</title>
<?php include "header_auth.php"?>		
		<!-- Header -->

<section class="box">
<img src="/images/1.png"  ><br> <br />
<font size=2 color=000000  face="arial">email: <?echo '<font color="green"  >'.$_SESSION['login'].'</font>'?>	
	<br />
	Дата регистрация пользователя: <?echo '[<font color="green" face="courier new">'.$row['reg_date'].'</font>]';?><br />
		Статус: <? if ($row['activate']==null ) 
	 {echo '<font color="red" >не активирован</font>';}
elseif($row['activate']==0) echo '<font color="red" >не активирован</font>';
elseif($row['activate']==1) echo '<font color="green"> активирован до ['.$row['date'].']</font>';
else { echo ' 
<font color="000000" face="arial">Доступен для вывода</font>';	}
		?><br />
	<li>Внесенная сумма подиски: <?echo '[<font color="green" >'.$m.'.00</font>] руб.'?></li>
	<li>Процент вознаграждение: <font color="green" > 45% </font>от суммы подписки</li>
	<li> Сумма вознаграждение: <?echo '[<font color="green" >'.$b.'.00</font>] руб.'?></li>
	Ваши друзья в системе:  <br /><?
		connect();
	$sql = "SELECT `login`,`activate`,`deposit` FROM `users` where `logr` like '".$_SESSION['login']."'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$i=0;
while($row = mysql_fetch_array($query)){
	
	if ($row['activate']=="1") {$i++;}	
	echo '
		
		Пользователь: <font color=blue>'.$row['login'].'</font> :: Статус подписки:: <font color=green>'.$row['activate'].' DEPOSIT</font> : '.$row['deposit'].'<br />';
	

}
  mysql_close();
echo 'Всего подписанных друзей <font color=blue>'.$i.'</font> друзей';	
	?>
	<li> Реферальная вознаграждение: <?$d=$i*50; echo '[<font color="green" >'. $d .'.00</font>] руб.'?></li><br /><hr />
	ВСЕГО <FONT COLOR=GREEN>DEPOSIT</FONT>: <?echo '[<font color="green" size=4 >'.$m=$m+$b+$d.'.00</font>] руб.'?>		
	
		
		
	
	
	<br />
	<?php
			
// обработка данных
			
if ($start===$row['date']) {
		  connect();
	$sql = "update `users` set `activate`='2' WHERE `login`='" . $_SESSION['login'] . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
		
		mysql_close();
		}
		

	
elseif($row['activate']===NULL) 	echo '
<center>

			<img src="/images/ok.jpg" > <br> 
				<p class="buttond" style="text-align:center; "><a href="http://www.free-kassa.ru/merchant/cash.php?oa=500&o=%CF%EE%E4%EF%E8%F1%EA%E0+%ED%E0+%E0%EA%F6%E8%FE+DEPOSIT+LIFE&m=54391&go_2pay=1&enc=windows-1251&form_id=31837&s=bcde5b69d00422b1380c359500a3b6bb"  style=" cursor: pointer; font-size:16px;  text-decoration: none; padding:10px 20px; color:green; background-color:#ffffff; border-radius:10px; border: 1px solid green;"
				><input type="hidden" name="one" value="oneac" />Подписка на 10 дней </a></p>
 <br /><font color=#777777>По окончанию акций Вы сможете вывести средство на свою карту</font></center>';


elseif($row['activate']==0) 	echo '
<center>

			<img src="/images/ok.png" width="472" height="120"> <br> 
				<p class="buttond" style="text-align:center; "><a href="http://www.free-kassa.ru/merchant/cash.php?oa=500&o=%CF%EE%E4%EF%E8%F1%EA%E0+%ED%E0+%E0%EA%F6%E8%FE+DEPOSIT+LIFE&m=54391&go_2pay=1&enc=windows-1251&form_id=31837&s=bcde5b69d00422b1380c359500a3b6bb" style=" cursor: pointer; font-size:16px;  text-decoration: none; padding:10px 20px; color:green; background-color:#ffffff; border-radius:10px; border: 1px solid green;"  >Подписка на 10 дней </a></p>
 <br /><font color=#777777>По окончанию акций Вы сможете вывести средство на свою карту</font></center>';


if ($row['activate']==="2")
echo '
			<hr>
		<center>
		<form name="sysmoney2" action="deactivate.php" method="POST"><table align="center" method=POST>
		<tr><td><input type= "text" name="card" placeholder="номер банковской карты" /> </td><td> 
		<input type= "submit" name="export" value="Вывод средств на карту"></td></tr></table></form></center>
				
		';

?>
	
	<center>
	<hr><br>
	<p class="buttond" style="text-align:center; "><a href="" style=" cursor: pointer; font-size:16px;  text-decoration: none; padding:10px 20px; color:#3232c7; background-color:#ffffff; border-radius:10px; border: 1px solid #3243c7;"  >Обновить</a></p>	
</center>
		
		</font>
	</section>	

							

</html>
<?php include "../foter.php"?>