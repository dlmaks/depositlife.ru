<?php
    require_once('database.php');
    isset($_POST["submit"]); 




   connect();
	$sql = "SELECT * FROM `users` WHERE `login`='" . $_SESSION['login']. "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
header('Refresh: 100; URL = home.php');
    mysql_close();
?>