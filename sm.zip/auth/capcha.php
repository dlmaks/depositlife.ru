<?php

session_start();
if ($_POST[submit]){
 if (mb_strtolower(trim($_POST[otvet]), 'UTF-8') == $_SESSION[otvet]) {
 header("Location: registration.php");
 }
 else {
  header("Location: capcha.php");  
 }
}
?>
<?php
$question = array(array('3+2=', 'пять'),    //вопросы и ответы
                  array('7-1=', 'шесть'),
                  array('20-10=', 'десять'),
                  array('17-10=', 'семь'),
				 array('4+4=', 'восемь'),
				 array('8+1=', 'девять'),
				  array('58-57=', 'один'),
				  array('1+1=', 'два'),
				  array('2+1=', 'три'),
				  array('60-60=', 'ноль'));
$key = rand(0,count($question)-1);        //ключ
$_SESSION[otvet] = $question[$key][1];    //ответ
?>

<title>Антиробот</title>
<link rel="stylesheet" href="../assets/css/main.css" />
<h5><a href="../"><FONT COLOR="green"  >DEPOSIT LIFE</FONT></a></h5>
		<center>
		<h2><font color=green face='times new roman'>Защита от ботов<br /><br /></font></h2>
		
				<section id="contact" class="main style3 secondary">
			<div class="content">
						<div class="box">
					<form method="POST" action="">
  <?php echo '<FONT COLOR="green" size=7>'.$question[$key][0].'</font>'; ?><br /><br />
  <input type="text" name="otvet" placeholder="написать число прописью"><br />
    <input type="submit" name="submit" value="Отправить">

</form>
						</div>
			
					</div>
			</section>
		<p class="to_reg"><a href="../">Назад</a></p></center>

<?
require_once('../foter.php');
  ?>