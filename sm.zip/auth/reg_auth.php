<?php
require_once('database.php');
isset($_post["submit"]);
$logr=$_POST["logr"];
$login=$_POST["login"];
$password=$_POST["password"];
if($password===""||$login==="") {
	echo "<center><br /><br /><br /><font color=red size=3>Введите логин и пароль <br /> </font><a href=registration.php>назад</a></center>";
}
else

{	
  connect();
	$sql = "SELECT `login` FROM `users` WHERE `login`='" . $login . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$row = mysql_fetch_array($query);
 	 mysql_close();
	if ($login!=$row["login"]) 
{
	$password=md5($password);
		session_start();
	$_SESSION['login'] = $login;
	$_SESSION['password'] = $password;
	connect();
		echo '<font color=red><h5>ВНИМАНИЕ! Запомните лучше запищите данные внизу, если вы забыли эти данные то вы не сможете войти в систему!</font></h5><br/>';
	echo 'Логин: <br/>';
	print_r ($login);
	echo '<br/>';
	echo 'Пароль: <br/>';
	print_r ($_POST["password"]);
	echo '<center><a href="../">Назад</a></center>';
	  connect();
	$sql = "INSERT INTO `users` 
			(`login`,`password`,`logr`) VALUES 
			('" . $login . "','" . $password . "','". $logr ."')";
	
	$query = mysql_query($sql) or die("<p>Невозможно добавить пользователя: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	 mysql_close();
	}	
else {
	echo "";
 }
}

?>