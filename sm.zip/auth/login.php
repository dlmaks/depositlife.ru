<?php
  require_once('database.php');
 isset($_post["submit"]);
  $login=$_POST["login"];
 $password=$_POST["password"];
 $password=md5($password);
 
connect();
	$sql = "SELECT `password` FROM `users` WHERE `login`='" . $login . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$row = mysql_fetch_array($query);
 	if($password!=$row["password"]) 
	
	{
		echo "";
}	
else {
		session_start();
	$_SESSION['login'] = $login;
	$_SESSION['password'] = $password;
	$message = '<p>Вы успешно авторизовались в системе. Сейчас вы будете переадресованы в личный кабинет. Если это не произошло, перейдите  по <a href="home.php">прямой&nbsp;ссылке</a>.</p>';
	header('Refresh: 1; URL = home.php');
 }
 mysql_close();
?>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1647152541986410'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1647152541986410&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
<head>
<link rel="stylesheet" href="../assets/css/main.css" />
	<title>Авторизация</title>
</head>
<h5><a href="../"><FONT COLOR="green">DEPOSIT LIFE</FONT></a></h5>
			<center>
		<h2><font color=green>Авторизация</font></h2>
		<section id="contact" class="main style3 secondary">
		<div class="content">
<div class="box">
						<form method="post" action="">
							<div class="field half first"><input type="text" name="login" id="login" placeholder="email" />
							</div>
							<div class="field half"><input type="password" name="password" id="password"  placeholder="Пароль" /></div>
							<ul class="actions">
								<li><input type="submit"name="submit" id="btn-submit" value="Вход" /></li>
							</ul>
						</form>
					</div>
						</div><br>
					</section>
					
	<p class="to_reg"><a href="contract.php">Регистрация и Подписка</a></p>
				[ <a href="../"> Назад </a> ]
					</center>

		
	
	<?require_once('../foter.php');?>	


