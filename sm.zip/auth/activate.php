<?php
session_start ();
$Login_ok=$_SESSION['login'];
include "database.php";
$start=date('Y-m-d');
$money="500";
connect();
	$sql = "SELECT * FROM `users` WHERE `login`='" . $Login_ok . "'";
	$query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
	$row = mysql_fetch_array($query);
    $sql="UPDATE `users` SET `deposit`='" .$money."',`activate`='1',`date`=DATE_ADD('".$start."', interval 10 day) WHERE `login`='" .$Login_ok."'";
    $query = mysql_query($sql) or die("<p>Невозможно выполнить запрос: " . mysql_error() . ". Ошибка произошла в строке " . __LINE__ . "</p>");
mysql_close();
header('Refresh: 1; URL = https://depositlife.ru/auth/home.php');

?>
<script>
fbq('track', 'Purchase', {
value: 247.35,
currency: 'USD'
});
</script>

