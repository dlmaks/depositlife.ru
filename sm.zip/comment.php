<title>Отзывы</title>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1647152541986410'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1647152541986410&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
<link rel="stylesheet" href="/assets/css/main.css" />
<br />
<center><h2><font color=green>ОТЗЫВЫ</font></h2></center>
<div class="box">
<?php include "header.php"?>
<?
FUNCTION save2($a){
$a = preg_replace ('/\s+/',' ', $a) ; 
$a = trim($a) ; 
$a = stripslashes($a);
$a = htmlspecialchars($a);
$a = str_replace("\r\n", "<br>", $a);
return $a;
}
// проверяем, если есть сообщение - обрабатываем
if (isset($_POST['message'])) {
if (!isset($_POST['q']) or ($_POST['q'] != 4)) {
echo "<script type=\"text/javascript\">alert(\"Неверный ответ на контрольный вопрос!\")</script>";
}
else {
// убираем лишние пробелы, заменяем кавычки и теги на символы
$name = save2($_POST['name']);
$message = save2($_POST['message']);
// формируем строку для записи
$date = date("Y-m-d");
$message = "<span class='vyvod'><B> $name </B> - <font color=green size=2>[$date]</font> <br> $message </span> <br> <br>";
// записываем строку в конец файла, если файла нет - создаем его
$fp = fopen((basename($_SERVER["PHP_SELF"] . ".comment")),"a+"); 
flock($fp,LOCK_EX); 
fputs($fp, $message."\r\n"); 
flock($fp,LOCK_UN); 
fclose($fp);
}
}
// печатаем файл 
@readfile(basename(($_SERVER["PHP_SELF"] . ".comment"))); 
echo "<br>";
?>

	<center>
		</div>
		<section id="contact" class="main style3 secondary">
		<div class="content">
<div class="box">
<FORM method="POST" name="comment" >
<span class='vyvod'><b>Ваше имя:</b></span><BR>
<INPUT name="name" type="text" class="vvod" size="30">
<BR><span class='vyvod'> <b>Комментарий:</b></span><BR>
<TEXTAREA name="message" class="vvod" rows="6" cols="60" wrap="virtual"></TEXTAREA>
<BR> <span class='vyvod'> два + два = </span> <input name="q" type="text" id="q" size="2" /> <BR>
<INPUT name="submit" type="submit" value="Добавить отзыв">
<BR />
</FORM>
	</div>
						</div><br>
					</section>
	<?php include "foter.php"?>
