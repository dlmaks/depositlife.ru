<?php

define("SMSC_POST", 0);					// использовать метод POST
define("SMSC_HTTPS", 0);				// использовать HTTPS протокол
define("SMSC_CHARSET", "utf-8");		// кодировка сообщения: utf-8, koi8-r или windows-1251 (по умолчанию)
define("SMSC_DEBUG", 0);				// флаг отладки
define("SMTP_FROM", "api@smsc.ru");     // e-mail адрес отправителя

class SMSClass
{
	private $User, $Pass;

	// ВНУТРЕННИЕ ФУНКЦИИ
	// Функция вызова запроса. Формирует URL и делает 3 попытки чтения
	private function _smsc_send_cmd($cmd, $arg = "", $files = array())
	{
		$url = (SMSC_HTTPS ? "https" : "http")."://smsc.ru/sys/".$cmd.".php?login=".urlencode($this->User)."&psw=".urlencode($this->Pass)."&fmt=1&charset=".SMSC_CHARSET."&".$arg;
		$i = 0;
		do {
			if ($i) {
				sleep(2 + $i);

				if ($i == 2)
					$url = str_replace('://smsc.ru/', '://www2.smsc.ru/', $url);
			}

			$ret = $this->_smsc_read_url($url, $files);
		}
		while ($ret == "" && ++$i < 4);

		if ($ret == "") {
			if (SMSC_DEBUG)
				echo "Ошибка чтения адреса: ".$url."\n";

			$ret = ","; // фиктивный ответ
		}

		$delim = ",";

		if ($cmd == "status") {
			parse_str($arg);

			if (strpos($id, ","))
				$delim = "\n";
		}

		return explode($delim, $ret);
	}

	// Функция чтения URL. Для работы должно быть доступно:
	// curl или fsockopen (только http) или включена опция allow_url_fopen для file_get_contents

	private function _smsc_read_url($url, $files)
	{
		$ret = "";
		$post = SMSC_POST || strlen($url) > 2000 || $files;

		if (function_exists("curl_init"))
		{
			static $c = 0; // keepalive

			if (!$c) {
				$c = curl_init();
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 10);
				curl_setopt($c, CURLOPT_TIMEOUT, 60);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
			}

			curl_setopt($c, CURLOPT_POST, $post);

			if ($post)
			{
				list($url, $post) = explode("?", $url, 2);

				if ($files) {
					parse_str($post, $m);

					foreach ($m as $k => $v)
						$m[$k] = isset($v[0]) && $v[0] == "@" ? sprintf("\0%s", $v) : $v;

					$post = $m;
					foreach ($files as $i => $path)
						if (file_exists($path))
							$post["file".$i] = function_exists("curl_file_create") ? curl_file_create($path) : "@".$path;
				}

				curl_setopt($c, CURLOPT_POSTFIELDS, $post);
			}

			curl_setopt($c, CURLOPT_URL, $url);

			$ret = curl_exec($c);
		}
		elseif ($files) {
			if (SMSC_DEBUG)
				echo "Не установлен модуль curl для передачи файлов\n";
		}
		else {
			if (!SMSC_HTTPS && function_exists("fsockopen"))
			{
				$m = parse_url($url);

				if (!$fp = fsockopen($m["host"], 80, $errno, $errstr, 10))
					$fp = fsockopen("212.24.33.196", 80, $errno, $errstr, 10);

				if ($fp) {
					fwrite($fp, ($post ? "POST ".$m[path] : "GET ".$m[path].'?'.$m[query])." HTTP/1.1\r\nHost: smsc.ru\r\nUser-Agent: PHP".($post ? "\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: ".strlen($m['query']) : "")."\r\nConnection: Close\r\n\r\n".($post ? $m['query'] : ""));

					while (!feof($fp))
						$ret .= fgets($fp, 1024);
					list(, $ret) = explode("\r\n\r\n", $ret, 2);

					fclose($fp);
				}
			}
			else
				$ret = file_get_contents($url);
		}

		return $ret;
	}
	
	public function __construct($UserName, $Password)
	{
		$this->User = $UserName;
		$this->Pass = $Password;
	}

	public function GetBalance()
	{
		$m = $this->_smsc_send_cmd("balance"); // (balance) или (0, -error)

		if (SMSC_DEBUG) {
			if (!isset($m[1]))
				echo "Сумма на счете: ", $m[0], "\n";
			else
				echo "Ошибка №", -$m[1], "\n";
		}
		return isset($m[1]) ? false : $m[0];
	}

	public function SendSms($msg)
	{
		$m = $this->_smsc_send_cmd("send", "cost=3&phones=".urlencode($msg['Phone'])."&mes=".urlencode($msg['Text']));

		if (SMSC_DEBUG) {
			if (!$m[1] > 0)
			    return array('Error'=>true);
		}
		return array('Error'=>false);
	}

}

