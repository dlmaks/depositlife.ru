<?php

/* Язык */
define('SANTI_LANG', 'ru');

/** Имя администратора антивируса */
define('SANTI_NAME', 'admin');

/** Пароль администратора антивируса */
define('SANTI_PASSWORD', 'f49ce1dfa10a46c93729206b83f56767');

/** KEY сканера по настольным антивирусам */
define('SANTI_4KEY', '');

/** TOKEN сканера по настольным антивирусам */
define('SANTI_4TOKEN', '');

/** URL сайта**/
define('SANTI_URL', 'http://depositlife.ru');

/** Папка с SANTI/**/
define('SANTI_PATH', 'SANTI');

/** Серверный путь к сайту/**/
define('SANTI_SERVERPATH', '/var/www/vhosts/deposilife.ru/httpdocs');

/** Часовой пояс/**/
define('SANTI_TIMEZONE', 'Europe/Moscow');

/** Ручной запуск автопилотов **/
define('SANTI_CRON_HAND', false);

/** Автоматическое обновление баз сигнатур/**/
define('SANTI_AUTO_UPDATE', false);

/** Имя сервера активной MySQL */
define('SANTI_DB_HOST', 'srv-pleskdb22.ps.kz:3306');

/** Имя активной MySQL */
define('SANTI_DB_NAME', 'deposili_xxx');

/** Имя пользователя активной MySQL */
define('SANTI_DB_USER', 'depos_xxx');

/** Пароль доступа к активной MySQL */
define('SANTI_DB_PASSWORD', 'dxxx123456');

/** Имя сервера копии MySQL */
define('SANTI_DBKOP_HOST', '');

/** Имя копии MySQL */
define('SANTI_DBKOP_NAME', '');

/** Имя пользователя копии MySQL */
define('SANTI_DBKOP_USER', '');

/** Пароль доступа к копии MySQL */
define('SANTI_DBKOP_PASSWORD', '');

/** Кодировка базы данных. */
define('SANTI_DB_CHARSET', '0');

/** Тип файлового хранилища (облака) */
define('SANTI_CLOUD', 'none');

/** Адрес файлового хранилища (облака) */
define('SANTI_CLOUD_URL', '');

/** логин к облаку */
define('SANTI_CLOUD_LOGIN', '');

/** Пароль к облаку */
define('SANTI_CLOUD_PASSWORD', '');

/** Папки и файлы исключения через , */
define('SANTI_STOPF', 'SANTI, *.gif, *.jpg, *.pdf, *.jpeg, *.png, *.bmp, *.log, *.xml.gz, images, *.mp3, *.mp4, *.avi, *.flv, cache, rss.xml, sitemap.xml, error_log');

/** Папки и файлы исключения backup через , */
define('SANTI_STOPB', 'SANTI');

/** Таблицы исключения БД */
define('SANTI_STOPT', '');

/** ID антивируса */
define('SANTI_ID', '');

/** Почта администратора антивируса */
define('SANTI_EMAIL', '');

/** Телефона администратора антивируса */
define('SANTI_PHONE', '');

/** Уведомлять ли по email */
define('SANTI_INFO_EMAIL', true);

/** Уведомлять ли по смс */
define('SANTI_INFO_SMS', false);

/** Логин к СМС агрегатору */
define('SANTI_SMS_USER', '');

/** Пароль к СМС агрегатору */
define('SANTI_SMS_PASSWORD', '');

/** Первый запуск**/
define('SANTI_START', '0');

/** Первый запуск**/
define('SANTI_VERSION', '0.6');

/** Абсолютный путь автоматом **/
define('ABSPATH', dirname(__FILE__).'/');

set_time_limit(0);
date_default_timezone_set(SANTI_TIMEZONE);

?>