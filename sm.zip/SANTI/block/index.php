<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	    <title>Сайт временно закрыт на реконструкцию.</title>
	    <link type="text/css" href="styles/reset.css" rel="stylesheet" media="all" />
	    <link type="text/css" href="styles/text.css" rel="stylesheet" media="all" />
	    <link type="text/css" href="styles/960.css" rel="stylesheet" media="all" />
	    <link type="text/css" href="styles/style.css" rel="stylesheet" media="all" />
		<link type="text/css" href="styles/jquery.countdown.css" rel="stylesheet" media="all" />
	</head>
	<?php include("../config.php"); ?>
	<body>
		<!--Header-->
	    <div class="header_cotainer">
		        <div class="container_12">
			   		<div class="grid_12">
		          		<p> <h2>КРАТКОВРЕМЕННАЯ РЕКОНСТРУКЦИЯ САЙТА <a href="<?php echo SANTI_URL;?>" style="color: #7C0505; text-decoration: none; display:inline; border-bottom:1px dashed #7C0505;">обновить страницу</a></h2></p>
		        	</div>
				</div>
		</div>
		<!--Content-->
		<div class="content_container container_12">
			  <div class="container_12 content_bg">
				  <div class="container_12 content_bg2">
					  <!-- Top line-->
					  <div class="grid_3 logo"><a href="<? echo SANTI_URL; ?>"><img src="images/logo.png" alt="" align="center"/></a><p class="slogan"><? echo SANTI_URL;?></p></div>
					  <div class="grid_9"><img src="images/dottedline.png" alt="" align="left" /></div>
					  
					  <div class="clear"></div>
					  
					  <!-- Text -->
					  	<div class="grid_7">
							  <p>В НАСТОЯЩИЙ МОМЕНТ НА САЙТЕ СОВЕРШАЮТСЯ ЧУДЕСА</p>
							  <p style="color:#7C0505;">ЧЕРЕЗ МГНОВЕНИЕ МЫ ВЕРНЕМСЯ!</p>
							  <p>НЕ ОТХОДИТЕ ДАЛЕКО ОТ ЭКРАНОВ СВОИХ КОМПЬЮТЕРОВ</p>
						</div>
					  <div class="clear"></div>
				  </div>
			  </div>
		</div>

			<!--Footer section-->
		    <div class="footer_container"><div class="container_12">
		    	<p><br><a href="http://santi.pro" style="text-decoration: none; display:inline; border-bottom:1px dashed;">Антивирус для сайтов "САНТИ"</a> </p>
		    </div></div>
	</body>
</html>