<?php

$_LANG = array();