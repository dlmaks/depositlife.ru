<?php

$_LANG = array(
	'Log in'=>'Войти',
	'Login'=>'Вход',
	'SANTI'=>'САНТИ',
	'SANTI - website antivirus'=>'САНТИ - антивирус для сайтов',
	'Username'=>'Логин',
	'Password'=>'Пароль',
	'Forgot your password?'=>'Забыли пароль?',
	'Sign in'=>'Вход',
	'Dashboard'=>'Пульт управления',
	'Settings'=>'Настройки',
	'Install'=>'Установка САНТИ',
	'Utils'=>'Утилиты',
	'Password generator'=>'Генератор паролей',
	'.ftpaccess configurator'=>'.ftpaccess конфигуратор',
	'PHP info'=>'PHP info',
	'Next'=>'Далее',
	'Previous'=>'Назад',
	'Finish'=>'Готово'
);