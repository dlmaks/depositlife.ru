var lang = {
	'Waiting. Santi in working.' : 'САНТИ работает. Подождите.'
};
