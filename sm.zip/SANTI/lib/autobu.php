<?php

include("lib/clouds.php");

to_log(2);

$site_root = SANTI_SERVERPATH;
$path = SANTI_SERVERPATH.'/'.SANTI_PATH.'/datas/backups/';
$archivename = "santi_abu_".date('Y-m-d_H-i') . "_" . $_SERVER['SERVER_NAME'] . ".zip";

$exludethisdirmode = SANTI_STOPB;
$hidden = array('.ftpquota', '.ftpaccess', '.htaccess');

autopilots_add_time(3);

$path_result = compress($path, $archivename);
if(SANTI_CLOUD != 'none')
{
	if(file_exists(SANTI_SERVERPATH."/".SANTI_PATH."/datas/backups/".$archivename))
		send_to_cloud(SANTI_SERVERPATH."/".SANTI_PATH."/datas/backups/".$archivename);
	unlink(SANTI_SERVERPATH."/".SANTI_PATH."/datas/backups/".$archivename);
}

function compress($path, $archivename)
{
	global $site_root;
	$zip = new ZipArchive();
	$zip->open($path.$archivename, ZipArchive::CREATE);
	$file_list = get_file_list($site_root);
	foreach($file_list as $file) {
		$zip->addFile($file, str_replace($site_root.'/', '', $file));
	}
	$zip->close();
	return "1";
}

function get_file_list($dir)
{
	global $site_root, $exludethisdirmode, $hidden;
	$file_list = array();

	foreach($hidden as $hf)
		if(file_exists($dir.'/'.$hf))
			$file_list[] = $dir.'/'.$hf;

	foreach(glob($dir.'/*') as $file) {
		if(is_file($file)) {
			if(strpos($file, '.zip')) continue;
			if(is_contains($exludethisdirmode, str_replace($site_root.'/', '', $file))) continue;
			$file_list[] = $file;
		}
		elseif(is_dir($file)) {
			if(is_contains($exludethisdirmode, str_replace($site_root.'/', '', $file))) continue;
			$file_list = array_merge($file_list, get_file_list($file));
		}
	}
	return $file_list;
}

function is_contains($mask, $file)
{
	$mask = array_map('trim', explode(',', $mask));

	foreach($mask as $m) {
		if(empty($m)) continue;
		$m = preg_replace('/\//', '\/', $m);
		$m = preg_replace('/\./', '\.', $m);
		$m = preg_replace('/\*/', '.*', $m);
		if(preg_match("/^$m$/i", $file)) return true;
	}
	return false;
}

?>