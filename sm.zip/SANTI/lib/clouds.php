<?php

function send_to_cloud($send_file = "")
{
    switch (SANTI_CLOUD)
    {
        case "google":
            send_to_google($send_file);
            break;
        case "yandex":
            send_to_yadisk($send_file);
            break;
        case "dropbox":
            send_to_dropbox($send_file);
            break;
        case "ftp":
			send_to_ftp($send_file);
            break;
        default:
            break;
    }
}

function send_to_ftp($file)
{
	$fp = fopen($file, 'r');
	// установка соединения
	$conn_id = ftp_connect(SANTI_CLOUD_URL);
	// вход с именем пользователя и паролем
	ftp_login($conn_id, SANTI_CLOUD_LOGIN, SANTI_CLOUD_PASSWORD);
	// попытка закачивания файла
	ftp_fput($conn_id, basename($file), $fp, FTP_BINARY);
	// закрываем соединение и дескриптор файла
	ftp_close($conn_id);
	fclose($fp);
}

function send_to_dropbox($send_file = "")
{
    $dropbox = new DropboxClient(array(
        'app_key' => SANTI_CLOUD_LOGIN,
        'app_secret' => SANTI_CLOUD_PASSWORD,
        'app_full_access' => true,
    ),'en');

    $access_token = load_token("dropbox");
    if(!empty($access_token))
    {
        $dropbox->SetAccessToken($access_token);
    }
    elseif(!empty($_GET['auth_callback']))
    {
        $request_token = load_token($_GET['oauth_token']);
        if(empty($request_token)) die('Request token not found!');
        $access_token = $dropbox->GetAccessToken($request_token);
        store_token($access_token, "dropbox");
        delete_token($_GET['oauth_token']);
        header('Location: /'.SANTI_PATH.'/index.php?page=19');
    }

    if(!$dropbox->IsAuthorized())
    {
        $return_url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME']."?auth_callback=1";
        $auth_url = $dropbox->BuildAuthorizeUrl($return_url);
        $request_token = $dropbox->GetRequestToken();
        store_token($request_token, $request_token['t']);
        die("Authentication required. <a href='$auth_url'>Click here.</a>");
    }
    $dropbox->UploadFile($send_file);
}

function send_to_yadisk($send_file = "")
{
    $wdc = new webdav_client();
    $wdc->set_server('ssl://webdav.yandex.ru');
    $wdc->set_port(443);
    $wdc->set_user(SANTI_CLOUD_LOGIN);
    $wdc->set_pass(SANTI_CLOUD_PASSWORD);
    // use HTTP/1.1
    $wdc->set_protocol(1);
    // enable debugging
    $wdc->set_debug(false);

    if (!$wdc->open()){echo "error";}

    if (!$wdc->check_webdav()){}

    $http_status = $wdc->mkcol("/santibackups/");
    preg_match('/\/([^\/]*)$/', $send_file, $m);
    $http_status = $wdc->put_file( "/santibackups/".$m[1], $send_file);
    $fileUnpublishinStatus = $wdc->fileUnPublish("/santibackups/".$send_file);
    $wdc->close();
}

function send_to_google($send_file = '')
{
	require_once 'classes/Google/Google_Client.php';
	require_once 'classes/Google/contrib/Google_DriveService.php';

	$client_id = SANTI_CLOUD_LOGIN;
	$client_secret = SANTI_CLOUD_PASSWORD;
	$redirect_uri = 'http://'.$_SERVER['HTTP_HOST'].'/'.SANTI_PATH.'/index.php?page=19';

	$client = new Google_Client();
	$client->setClientId($client_id);
	$client->setClientSecret($client_secret);
	$client->setRedirectUri($redirect_uri);
	$client->setScopes(array('https://www.googleapis.com/auth/drive'));
	$service = new Google_DriveService($client);

	if (isset($_REQUEST['logout'])) {
		unset($_SESSION['upload_token']);
	}

	//Request authorization
	if (isset($_GET['code'])) {
		$client->authenticate($_GET['code']);
		$_SESSION['upload_token'] = $client->getAccessToken();
		store_token($_SESSION['upload_token'], 'google');
		$redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'].'?page=19';
		header('Location: ' . $redirect);
	}

	// Exchange authorization code for access token
	if ($access_token = load_token('google')) {
		$client->setAccessToken($access_token);
	} else {
		$authUrl = $client->createAuthUrl();
		header('Location: '.$authUrl);
	}

	//Insert a file
	if ($client->getAccessToken()) {
		$file = new Google_DriveFile();
		preg_match('/\/([^\/]+)$/', $send_file, $m);
		$file->setTitle($m[1]);
		//$file->setDescription('');
		$file->setMimeType('text/plain');

		$data = file_get_contents($send_file);

		$createdFile = $service->files->insert($file, array(
		'data' => $data,
		'mimeType' => 'text/plain',
		));
	}
}

function store_token($token, $name)
{
    if(!file_put_contents("datas/tokens/$name.token", serialize($token)))
        die('<br />Could not store token! <b>Make sure that the directory `tokens` exists and is writable!</b>');
}

function load_token($name)
{
    if(!file_exists("datas/tokens/$name.token")) return null;
    return unserialize(file_get_contents("datas/tokens/$name.token"));
}

function delete_token($name)
{
    unlink("datas/tokens/$name.token");
}

?>
