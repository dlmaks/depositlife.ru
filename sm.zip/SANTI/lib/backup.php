<?php

switch ($dobu)
{
    case "2":
        $path_result = decompress($path, $bufile);
        die($path_result);
      break;
    default:
        die("0");
        break;
}

/*decompress*/
function decompress($path, $selarchive) 
{
	if(!is_dir($path)) mkdir($path);
	$zip = new ZipArchive();
	$zip->open($selarchive);
	$zip->extractTo($path);
	$zip->close();
}
/*decompress*/

die("0");
?>