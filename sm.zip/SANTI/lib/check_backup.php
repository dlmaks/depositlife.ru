<?php

$backup_dir = "datas/backups/*.zip";
to_log(8);
foreach(glob($backup_dir) as $file)
{
	if(!strpos($file, "lastsanti")) 
		if(filemtime($file) + 60*60*24*30 < time())
			unlink($file);
}

?>