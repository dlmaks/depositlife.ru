<?php

function check_notifiers()
{
	$xml="http://santivi.com/category/uvedomleniya-v-santi/feed";

	$xmlDoc = new DOMDocument();
	$xmlDoc->load($xml);

	$x=$xmlDoc->getElementsByTagName('item');

	if( $x->length > 20 )
	  $num = 20;
	else
	  $num = $x->length;

	for ($i=0; $i<$num; $i++)
	{
	    $item_title=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('title')->item(0)->childNodes->item(0)->nodeValue));
	    $item_link=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('link')->item(0)->childNodes->item(0)->nodeValue));
	    $item_desc=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('description')->item(0)->childNodes->item(0)->nodeValue));
	    $item_date=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('pubDate')->item(0)->childNodes->item(0)->nodeValue));

	    notifiers_add($item_link, $item_title, Rfc2822ToTimestamp($item_date), 0);
	}

    $ver_data = "";

    $url = "http://santivi.com/version.txt";
    $parse_url = parse_url($url);
    $path = $parse_url["path"];
    $host = $parse_url["host"];

    $result = tcp_send("santivi.com", array(
                                "POST ".$path." HTTP/1.1\r\n",
                                "Host: santivi.com\r\n",
                                "User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.2 Safari/537.36\r\n", 
                                "Content-Type: application/x-www-form-urlencoded\r\n",
                                "Content-Length: ".strlen($ver_data)."\r\n",
                                "Connection: close\r\n\r\n",
                                $ver_data."\n\n",
                            )
        );

    $length = strrpos($result, "~") - strpos($result, "~");
    $result = substr($result, strpos($result, "~")+1, $length-1);

    if(SANTI_VERSION < $result)
    	notifiers_add("http://santivi.com/skachat", "Скачайте обновленный САНТИ.", "Ваша версия устарела.", 0);
}

function Rfc2822ToTimestamp($date)
{
	$aMonth = array(
             "Jan"=>"1", "Feb"=>"2", "Mar"=>"3", "Apr"=>"4", "May"=>"5",
             "Jun"=>"6", "Jul"=>"7", "Aug"=>"8", "Sep"=>"9", "Oct"=>"10",
             "Nov"=>"11", "Dec"=>"12",
             "янв"=>"1", "фев"=>"2", "мар"=>"3", "апр"=>"4", "май"=>"5",
             "июн"=>"6", "июл"=>"7", "авг"=>"8", "сен"=>"9", "окт"=>"10",
             "ноя"=>"11", "дек"=>"12",
             );
    //26 Jul 2013 10:51:00 +0400
    if (strlen($date) <= 27){$date="Fri, ".$date;}
        
    list( , $day, $month, $year, $time) = explode(" ", $date);
    list($hour, $min, $sec) = explode(":", $time);
    $month = $aMonth[$month];
    return $year."-".$month."-".$day." ".$hour.":".$min.":".$sec;
}

function tcp_send($board, $data)
{
        $answer = "";

        // Get IP
        $ip = gethostbyname($board);
        // Open socket
        $fp = fsockopen($ip, 80);

        if ( $fp )
        {
            // Set HTTP header
            foreach( $data as $row )
            {
                fputs($fp, $row);
            }

            // Get an answer
            while( !feof($fp) )
            {
                $answer .= fread($fp, 512);
            }

            fclose($fp);
        }

        return $answer;
} 

?>