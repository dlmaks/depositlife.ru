<?php

function send_mail($subject, $message)
{
	if (SANTI_INFO_EMAIL)
	{
		$subject = $subject . ' ' .$_SERVER['SERVER_NAME'];
		preg_match('/(w{3})?\.?(.*)$/', $_SERVER['SERVER_NAME'], $m);
		$address = 'Антивирус для сайтов SANTI <alerts@'.$m[2].'>';
		$headers = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		$headers .= 'From: ' . $address . "\r\n";

		$mes = "<table width=100%>
					<tr>
						<td><p>".$message."</p></td>
					</tr>
					<tr>
						<td><br><b>Интернет-антивирус</b><br><br><a href='http://santivi.com'><img src='http://santivi.com/Images/logo.png' align = left style='margin: 3px;'></a></td>
					</tr>
				</table>";
		$send = mail(SANTI_EMAIL, $subject, $mes, $headers);
		return 1;
	}
}

function send_sms($message)
{
	if(SANTI_INFO_SMS)
	{
		$login = SANTI_SMS_USER;
		$password = SANTI_SMS_PASSWORD;
		$msg = array(
			'Phone' => trim(SANTI_PHONE),
			'Text' => $message
		);
			
		$sms = new SMSClass($login, $password);
		$result = $sms->SendSMS($msg);
		if ($result['Error'])
			return 0;
		else
			return 1;
	}
}

?>