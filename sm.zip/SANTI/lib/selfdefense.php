<?php

$buneed = false;
$dosf = 3;
include('lib/scanfiles.php');

if($buneed)
{
	to_log(9);
	objects_add("-", 20, "автоматическое восстановление антивируса", 2, 0);
	$fileoverwrite = true;
	$bufile = 'datas/backups/lastsanti.zip';
	$path = addslashes(htmlspecialchars(strip_tags(trim(rtrim(preg_replace('/\\\+|\/+/', '/', SANTI_SERVERPATH.'/'.SANTI_PATH.''), '/')))));
	$dobu = 2;
	include('lib/backup.php');
}

?>