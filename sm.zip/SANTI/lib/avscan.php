<?php

include("lib/notifier.php");

to_log(3);
$virus = false;

autopilots_add_time(5);

$url = str_replace("http://", "", SANTI_URL);
$url = str_replace("/", "", $url);
$post = "id=".SANTI_4KEY."&token=".SANTI_4TOKEN."&action=exploit&exploit=".$url;

$result = tcp_send("scan4you.net", array(
                            "POST /remote_async.php HTTP/1.1\r\n",
                            "Host: scan4you.net\r\n",
                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                            "Content-Type: application/x-www-form-urlencoded\r\n",
                            "Content-Length: ".strlen($post)."\r\n",
                            "Connection: close\r\n\r\n",
                            $post,
                        )
    );

$jsonpos = strpos($result, '{');
$result = substr($result, $jsonpos, strlen($result) - $jsonpos);
$job = json_decode($result, 1);
$jid = $job['JOB_ID'];

if (!$job['JOB_ID']) exit;

sleep(10);

while (!$ret = get_result($jid))
{
    sleep(10);
}

if ($ret['STATUS'] == 'READY')
{
    $text = "Сканер по настольным антивирусам обнаружил определение сайта как вредоносного.<br>Подробнее:<br><br>";
    $res = show_tree($ret);
    $text .= $res;

    if ($virus)
    {
        send_mail("Уведомление АВ автопилота", $text);
        send_sms("Событие от САНТИ АВ. Критичность: высокая!");
        objects_add($res, 21, "требуется ручной поиск и лечение", 3, 0);
    }
}

if ($ret['STATUS'] == 'ERROR')
{
    //print_r($ret['ERROR']);
}
if ($ret['STATUS'] == 'NOT FOUND')
{
    //print_r($ret);
}

function show_tree($ret)
{
    global $virus;

    $buffer = null;
    foreach ($ret as $key => $arr)
    {
        if (is_array($arr))
        {
            if($key != "RESULT")
            {
                $buffer .= '<b>Антивирус '.$key.': </b><br>';
                $virus = true;
            }
            $buffer .= show_tree($arr).'<br>';
        }
        else if(($arr != "OK") && ($arr != "READY"))
        {
            $buffer .= 'Файл <b>'.$key.'</b> вирус <b><i>'.$arr.'</i></b><br>';
            $virus = true;
        }
    }

    return $buffer;
}

function get_result($jid)
{
    global $url,$id,$token;

    $post = "id=".SANTI_4KEY."&token=".SANTI_4TOKEN."&action=get_job&job_id=".$jid;

    $response = tcp_send("scan4you.net", array(
                            "POST /remote_async.php HTTP/1.1\r\n",
                            "Host: scan4you.net\r\n",
                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                            "Content-Type: application/x-www-form-urlencoded\r\n",
                            "Content-Length: ".strlen($post)."\r\n",
                            "Connection: close\r\n\r\n",
                            $post,
                        )
    );

    $jsonpos = strpos($response, '{');
    $response = substr($response, $jsonpos, strlen($response) - $jsonpos);
    $job = json_decode($response, 1);

    if ($job['STATUS'] != 'WORKING')
        return $job;
}

function tcp_send($board, $data)
{
        $answer = "";

        // Get IP
        $ip = gethostbyname($board);
        // Open socket
        $fp = fsockopen($ip, 80);

        if ( $fp )
        {
            // Set HTTP header
            foreach( $data as $row )
            {
                fputs($fp, $row);
            }

            // Get an answer
            while( !feof($fp) )
            {
                $answer .= fread($fp, 512);
            }

            fclose($fp);
        }

        return $answer;
}

?>