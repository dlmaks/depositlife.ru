<?php

include("lib/notifier.php");

to_log(6);
if(ALERT_SECH)
    $al = 1;
else
    $al = 0;

autopilots_add_time(4);

$notifier = false;
$text = "";

$ya_data = "url=".urlencode(SANTI_URL)."&mime=html&l10n=ru";
$goo_data = "";

$url = "http://www.google.com/safebrowsing/diagnostic?site=".urlencode(SANTI_URL)."&hl=ru";
$parse_url = parse_url($url);
$path = $parse_url["path"];
if($parse_url["query"])
	$path .= "?" . $parse_url["query"];
	$host = $parse_url["host"];

$result1 = tcp_send("www.google.com", array(
                            "POST ".$path." HTTP/1.1\r\n",
                            "Host: www.google.com\r\n",
                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                            "Content-Type: application/x-www-form-urlencoded\r\n",
                            "Content-Length: ".strlen($goo_data)."\r\n",
                            "Connection: close\r\n\r\n",
                            $goo_data."\n\n",
                        )
    );

$result2 = tcp_send("yandex.ru", array(
                            "POST /infected HTTP/1.1\r\n",
                            "Host: yandex.ru\r\n",
                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                            "Content-Type: application/x-www-form-urlencoded\r\n",
                            "Content-Length: ".strlen($ya_data)."\r\n",
                            "Connection: close\r\n\r\n",
                            $ya_data,
                        )
    );

if(strpos($result1, "Сайт занесен в список подозрительных"))
{
	$text = "Сканер поисковых систем выявил занесение сайта в список подозрительных ПС Google.<br><br>";
	$notifier = true;
	objects_add("http://google.com", 18, "требуется очистить сайт и отправить на проверку в Google", 3, 0);
}

if(strpos($result2, "может быть опасен"))
{
	$text .= "Сканер поисковых систем выявил занесение сайта в список подозрительных ПС Yandex.";
	$notifier = true;
	objects_add("http://yandex.ru", 17, "требуется очистить сайт и отправить на проверку в Yandex", 3, 0);
}

if($notifier)
{
	send_mail("Уведомление ПС автопилота", $text);
	send_sms("Событие от САНТИ ПС. Критичность: высокая!");
}

function tcp_send($board, $data)
{
        $answer = "";

        // Get IP
        $ip = gethostbyname($board);
        // Open socket
        $fp = fsockopen($ip, 80);

        if ( $fp )
        {
            // Set HTTP header
            foreach( $data as $row )
            {
                fputs($fp, $row);
            }

            // Get an answer
            while( !feof($fp) )
            {
                $answer .= fread($fp, 512);
            }

            fclose($fp);
        }

        return $answer;
}

?>