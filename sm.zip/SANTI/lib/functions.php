<?php

function is_token()
{
	if(SANTI_CLOUD == 'google' && is_file('datas/tokens/google.token')) return true;
	if(SANTI_CLOUD == 'dropbox' && is_file('datas/tokens/dropbox.token')) return true;
	if(SANTI_CLOUD == '' || SANTI_CLOUD == 'yandex') return true;
}

function token_stat()
{
	$ret = array();
	if(is_file('datas/tokens/google.token')) $ret[] = 'google';
	if(is_file('datas/tokens/dropbox.token')) $ret[] = 'dropbox';
	return implode(',', $ret);
}

function get_alert_type($id)
{
	switch ($id)
	{
        case 0: $alert_type = "новый файл"; break;
        case 1: $alert_type = "изменение файла"; break;
        case 2: $alert_type = "изменение прав на файл"; break;
        case 3: $alert_type = "iframe вставка"; break;
        case 4: $alert_type = "шелл скрипт"; break;
        case 5: $alert_type = "unix файл"; break;
        case 6: $alert_type = "шифрованный код"; break;
        case 7: $alert_type = "вредоносный скрипт"; break;
        case 8: $alert_type = "каталог ссылок"; break;
        case 9: $alert_type = "скрытый файл"; break;
        case 10: $alert_type = "дорвей"; break;
        case 11: $alert_type = ".htaccess модификация"; break;
        case 12: $alert_type = "скрытый php код"; break;
        case 13: $alert_type = "перелинковщик"; break;
        case 14: $alert_type = "ошибка чтения файла"; break;
        case 15: $alert_type = "большая папка"; break;
        case 16: $alert_type = "подозрительное содержимое"; break;
        case 17: $alert_type = "блокировка яндексом"; break;
        case 18: $alert_type = "блокировка google"; break;
        case 19: $alert_type = "удаление файла"; break;
        case 20: $alert_type = "вмешательство в антивирус"; break;
        case 21: $alert_type = "блокировка настольными антивирусами"; break;
        case 22: $alert_type = "от утилиты"; break;
    }

    return $alert_type;
}

function get_alert_criticality($id)
{
	switch ($id)
    {
        case 1: $alert_criticality = "низкая"; break;
        case 2: $alert_criticality = "средняя"; break;
        case 3: $alert_criticality = "высокая"; break;
    }

    return $alert_criticality;
}

function get_alert_status($id)
{
	switch ($id)
	{
        case 0: $alert_status = "необработан"; break;
        case 1: $alert_status = "вылечено"; break;
        case 2: $alert_status = "игнорировать"; break;
    }

    return $alert_status;
}

/**
 * Функция вывода списка временных зон для настроек
 *
 * @param string $name_var имя переменной для select
 * @param string $id_select выделенный элемент
 * @param string $style дополнение к <select>, можно стиль указать или например multyple или количество видимых строк... и т.д. Просто вставляется в <select $style>
 *
 * @author WeBi <adm@webi.ru>
 * @version v 1.0  дата 19 октября 2014
 */
function get_timezone_select($name_var, $id_select = '', $style = '')
{
    if(!strlen($id_select)) $id_select='Europe/Moscow';

    $time_zone['Pacific/Samoa'] = '(GMT -11:00) Остров Мидуэй, Самоа';
    $time_zone['US/Hawaii'] = '(GMT -10:00) Гавайи';
    $time_zone['US/Alaska'] = '(GMT -9:00) Аляска';
    $time_zone['America/Los_Angeles'] = '(GMT -8:00) Лос-Анджелес';
    $time_zone['America/Denver'] = '(GMT -7:00) Денвер';
    $time_zone['America/Chicago'] = '(GMT -6:00) Центральное время (США и Канада), Мехико';
    $time_zone['America/New_York'] = '(GMT -5:00) Восточное время (США и Канада), Богота, Лима, Нью-Йорк';
    $time_zone['America/Caracas'] = '(GMT -4:00) Каракас';
    $time_zone['America/Buenos_Aires'] = '(GMT -3:00) Бразилия, Буэнос-Айрес, Джорджтаун';
    $time_zone['America/Sao_Paulo'] = '(GMT -2:00) Среднеатлантическое время';
    $time_zone['Atlantic/Azores'] = '(GMT -1:00) Азорские острова, острова Зелёного Мыса';
    $time_zone['Europe/London'] = '(GMT 0) Дублин, Лондон, Лиссабон, Касабланка, Эдинбург';
    $time_zone['Europe/Berlin'] = '(GMT +1:00) Брюссель, Копенгаген, Мадрид, Париж, Берлин';
    $time_zone['Europe/Kiev'] = '(GMT +2:00) Афины, Киев, Минск, Бухарест, Рига, Таллин';
    $time_zone['Europe/Moscow'] = '(GMT +3:00) Москва, Санкт-Петербург, Волгоград';
    $time_zone['Asia/Yerevan'] = '(GMT +4:00) Абу-Даби, Баку, Тбилиси, Ереван';
    $time_zone['Asia/Yekaterinburg'] = '(GMT +5:00) Екатеринбург, Исламабад, Карачи, Ташкент';
    $time_zone['Asia/Novosibirsk'] = '(GMT +6:00) Омск, Новосибирск, Алма-Ата, Астана';
    $time_zone['Asia/Krasnoyarsk'] = '(GMT +7:00) Красноярск, Норильск, Бангкок, Ханой, Джакарта';
    $time_zone['Asia/Singapore'] = '(GMT +8:00) Иркутск, Пекин, Перт, Сингапур, Гонконг';
    $time_zone['Asia/Tokyo'] = '(GMT +9:00) Якутск, Токио, Сеул, Осака, Саппоро';
    $time_zone['Asia/Vladivostok'] = '(GMT +10:00) Владивосток, Восточная Австралия, Гуам';
    $time_zone['Australia/Sydney'] = '(GMT +11:00) Магадан, Сахалин, Соломоновы Острова';
    $time_zone['Asia/Kamchatka'] = '(GMT +12:00) Камчатка, Окленд, Уэллингтон, Фиджи';


    $retutn = '<select name="'.$name_var.'" id="'.$name_var.'" '.$style.'>'."\n";

    foreach ($time_zone as $key => $value)
    {
        $retutn.='<option value="'.$key.'" '.($key == $id_select ? 'selected' : '').'>'.$value.'</option>'."\n";
    }
    $retutn.="</select>\n";

    return $retutn;
}

function objects_add($obj, $type, $info, $criticality, $status) //добавляем объект
{
	global $db;

	$new_obj[OBJ_ID] = 0;
	$new_obj[OBJ_OBJ] = $obj;
	$new_obj[OBJ_TYPE] = $type;
	$new_obj[OBJ_INFO]  = $info;
	$new_obj[OBJ_CRITICALITY]  = $criticality;
	$new_obj[OBJ_STATUS]  = $status;
	$new_obj[OBJ_TIME]  = time();

	$newId = $db->insertWithAutoId(objects, OBJ_ID, $new_obj);

	if($type == 22)
		die("$newId");
}

function objects_get() // получаем все найденные объекты
{
	global $db;
	$allrows = $db->selectWhere(objects, NULL, -1, new OrderBy(OBJ_ID, DESCENDING, INTEGER_COMPARISON));

	return $allrows;
}

function objects_null($id) //обнуляем статус подозрительного объекта
{
	global $db;

	$db->updateSetWhere(objects, array(OBJ_STATUS => '0'), new SimpleWhereClause(OBJ_ID, '=', $id));

	die(1);
}

function objects_healed($id) //объект вылечен
{
	global $db;

	$db->updateSetWhere(objects, array(OBJ_STATUS => '1'), new SimpleWhereClause(OBJ_ID, '=', $id));

	die(1);
}

function get_objects_path($id) //получаем путь к файлу
{
	global $db;

	$rows = $db->selectWhere(objects, new SimpleWhereClause(OBJ_ID, '=', $id));
	return $rows[0][1];
}

function objects_ignore($id) //добавляем файл в игнорируемые
{
	global $db;

	$db->updateSetWhere(objects, array(OBJ_STATUS => '2'), new SimpleWhereClause(OBJ_ID, '=', $id));

	die(1);
}

function autopilots_add_time($autotype) //помечаем последнее время выполнения скрипта
{
	global $db;
	$nt = date('d-m-Y H:i:s',time());
	$db->updateSetWhere(pilots, array(AP_DATE => $nt), new SimpleWhereClause(AP_TYPE, '=', $autotype));
}

function autopilots_get_time($autotype) //получаем последнее время запуска автопилота
{
	global $db;
	$rows = $db->selectWhere(pilots, new SimpleWhereClause(AP_TYPE, '=', $autotype));
	if(isset($rows[0][3]))
		return $rows[0][3];
	else
		return "-:- -.-.-";
}

function notifiers_add($link, $title, $date, $status) //добавляем уведомления
{
	global $db;

	$rows = $db->selectUnique(notifiers, N_LINK, $link);

	if(empty($rows))
	{
		$new_not[N_ID] = 0;
		$new_not[N_LINK] = $link;
		$new_not[N_TITLE] = $title;
		$new_not[N_DATE]  = $date;
		$new_not[N_STATUS]  = 0;

		$newId = $db->insertWithAutoId(notifiers, N_ID, $new_not);
	}
}

function notifiers_get($status = 0) //получаем уведомления
{
	global $db;

	$rows = $db->selectWhere(notifiers, new SimpleWhereClause(N_STATUS, '=', $status));
	return $rows;
}

function notifiers_delete($id) //убираем из видимых уведомления
{
	global $db;

	$db->updateSetWhere(notifiers, array(N_STATUS => '1'), new SimpleWhereClause(N_ID, '=', $id));

	die(1);
}

function get_alert_stat($criticality) //берем данные для построени графика
{
	global $db;

	$alerts = new AndWhereClause();
	$alerts->add(new SimpleWhereClause(OBJ_CRITICALITY, '=', $criticality, INTEGER_COMPARISON));
	$alerts->add(new SimpleWhereClause(OBJ_TIME, '>',  mktime('0','0','0', date("m"), date("d")-'30', date("Y")), INTEGER_COMPARISON));
	$result = $db->selectWhere(objects, $alerts);

	$stat_array = array();
	for($i = 0; $i < 30; $i++)
	{
		$stat_array[$i][0] = date('d-m-Y', mktime('0','0','0', date("m"), date("d")-(string)(30 - $i), date("Y")));
		$stat_array[$i][1] = 0;
	}

	foreach ($result as $stats)
	{
		for($ii = 0; $ii < 30; $ii++)
			if (($stat_array[$ii][0]) == (date('d-m-Y', $stats[6])))
				$stat_array[$ii][1] = $stat_array[$ii][1] + 1;
	}

	return $stat_array;
}

function to_log($id)
{
	global $db;
	$log_dir = 'datas/log';
	switch($id) {
		case 0: $log = 'Сохранение настроек'; break;
		case 1: $log = 'Автопилот: мониторинг файлов сайта'; break;
		case 2: $log = 'Автопилот: бекапинг файлов'; break;
		case 3: $log = 'Автопилот: проверка сайта глазами десктопных антивирусов'; break;
		case 4: $log = 'Автопилот: мониторинг базы данных сайта'; break;
		case 5: $log = 'Автопилот: бекапинг базы данных'; break;
		case 6: $log = 'Автопилот: проверка сайта глазами поисковых систем'; break;
		case 7: $log = 'Пользователь '.SANTI_NAME.' вошел в систему'; break;
		case 8: $log = 'Удаление устаревших бекапов'; break;
		case 9: $log = 'Автоматическое восстановление антивируса'; break;
	}

	$new_event[E_ID] = 0;
	$new_event[E_DATE] = date('d-m-Y');
	$new_event[E_TIME] = date('H:i:s');
	$new_event[E_EID]  = $id;

	$newId = $db->insertWithAutoId(events, E_ID, $new_event);
}

function l($txt)
{
	global $_LANG;
	
	if(isset($_LANG) && array_key_exists($txt, $_LANG))
		return $_LANG[$txt];
	return $txt;
}
