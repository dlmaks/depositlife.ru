<?php

/** Статус файлового сканера */
define('STATUS_FILES', true);

/** Периодичность запуска**/
define('CRON_FILES', 3);

/** Статус сканера БД**/
define('STATUS_DB', false);

/** Периодичность сканирования БД */
define('CRON_DB', 3);

/** Статус бекапинга */
define('STATUS_BU', false);

/** Бекапить ли в Yandex.DISK? */
define('CLOUDDISK_BU', false);

/** Периодичность бекапинга */
define('CRON_BU', 6);

/** Статус бекапинга БД */
define('STATUS_BUD', false);

/** Бекапить ли БД в Yandex.DISK? */
define('CLOUDDISK_BUD', false);

/** Периодичность бекапинга БД */
define('CRON_BUD', 6);

/** Статус проверки в ПС */
define('STATUS_SECH', true);

/** Сообщать ли о новых страницах в поиске */
define('ALERT_SECH', false);

/** Периодичность проверки ПС */
define('CRON_SECH', 3);

/** Статус браузерной проверки */
define('STATUS_BRCH', true);

/** Периодичность браузерной проверки */
define('CRON_BRCH', 3);

?>