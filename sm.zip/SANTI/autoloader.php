<?php

function autoload($file)
{
	$search_dir = 'classes';

	if(!(boolean)SANTI_PATH || !(boolean)SANTI_SERVERPATH) {
		preg_match('/(.*)\/[^\/]+$/', __FILE__, $m);
		$dir = $m[1];
	} else $dir = SANTI_SERVERPATH.'/'.SANTI_PATH;

	$file = str_replace('\\', '/', $file);
	$path = $dir.'/'.$search_dir;
	$filepath = $dir.'/'.$search_dir.'/'.$file.'.php';

	if (file_exists($filepath))
	{
		require_once($filepath);
	}
	else
	{ 
		$flag = true;
		recursive_autoload($file, $path, $flag);
	}
}

function recursive_autoload($file, $path, $flag)
{
	if (false !== ($handle = opendir($path)) && $flag)
	{
		while (false !== ($dir = readdir($handle)) && $flag)
		{
			if (strpos($dir, '.') === false)
			{
				$path2 = $path .'/' . $dir;
				$filepath = $path2 . '/' . $file . '.php';
				if (file_exists($filepath))
				{
					$flag = false;
					require($filepath);
					break;
				}
			recursive_autoload($file, $path2, $flag); 
			}
		}
		closedir($handle);
	}
}

spl_autoload_register('autoload');
