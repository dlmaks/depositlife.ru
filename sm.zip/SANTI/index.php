<?php

/** Режим отладки**/
define('ST_DEBUG', false);

if(ST_DEBUG)
{
    error_reporting(E_ALL | E_STRICT) ;
    ini_set('display_errors', 'On');
    ini_set('error_log', 'datas/errors.log');
}
else
{
    error_reporting(0);
}

if (!isset($_SESSION)) session_start();

require_once("config.php"); 
require_once("autoloader.php");
require_once("autoconfig.php");
require_once("lib/functions.php");
require_once("controllers/database.php");
$language = SANTI_LANG;
if(isset($_GET['lang'])) {
    $language = addslashes(htmlspecialchars(strip_tags(trim($_GET['lang']))));
}

if(file_exists('lang/'.$language.'.php'))
	require_once('lang/'.$language.'.php');
else
	$_LANG = array();

header('Content-Type: text/html; charset=utf-8');

$utils = array('auth','autocron','autosech','autosettings','backup','blocker','cleaner',
	'database','datefinder','file_editor','ftpacc','generator','news','phpinfo','scanfiles',
	'settings','smsbalance','clearnotifi','gettoken','testhost','cloudsettings');

if((isset($_GET['util'])) && (in_array($_GET['util'], $utils)))
{
	require_once('controllers/'.htmlspecialchars(addslashes($_GET['util'])).'.php');
	exit();
}
elseif(isset($_GET['auth_callback']))
{
    header("Location: ?util=gettoken&auth_callback=1&oauth_token=".htmlspecialchars(addslashes($_GET['oauth_token']))."&uid=".htmlspecialchars(addslashes($_GET['uid'])));
    exit();
}
elseif(isset($_GET['code']))
{
    header("Location: ?util=gettoken&code=".htmlspecialchars(addslashes($_GET['code'])));
    exit();
}

if(file_exists('install.php'))
{    
    require_once("install.php");
    exit;
}

$force = 0;
if(isset($_GET['force'])) $force = addslashes(htmlspecialchars(strip_tags(trim($_GET['force']))));

if(isset($_GET['cron'])) {
	switch($_GET['cron'])
	{
		case 'autobu':
			if(STATUS_BU || $force)
            {
                require_once('lib/check_backup.php');
				require_once('lib/autobu.php');
            }
			exit;
		case 'autosech':
			if(STATUS_SECH || $force)
				require_once('lib/autosech.php');
			exit;
		case 'avscan':
			if(STATUS_BRCH || $force)
				require_once('lib/avscan.php');
			exit;
		case 'dbbackup':
			if(STATUS_BUD || $force)
				require_once('lib/dbbackup.php');
			exit;
		case 'scandb':
			if(STATUS_DB || $force)
				require_once('lib/scandb.php');
			exit;
		case 'scanfiles':
			if(STATUS_FILES || $force)
				require_once('lib/scanfiles.php');
			exit;
		case 'selfdefense':
			require_once('lib/selfdefense.php');
			exit;
		case 'check_backup':            
			require_once('lib/check_backup.php');
			exit;
	}
}

if(isset($_GET['page'])) 
    $page = htmlspecialchars(addslashes($_GET['page'])); 
else
    $page = 1;

if (!isset($_SESSION['auth']))
    $page = 0;
elseif((!isset($page)) && ($page > 20))
    $page = 1;

if((($page != 0) && (SANTI_START != "0")) && ($page != 20))
    $page=19;

switch ($page)
{
    case "0":
    {
        $title = ' | '.l('Login');
        include ("templates/header.tpl.php");
        include ("templates/login.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "1":
    {
        $title = ' | '.l('Dashboard');
        define('AFILETIME', autopilots_get_time(1)); //файловый автопилот
        define('ADBTIME', autopilots_get_time(2)); //автопилот скана бд
        define('ABUTIME', autopilots_get_time(3)); //автопилот бекапинга файлов
        define('ASECHTIME', autopilots_get_time(4)); //автопилот проверки ПС
        define('AAVSTIME', autopilots_get_time(5)); //автопилот проверки по AV
        define('ABUDTIME', autopilots_get_time(7)); //автопилот бекапинга БД
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/main.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "121":
    {
        $title = ' | '.l('Utils').' | Редактор файлов';
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_feditor.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "13":
    {
        $title = ' | '.l('Utils').' | '.l('Password generator');
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_gen.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "14":
    {
        $title = ' | '.l('Utils')." | Сканер прав папок и файлов";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_chmod.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "15":
    {
        $title = ' | '.l('Utils').' | '.l('.ftpaccess configurator');
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_ftpacc.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "16":
    {
        $title = ' | '.l('Utils')." | Бекап";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_bu.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "161":
    {
        $title = ' | '.l('Utils')." | Блокиратор сайта";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_block.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "162":
    {
        $title = ' | '.l('Utils')." | Date-поиск файлов";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_fsearch.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "163":
    {
        $title = ' | '.l('Utils')." | Поиск и удаление вредоносных вставок";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_cleaner.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "17":
    {
        $title = ' | '.l('Utils').' | '.l('PHP info');
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_phpinfo.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "18":
    {
        $title = ' | '.l('Utils')." | Новости уязвимостей";
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/utils_news.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "19":
    {
        $title = ' | '.l('Settings');
        include ("templates/header.tpl.php");
        include ("templates/top_menu.tpl.php");
        include ("templates/settings.tpl.php");
        include ("templates/footer.tpl.php");
    } exit;
    case "20":
    {
        unset($_SESSION['auth']);
        unset($_SESSION['last_page']);
        session_destroy();
        header('Location: http://'.$_SERVER['HTTP_HOST'].substr($_SERVER['REQUEST_URI'],0,strpos($_SERVER['REQUEST_URI'],'?')));
    } exit;
    default:
    {
        $title = ' | '.l('Login');
        include ("templates/header.tpl.php");
        include ("templates/login.tpl.php");
        include ("templates/footer.tpl.php");
    }
    exit;
}

?>


