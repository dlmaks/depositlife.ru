<?php if(!defined('SANTI_NAME')) die('Access denied'); ?>

<input type="hidden" id="firststart" value="<?php echo SANTI_START ?>">
    <!-- WIDGETS -->

    <!-- Masks -->
    <script type="text/javascript" src="templates/js/widgets/input-mask/inputmask.js"></script>

    <!-- Bootstrap Dropdown -->
    <script type="text/javascript" src="templates/js/widgets/dropdown/dropdown.js"></script>

    <!-- Bootstrap Tooltip -->
    <script type="text/javascript" src="templates/js/widgets/tooltip/tooltip.js"></script>

    <!-- Bootstrap Popover -->
    <script type="text/javascript" src="templates/js/widgets/popover/popover.js"></script>

    <!-- Input switch alternate -->
    <script type="text/javascript" src="templates/js/widgets/input-switch/inputswitch-alt.js"></script>
    <script type="text/javascript" src="templates/js/widgets/input-switch/inputswitch.js"></script>

    <!-- Slim scroll -->
    <script type="text/javascript" src="templates/js/widgets/slimscroll/slimscroll.js"></script>

    <!-- Screenfull -->
    <script type="text/javascript" src="templates/js/widgets/screenfull/screenfull.js"></script>

    <!-- Widgets init -->
    <script type="text/javascript" src="templates/js/widgets-init.js"></script>

    <!-- Data tables -->
    <script type="text/javascript" src="templates/js/widgets/datatable/datatable.js"></script>
    <script type="text/javascript" src="templates/js/widgets/datatable/datatable-bootstrap.js"></script>
    <script type="text/javascript" src="templates/js/widgets/datatable/datatable-responsive.js"></script>

    <!-- Date picker -->
    <script type="text/javascript" src="templates/js/widgets/datepicker/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="templates/js/widgets/datepicker/bootstrap-datepicker.ru.js"></script>

    <!-- Wizard -->
    <script type="text/javascript" src="templates/js/widgets/wizard/wizard.js"></script>

    <!-- Tabs -->
    <script type="text/javascript" src="templates/js/widgets/tabs/tabs.js"></script>

    <!-- Noty -->
    <script type="text/javascript" src="templates/js/widgets/noty-notifications/noty.js"></script>
    
    <!-- Theme layout -->
    <script type="text/javascript" src="templates/js/layout.js"></script>

    <!-- Bootstrap Modal -->
    <script type="text/javascript" src="templates/js/widgets/modal/modal.js"></script>
    <script type="text/javascript" src="templates/js/md5-min.js"></script>
    <script type="text/javascript" src="templates/js/jquery.blockUI.js"></script>

    <script type="text/javascript" src="templates/js/gsav.js"></script>
</body>
</html>