<?php if(!defined('SANTI_NAME')) die('Access denied'); ?>

	<style type="text/css">

	    html,body {
	        height: 100%;
	        background: #fff;
	        overflow: hidden;
	    }

	</style>

	<div id="loading">
	    <div class="spinner">
	        <div class="bounce1"></div>
	        <div class="bounce2"></div>
	        <div class="bounce3"></div>
	    </div>
	</div>

    <div class="center-vertical">
        <div class="center-content">

            <div class="col-md-3 center-margin">

                <form id="login_form">
                    <div class="content-box wow bounceInDown modal-content">
                        <div style="padding: 15px 0px 0px 9px;">
                            <img src="templates/images/logo.png">
                        </div>
                        <div class="content-box-wrapper">
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="login" class="form-control" id="login" name="login" placeholder="<?= l('Username') ?>">
                                    <span class="input-group-addon bg-blue">
                                        <i class="glyph-icon icon-user"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="<?= l('Password') ?>">
                                    <span class="input-group-addon bg-blue">
                                        <i class="glyph-icon icon-unlock-alt"></i>
                                    </span>
                                </div>
                            </div>                            
                            <div class="form-group" id="error">
                                <a href="http://forum.santivi.com/viewtopic.php?id=24" title="<?= l('Recover password') ?>" target="_blank"><?= l('Forgot your password?') ?></a>
                            </div>
                            <input type="hidden" name="language" id="language" value="<?= SANTI_LANG ?>">
                            <input type="submit" class="btn btn-info" value="<?= l('Log in') ?>">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>