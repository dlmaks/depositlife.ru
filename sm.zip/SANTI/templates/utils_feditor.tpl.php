<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Просмотрщик файлов</h2>
                        <p></p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="generator" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">Укажите кодировку файла:</label>
                                    <div class="col-sm-6">
                                        <?php

                                            if(isset($_GET['encode'])) 
                                                $cursel = $_GET['encode']; 
                                            else 
                                                $cursel = 0; 

                                            $error = false;
                                            function my_error_handler($code, $msg, $file, $line) 
                                            {global $error; $error = true;}

                                            set_error_handler('my_error_handler');

                                            $fencode = "utf-8";

                                            if (isset($_GET['file_id']))
                                            {
                                                $file_path = get_objects_path($_GET['file_id']);

                                                if (isset($_GET['encode']))
                                                    switch ($_GET['encode']) {
                                                        case 0:
                                                                $fencode = "utf-8";
                                                            break;
                                                        case 1:
                                                                $fencode = "windows-1251";
                                                            break;
                                                        case 2:
                                                                $fencode = "koi-8";
                                                            break;
                                                        case 3:
                                                                $fencode = "windows-1251";
                                                            break;
                                                    }
                                                $file = htmlspecialchars(file_get_contents($file_path));
                                                $file_conv = iconv($fencode, 'utf-8', $file);
                                                if((!$error) && ($fencode != "utf-8")) $file = $file_conv; else if((!$error) && ($fencode == "utf-8")) {} else $file = "задайте верную кодировку";
                                            }
                                            else 
                                            {
                                                $file_path='';
                                                $file = 'Файл не указан';
                                            }                                        
                                    
                                        ?>
                                        <select class="form-control" name="encoding" id="encoding" onchange="window.location.replace('<?php echo  SANTI_URL."/".SANTI_PATH."/index.php?page=121&file_id=".$_GET['file_id'];?>'+'&encode='+this.selectedIndex);">                                        
                                            <option value="0" <?php if($cursel == 0) echo "selected"; ?>>utf-8</option>
                                            <option value="1" <?php if($cursel == 1) echo "selected"; ?>>windows-1251</option>
                                            <option value="2" <?php if($cursel == 2) echo "selected"; ?>>koi-8</option>
                                            <option value="3" <?php if($cursel == 3) echo "selected"; ?>>ANSI</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <!--<div class="col-sm-3"><input type="" value="Сохранить"  class="btn btn-warning" <?php if($error) echo "DISABLED"; ?>></div>-->
                                    <div class="col-sm-12">
                                        <div id="editor" class="" style="height: 300px;"><?= $file; ?></div>        
                                        <input type="hidden" id="fileid" value="<?php if(isset($_GET['file_id'])) echo $_GET['file_id'] ?>">
                                    </div>
                                </div>

                                <script src="templates/js/widgets/ace/ace.js" type="text/javascript" charset="utf-8"></script>
                                <script>
                                    var editor = ace.edit("editor");
                                    var Range = ace.require("ace/range").Range;
                                    editor.setTheme("ace/theme/chrome");                                    
                                    
                                    <?php

                                        $extension = pathinfo($file_path, PATHINFO_EXTENSION);
                                        //подсветка вредоноса
                                        $select_start = addslashes('include ("templates/main.tpl.php");');
                                        $select_end = '';
                                        //подсветка вредоноса

                                        switch ($extension) {
                                            case 'php':
                                                echo 'editor.getSession().setMode("ace/mode/php");';
                                                break;
                                            case 'js':
                                                echo 'editor.getSession().setMode("ace/mode/javascript");';
                                                break; 
                                            case 'css':
                                                echo 'editor.getSession().setMode("ace/mode/css");';
                                                break;
                                            case 'html':
                                                echo 'editor.getSession().setMode("ace/mode/html");';
                                                break; 
                                            case 'htm':
                                                echo 'editor.getSession().setMode("ace/mode/html");';
                                                break;
                                            case 'sql':
                                                echo 'editor.getSession().setMode("ace/mode/sql");';
                                                break;
                                            case 'xml':
                                                echo 'editor.getSession().setMode("ace/mode/xml");';
                                                break;
                                            case 'pl':
                                                echo 'editor.getSession().setMode("ace/mode/perl");';
                                                break; 
                                            default:
                                                echo 'editor.getSession().setMode("ace/mode/text");';
                                                break;
                                        }

                                        if($select_start != "")
                                        {
                                            if($select_end == "")
                                            {
                                                $select_start = 'include ("templates/header.tpl.php");';
                                    ?>
                                                
                                                var range = editor.findAll('<?php echo $select_start ?>', {
                                                    backwards:  false,
                                                    wrap: false,
                                                    caseSensitive: false,
                                                    wholeWord: false,
                                                    regExp: false
                                                });

                                                for(var counter = 0; counter < range; counter++)
                                                {
                                                    //editor.getSession().addMarker(editor.selection.ranges[counter], "warning", "virus");
                                                }                                                                

                                    <?php
                                            }
                                        }

                                    ?>                                                    
                                </script>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    