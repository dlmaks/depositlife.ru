<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Генератор паролей</h2>
                        <p>Утилита для генерации пароля по заданным параметрам</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="generator" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">Укажите длину пароля:</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="passlength" id="passlength" class="form-control" onkeyup = 'this.value=parseInt(this.value) | 0'>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Укажите тип пароля:</label>
                                    <div class="col-sm-6">
                                        <select class="form-control" name="passtype" id="passtype" >
                                            <option value="1">Любые символы в любом регистре</option>                                                                
                                            <option value="3">Буквы+цифры в верхнем и нижнем регистрах</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Результат генерации:</label>
                                    <div class="col-sm-6">
                                        <h3 id="result"></h3>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-6"><input type="submit" value="Сгенерировать" class="btn btn-warning"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    