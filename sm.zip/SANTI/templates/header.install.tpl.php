<?php if(!defined('SANTI_NAME')) die('Access denied'); ?>
<!DOCTYPE html>
<html lang="ru">
<head>

    <style>
        /* Loading Spinner */
        .spinner{margin:0;width:70px;height:18px;margin:-35px 0 0 -9px;position:absolute;top:50%;left:50%;text-align:center}.spinner > div{width:18px;height:18px;background-color:#333;border-radius:100%;display:inline-block;-webkit-animation:bouncedelay 1.4s infinite ease-in-out;animation:bouncedelay 1.4s infinite ease-in-out;-webkit-animation-fill-mode:both;animation-fill-mode:both}.spinner .bounce1{-webkit-animation-delay:-.32s;animation-delay:-.32s}.spinner .bounce2{-webkit-animation-delay:-.16s;animation-delay:-.16s}@-webkit-keyframes bouncedelay{0%,80%,100%{-webkit-transform:scale(0.0)}40%{-webkit-transform:scale(1.0)}}@keyframes bouncedelay{0%,80%,100%{transform:scale(0.0);-webkit-transform:scale(0.0)}40%{transform:scale(1.0);-webkit-transform:scale(1.0)}}
    </style>

    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title><?= l('SANTI - website antivirus'); echo $title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="Антивирус для сайта Санти">
    <meta name="author" content="Игорь Митрофанов">
    <meta name="robots" content="noindex" />

    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <link href='http://fonts.googleapis.com/css?family=Cousine:400,400italic,700,700italic&subset=cyrillic-ext,latin' rel='stylesheet' type='text/css'>

    <!-- HELPERS -->
    <link rel="stylesheet" type="text/css" href="templates/css/backgrounds.css">
    <link rel="stylesheet" type="text/css" href="templates/css/boilerplate.css">
    <link rel="stylesheet" type="text/css" href="templates/css/grid.css">
    <link rel="stylesheet" type="text/css" href="templates/css/typography.css">
    <link rel="stylesheet" type="text/css" href="templates/css/utils.css">
    <link rel="stylesheet" type="text/css" href="templates/css/colors.css">

    <!-- ELEMENTS -->
    <link rel="stylesheet" type="text/css" href="templates/css/elements/buttons.css">
    <link rel="stylesheet" type="text/css" href="templates/css/elements/content-box.css">
    <link rel="stylesheet" type="text/css" href="templates/css/elements/forms.css">
    <link rel="stylesheet" type="text/css" href="templates/css/elements/menus.css">
    <link rel="stylesheet" type="text/css" href="templates/css/elements/tables.css">

    <!-- ICONS -->
    <link rel="stylesheet" type="text/css" href="templates/css/fontawesome/fontawesome.css">

    <!-- WIDGETS -->
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/datatable/datatable.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/dialog/dialog.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/dropdown/dropdown.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/input-switch/inputswitch.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/input-switch/inputswitch-alt.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/jgrowl-notifications/jgrowl.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/modal/modal.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/tooltip/tooltip.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/popover/popover.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/wizard/wizard.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/datepicker/datepicker.css">
    <link rel="stylesheet" type="text/css" href="templates/css/widgets/noty-notifications/noty.css">
    

    <!-- SNIPPETS -->
    <link rel="stylesheet" type="text/css" href="templates/css/notification-box.css">

    <!-- theme -->
    <link rel="stylesheet" type="text/css" href="templates/css/layout.css">
    <link rel="stylesheet" type="text/css" href="templates/css/color-schemes/default.css">
    <link rel="stylesheet" type="text/css" href="templates/css/components/default.css">
    <link rel="stylesheet" type="text/css" href="templates/css/border-radius.css">

    <!-- responsive -->
    <link rel="stylesheet" type="text/css" href="templates/css/responsive-elements.css">
    <link rel="stylesheet" type="text/css" href="templates/css/admin-responsive.css">

    <!-- JS Core -->
    <script type="text/javascript" src="templates/js/jquery-core.js"></script>
    <script type="text/javascript" src="templates/js/jquery-ui-core.js"></script>
    <script type="text/javascript" src="templates/js/jquery-ui-widget.js"></script>
    <script type="text/javascript" src="templates/js/jquery-ui-mouse.js"></script>
    <script type="text/javascript" src="templates/js/jquery-ui-position.js"></script>

    <script type="text/javascript">
        $(window).load(function(){
            setTimeout(function() {
                $('#loading').fadeOut( 400, "linear" );
            }, 300);
        });
    </script>

    <?php echo '<script type="text/javascript" src="lang/'.$language.'.js"></script>'; ?>

</head>
<body class="closed-sidebar boxed-layout full-bg-2 fixed-bg">
<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
<div>
    <div id="loading">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>

    <div id="page-wrapper">
        <!-- header -->
        <div id="page-header" class="bg-gradient-2">
            <div id="header-logo" class="logo-bg">
                <a href="index.php" class="logo-content-big" title="<?= l('SANTI')?>">
                </a>
                <a href="index.php" class="logo-content-small" title="<?= l('SANTI')?>">
                </a>
            </div>

            <!-- header-nav-left -->
            <div id="header-nav-left">                
            </div>
            <!-- #header-nav-left -->

            <!-- top menu -->
            <div id="header-nav-right">                    
            </div>
            <!-- #header-nav-right -->
        </div>
        <!-- #header --> 