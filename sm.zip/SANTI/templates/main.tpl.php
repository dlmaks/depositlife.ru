<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <!--<div id="page-title">
                        <h2>Пульт управления</h2>
                    </div>-->

                    <div class="panel">
                        <div class="panel-body">
                            <h3 style="margin: 0px 0px 15px;">
                                Уведомления от автопилотов
                            </h3>
                            <div>
                                <table id="datatable-alerts" class="dataTables table table-striped table-bordered responsive no-wrap" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>№</th>
                                        <th>Критичность</th>
                                        <th>Объект</th>
                                        <th>Тип</th>
                                        <th>Дата</th>
                                        <th>Действия</th>
                                    </tr>
                                    </thead>

                                    <tfoot>
                                    <tr>
                                        <th>№</th>
                                        <th>Критичность</th>
                                        <th>Объект</th>
                                        <th>Тип</th>
                                        <th>Дата время</th>
                                        <th>Действия</th>
                                    </tr>
                                    </tfoot>

                                    <tbody>
                                    <?php
                                        $obj_rows = objects_get();
                                        foreach($obj_rows as $rows)
                                        {
                                            $alert_type = get_alert_type($rows[2]);
                                            $alert_criticality = get_alert_criticality($rows[4]);
                                            $alert_status = get_alert_status($rows[5]);
                                            $actions_block = '';
                                            if($rows[5] == 0 && $rows[2]!=17 &&
                                                                $rows[2]!=18 &&
                                                                $rows[2]!=19 &&
                                                                $rows[2]!=20 &&
                                                                $rows[2]!=21)
                                            {
                                                $actions_block = '
                                                <select class="form-control" style="border: none; box-shadow: none; min-width: 89px;">                                                    
                                                    <option value="3" selected>выбрать</option>
                                                    <option value="4" onclick="object_healed('.$rows[0].');">не показывать</option>
                                                    <option value="5" onclick="alert(\'не доступно\')">проверить</option>
                                                    <option value="6" onclick="object_ignore('.$rows[0].')">игнорировать</option>
                                                </select>';
                                            }
                                            elseif($rows[5] == 1)
                                            {
                                                $actions_block = '<span style="display: inline-block; float: right;">не показывается&nbsp;&nbsp;
                                                <a  style="cursor: pointer;" onclick="object_null('.$rows[0].');" class="tips" title="отменить">
                                                <i class="glyph-icon font-orange icon-refresh"></i></a></span>';
                                            }
                                            elseif($rows[5] == 2)
                                            {
                                                $actions_block = '<span style="display: inline-block; float: right;">игнорируется&nbsp;&nbsp;
                                                <a style="cursor: pointer;" onclick="object_null('.$rows[0].');" class="tips" title="отменить">
                                                <i class="glyph-icon font-orange icon-refresh"></i></a></span>';
                                            }

                                            if(($rows[5] != 1) && ($rows[5] != 2))
                                            {
                                                echo '<tr style="height: 30px !important;">
                                                    <td>'.$rows[0].'</td>
                                                    <td>'.$alert_criticality.'</td>
                                                    <td><div id="file_'.$rows[0].'">'.str_replace("\\", "/", $rows[1]).'</div><div>'.$rows[3].'</div></td>
                                                    <td>'.$alert_type.'</td>
                                                    <td>'.date('d-m-Y H:i:s', $rows[6]).'</td>
                                                    <td class="center" id="action_'.$rows[0].'">'.$actions_block.'</td>
                                                </tr>';
                                            }
                                        }
                                    ?>                                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <h3 style="margin: 0px 0px 15px;">
                                Автопилоты <?php if(SANTI_CRON_HAND) echo "(активирован локальный CRON)"; ?>
                            </h3>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="content-box border-top border-red">
                                            <div>
                                                <h3 class="content-box-header clearfix" style="display: inline-block;">Мониторинг файлов сайта</h3>
                                                <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_files" name="status_files" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_FILES) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл"></span>
                                            </div>
                                            <div class="content-box-wrapper">                                                
                                                <label class="control-label">Последнее выполнение:</label><?php echo AFILETIME;?> <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="run_auto('scanfiles'); return false;" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                                <div class="divider"></div>
                                                <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=scanfiles&dosf=1";?>
                                            </div>
                                            <input type="hidden" name="cron_files" id="cron_files" value="3">
                                    </div>

                                    <div class="content-box border-top border-yellow">
                                        <div>
                                            <h3 class="content-box-header clearfix" style="display: inline-block;">Настольные антивирусы</h3>
                                            <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_brch" name="status_brch" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_BRCH) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл"></span>
                                        </div>
                                        <div class="content-box-wrapper">
                                            <label class="control-label">Последнее выполнение:</label><?php echo AAVSTIME;?> <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="run_auto('avscan'); return false;" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                            <div class="divider"></div>
                                            <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=avscan";?>
                                        </div>
                                        <input type="hidden" name="cron_brch" id="cron_brch" value="3">
                                    </div>

                                    <div class="content-box border-top border-green">
                                        <div>
                                            <h3 class="content-box-header clearfix" style="display: inline-block;">Резервное копирование файлов</h3>
                                            <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_bu" name="status_bu" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_BU) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл"></span>
                                        </div>
                                        <div class="content-box-wrapper">
                                            <label class="control-label">Частота выполнения:</label>
                                            <select class="form-control" style="width: 50%;" id="cron_bu" name="cron_bu" >
                                                <option value="4" <?php if(CRON_BU == "4") echo "selected"; ?>>Каждые 3 дня</option>
                                                <option value="5" <?php if(CRON_BU == "5") echo "selected"; ?>>Каждую неделю</option>
                                                <option value="6" <?php if(CRON_BU == "6") echo "selected"; ?>>Каждый месяц</option>
                                            </select>
                                            <div class="divider"></div>
                                            <label class="control-label">Последнее выполнение:</label><?php echo ABUTIME;?> <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="run_auto('autobu'); return false;" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                            <div class="divider"></div>
                                            <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=autobu";?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">

                                    <div class="content-box border-top border-red razmyt">
                                        <div>
                                            <h3 class="content-box-header clearfix" style="display: inline-block;">Мониторинг базы данных</h3>
                                            <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_db" name="status_db" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_DB) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл" DISABLED></span>
                                        </div>
                                        <div class="content-box-wrapper">
                                            <label class="control-label">Последнее выполнение:</label><?php echo ADBTIME;?> <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="return false; run_auto('scandb')" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                            <div class="divider"></div>
                                            <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=scandb";?>
                                        </div>
                                        <input type="hidden" name="cron_db" id="cron_db" value="3">
                                    </div>

                                    <div class="content-box border-top border-yellow">
                                        <div>
                                            <h3 class="content-box-header clearfix" style="display: inline-block;">Блокировка ПС</h3>
                                            <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_sech" name="status_sech" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_SECH) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл"></span>
                                        </div>                                        
                                        <div class="content-box-wrapper">
                                            <label class="control-label">Последнее выполнение:</label><?php echo ASECHTIME;?> <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="run_auto('autosech'); return false;" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                            <div class="divider"></div>
                                            <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=autosech";?>
                                        </div>
                                        <input type="hidden" name="cron_sech" id="cron_sech" value="3">
                                    </div>

                                    <div class="content-box border-top border-green">
                                        <div>
                                            <h3 class="content-box-header clearfix" style="display: inline-block;">Резервное копирование БД</h3>
                                            <span class="float-right" style="padding: 18px;"><input type="checkbox" id="status_bud" name="status_bud" data-on-color="info" data-size="mini" class="input-switch" <?php if (STATUS_BUD) echo "checked";?> data-on-text="Вкл" data-off-text="Выкл"></span>
                                        </div>
                                        <div class="content-box-wrapper">
                                            <label class="control-label">Частота выполнения:</label>
                                            <select id="cron_bud" name="cron_bud" class="form-control" style="width: 50%;">
                                                <option value="4" <?php if(CRON_BUD == "4") echo "selected"; ?>>Каждые 3 дня</option>
                                                <option value="5" <?php if(CRON_BUD == "5") echo "selected"; ?>>Каждую неделю</option>
                                                <option value="6" <?php if(CRON_BUD == "6") echo "selected"; ?>>Каждый месяц</option>
                                            </select>
                                            <div class="divider"></div>
                                            <label class="control-label">Последнее выполнение:</label><?php echo ABUDTIME;?>  <a href="" style="border:0px; font-size: 14px; color: #308DCC" title="выполнить сейчас" onclick="run_auto('dbbackup'); return false;" > <i class="glyph-icon icon-play-circle-o"></i></a>
                                            <div class="divider"></div>
                                            <label class="control-label">Ссылка:</label><?php echo SANTI_URL."/".SANTI_PATH."/?cron=dbbackup";?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--модальное окно диалога -->
    <div class="modal fade bs-example-modal-sm" id="alert_dialog" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Предупреждение</h4>
                </div>
                <div class="modal-body">
                    <p>Все уведомления будут удалены</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
                    <button type="button" class="btn btn-primary" id="clear_notifi" data-dismiss="modal">Продолжить</button>
                </div>
            </div>
        </div>
    </div>
    <!-- конец модального окна диалога -->    