<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>.ftpaccess конфигуратор</h2>
                        <p>Утилита для формирования файла .ftpaccess</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="ftpa" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-4">
                                        <input type="radio" id="choose" name="choose" value="deny_all" checked="checked">&nbsp;запрет доступа всем
                                    </label>
                                    <div class="col-sm-8">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4">
                                        <input type="radio" id="choose" name="choose" value="deny_ip">&nbsp;запрет доступа для IP:
                                    </label>
                                    <div class="col-sm-5">
                                        <textarea class="form-control" placeholder="ip адреса через точку с запятой" name="dip" id="dip" value="" ></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4">
                                        <input type="radio" id="choose" name="choose" value="allow_ip">&nbsp;разрешить доступ для IP:
                                    </label>
                                    <div class="col-sm-5">
                                        <textarea name="aip" id="aip" value="" placeholder="ip адреса через точку с запятой" class="form-control"></textarea><br>ваш IP адрес: <b><? echo $_SERVER["REMOTE_ADDR"];?></b>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-5">
                                        <input type="checkbox" name="deny_rewrite" id="deny_rewrite" value="rewrite">&nbsp;запретить перезапись существующих файлов
                                    </label>
                                    <div class="col-sm-7">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-2"><input type="submit" value="Сгенерировать" class="btn btn-warning"></div>
                                    <div class="col-sm-8">
                                        <textarea name="result" id="result" rows="7" value="" placeholder="здесь появится содержимое для файла .ftpaccess. Создайте файл в дирректории куда подлючает вас ftp и вставьте в него сгенерированное содержимое." class="form-control"></textarea>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    