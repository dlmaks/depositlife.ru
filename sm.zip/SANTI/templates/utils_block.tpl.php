<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Блокировка сайта</h2>
                        <p>Временная блокировка сайта на время восстановления или профилактики</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="blocker" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">
                                        Текущее состояние блокировки:
                                    </label>
                                    <div class="col-sm-9" id="blockstate" style="padding-top: 7px"></div>
                                </div>
                                <?php
                                    if(is_file('../.htaccess.bak'))
                                        echo '<div id="excl_ip" class="form-group" style="display: none">';
                                    else
                                        echo '<div id="excl_ip" class="form-group">';
                                ?>
                                    <label class="col-sm-3 control-label">
                                        IP исключения:
                                    </label>
                                    <div class="col-sm-6">
                                        <input type="text" id="exclude_ip" name="exclude_ip" value="" class="form-control">
                                    </div>
                                </div>                                
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-9">
                                        <input type="hidden" name="do" id="do" value="">
                                        <input type="submit" value="" class="btn btn-warning" id="blockBtn">
                                    </div>
                                </div>
                            </form>
                            <script type="text/javascript">
                                $(document).ready(function()
                                    {
                                        checkBlock();
                                    }
                                )                                
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    