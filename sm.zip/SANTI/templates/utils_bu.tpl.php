<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Бекап и восстановление</h2>
                        <p>Инструмент для бекапинга/восстановления файлов интернет-проекта</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">Выберите действие:</label>
                                    <div class="col-sm-6">
                                        <select class="form-control" name="dobu" id="dobu">
                                            <option value="1" selected>Бекапим</option>
                                            <option value="2">Восстанавливаем</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group" id="bunameblock">
                                    <label class="col-sm-3 control-label">Имя бекапа:</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="arhname" id="arhname" value="<?php echo "santi_bu_".date('Y-m-d_H-i').".zip"?>" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label" id="startpathlbl">С какой папки бекапим:</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" type="text" name="startpath" id="startpath" value="<?php echo SANTI_SERVERPATH?>">
                                    </div>
                                </div>
                                <div class="form-group" id="stoppathblock">
                                    <label class="col-sm-3 control-label">Исключить папки, файлы:</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" type="text" name="stoppath" id="stoppath" value="<?php echo SANTI_STOPB ?>">
                                    </div>
                                </div>
                                <div class="form-group" id="rasshblock">
                                    <label class="col-sm-3 control-label">Только с расширением:</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" type="text" name="rassh" id="rassh" value="">
                                    </div>
                                </div>
                                <div class="form-group" id="maxsizeblock">
                                    <label class="col-sm-3 control-label">Не более (байт):</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" type="text" name="maxsize" id="maxsize" value="">
                                    </div>
                                </div>
                                <div class="form-group" id="bufsblock" style="display: none;">
                                    <label class="col-sm-3 control-label">Существующие бекапы:</label>
                                    <div class="col-sm-6">
                                        <select name="bufile" id="bufile" class="form-control">
                                            <?php

                                                $filenamecount = glob('datas/backups/*.zip')?glob('datas/backups/*.zip'):array();
                                                if (count($filenamecount) > 0) 
                                                {
                                                    foreach ($filenamecount as $filenamele) 
                                                    {
                                                        if (is_readable($filenamele))
                                                        {
                                                            echo '<option value="'.$filenamele.'">'.$filenamele.'</option>';
                                                        }
                                                    }
                                                } 
                                                else if (count($filenamecount) == 1) 
                                                {
                                                    if (is_readable($filenamecount[0])) 
                                                    {
                                                        echo '<option value="'.$filenamecount[0].'">'.$filenamecount[0].'</option>';
                                                    }
                                                } 
                                                
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-6">
                                        <input data-target="#alert_dialog" data-toggle="modal" type="submit" value="Выполнить" class="btn btn-warning" onclick="return false;">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--модальное окно диалога -->
    <div class="modal fade bs-example-modal-sm" id="alert_dialog" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Предупреждение</h4>
                </div>
                <div class="modal-body">
                    <p>Не продолжайте, если не уверены, что правильно заданы все фильтры и папки для бекапа/восстановления. Возможна потеря файлов при восстановлении или нехватка места на сервере после бекапа.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
                    <button type="button" class="btn btn-primary" id="buform" data-dismiss="modal">Продолжить</button>
                </div>
            </div>
        </div>
    </div>
    <!-- конец модального окна диалога -->  