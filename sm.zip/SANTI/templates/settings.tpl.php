<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2><?php if(!file_exists('install.php')) echo l('Settings'); else echo l('Install'); ?></h2>                        
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <div id="wizard-result">                                
                            </div>
                            <?php
                                if (file_exists('install.php'))
                                {
                                    echo "<div style='display:none; color:#FA7753; padding-top:10px; font-size: 14px;' id='install_complete'>Установка завершена. Для продолжения работы удалите файл install.php, затем обновите странцу или перейдите по <a href='index.php'>ссылке</a>. </div>";
                                }
                            ?>
                            <div id="form-wizard">
                                <ul>
                                    <li><a href="#step-0" data-toggle="tab">Тест хостинга</a></li>
                                    <li <? if(!file_exists('install.php')) echo 'class="active"' ?>><a href="#step-1" id="step1" data-toggle="tab" <? if(file_exists('install.php')) echo 'class="disabled"' ?>>Система</a></li>
                                    <li><a href="#step-2" id="step2" data-toggle="tab" class="disabled">Файлы и БД</a></li>
                                    <li><a href="#step-3" id="step3" data-toggle="tab" class="disabled">Личная информация</a></li>
                                    <li><a href="#step-4" id="step4" data-toggle="tab" class="disabled">Информирование</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane form-horizontal bordered-row" id="step-0">
                                        
                                    </div>
                                    <div class="tab-pane form-horizontal bordered-row active" id="step-1">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Логин:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="login" name="regular" value="<?php echo SANTI_NAME ?>" class="validate[required] form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Новый пароль:</label>
                                            <div class="col-sm-9">
                                                <input type="password" id="pwd" name="pwd" value=""  class="validate[required] form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Повторите пароль:</label>
                                            <div class="col-sm-9">
                                                <input type="password" id="pwd1" name="pwd1" value=""  class="validate[required] form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Адрес сайта:</label>
                                            <div class="col-sm-9">
                                                <?php
                                                if (strlen(SANTI_URL))
                                                {
                                                    $url = SANTI_URL;
                                                }
                                                else
                                                {
                                                    $url = 'http://'.preg_replace('/\\\+|\/+/', '/', $_SERVER['SERVER_NAME']);
                                                }
                                                ?>

                                                <input type="text" id="url" name="url" value="<?php echo $url; ?>" class="form-control">
                                                <span class="help-block">Подсказка: обязательно проверьте правильность адреса сайта</span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Имя папки антивируса:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="path" name="path" value="<? if (strlen(SANTI_PATH)) echo SANTI_PATH; else echo $path = str_replace("/", "", dirname($_SERVER['PHP_SELF'])); ?>" class="validate[required] form-control">
                                                <span class="help-block">Подсказка: обязательно проверьте правильность указания папки антивируса</span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Серверный путь к сайту:</label>
                                            <div class="col-sm-9">
                                                <?php
                                                if (strlen(SANTI_SERVERPATH))
                                                {
                                                    $serverpath = SANTI_SERVERPATH;
                                                }
                                                else
                                                {
                                                    getcwd();
                                                    chdir("..");
                                                    $serverpath = preg_replace('/\\\+|\/+/', '/', getcwd());
                                                }
                                                ?>
                                                <input type="text" id="serverpath" name="serverpath" value="<?php echo $serverpath; ?>" class="form-control"/>
                                                <span class="help-block">Подсказка: обязательно проверьте правильность пути к сайту</span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Выбор часового пояса:</label>
                                            <div class="col-sm-9">
                                                <?=get_timezone_select('timezone', defined('SANTI_TIMEZONE')? SANTI_TIMEZONE : '', 'class="form-control"');?>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Ручная настройка CRON для автопилотов:</label>
                                            <div class="col-sm-9">
                                                <input type="checkbox" id="cronhand" name="cronhand" <?php if (SANTI_CRON_HAND) echo "checked"; ?> data-size="small" class="input-switch" data-on-text="Вкл" data-off-text="Выкл">
                                            </div>
                                        </div>
                                        <div class="form-group" style="padding: 0px;">
                                            <label class="col-sm-3 control-label"><!--Автоматическое обновление базы вирусов:--></label>
                                            <div class="col-sm-9">
                                                <!--<input type="checkbox" id="autoupdate" name="autoupdate" <?php if (SANTI_AUTO_UPDATE) echo "checked"; ?> data-size="small" class="input-switch" data-on-text="Вкл" data-off-text="Выкл">-->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane form-horizontal bordered-row" id="step-2">                                        
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Адрес БД:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="addressbd" name="addressbd" value="<?php echo SANTI_DB_HOST ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Имя БД:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="namebd" name="namebd" value="<?php echo SANTI_DB_NAME ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Логин БД:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="loginbd" name="loginbd" value="<?php echo SANTI_DB_USER ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Пароль БД:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="passwordbd" name="passwordbd" value="<?php echo SANTI_DB_PASSWORD ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Кодировка БД:</label>
                                            <div class="col-sm-9">
                                                <select name="cod" id="cod" class="form-control">
                                                    <option value="0" <?php if (SANTI_DB_CHARSET == "0") echo "selected"; ?>>Auto</option>
                                                    <option value="1" <?php if (SANTI_DB_CHARSET == "1") echo "selected"; ?>>UTF-8</option>
                                                    <option value="2" <?php if (SANTI_DB_CHARSET == "2") echo "selected"; ?>>CP-1251</option>
                                                    <option value="3" <?php if (SANTI_DB_CHARSET == "3") echo "selected"; ?>>KOI-8</option>
                                                </select>
                                                <input type="hidden" id="addresskopbd" name="addresskopbd" value="<?php echo SANTI_DBKOP_HOST ?>">
                                                <input type="hidden" id="namekopbd" name="namekopbd" value="<?php echo SANTI_DBKOP_NAME ?>">
                                                <input type="hidden" id="loginkopbd" name="loginkopbd" value="<?php echo SANTI_DBKOP_USER ?>">
                                                <input type="hidden" id="passwordkopbd" name="passwordkopbd" value="<?php echo SANTI_DBKOP_PASSWORD ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Файловое хранилище:</label>
                                            <div class="col-sm-5">
                                                <select name="cloud" id="cloud" class="form-control">
                                                    <option value="none">Нет</option>
                                                    <option value="yandex" <?php if (SANTI_CLOUD == "yandex") echo "selected"; ?>>Яндекс.Диск</option>
                                                    <option value="google" <?php if (SANTI_CLOUD == "google") echo "selected"; ?>>Google Диск</option>
                                                    <option value="dropbox" <?php if (SANTI_CLOUD == "dropbox") echo "selected"; ?>>Dropbox</option>
                                                    <option value="ftp" <?php if (SANTI_CLOUD == "ftp") echo "selected"; ?>>FTP</option>
                                                </select>
                                                <input type="hidden" id="token_stat" name="token_stat" value="<?php echo token_stat(); ?>">
                                                <span id="token_lbl" class="help-block <?= is_token() ? '' : 'hidden' ?>">Токен получен</span>
                                            </div>
                                            <div class="col-sm-4">                                                
                                                <a id="token_btn" data-toggle="modal" class="btn btn-default hidden" href="#token_dialog"> <?= is_token() ? 'Получить токен заново' : 'Получить токен' ?></a>
                                            </div>
                                        </div>
                                        <?php
                                        if(SANTI_CLOUD == "ftp")
                                            echo '<div id="set_url" class="form-group">';
                                        else
                                            echo '<div id="set_url" class="form-group" style="display:none">';
                                        ?>
                                            <label class="col-sm-3 control-label">Address:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="cloud_url" name="cloud_url" value="<?php echo SANTI_CLOUD_URL ?>" class="form-control">
                                            </div>
                                        </div>
                                        <?php
                                            if(SANTI_CLOUD != "none")
                                                echo '<div id="set_login" class="form-group">';
                                            else
                                                echo '<div id="set_login" class="form-group" style="display:none">';
                                        ?>
                                            <label class="col-sm-3 control-label" id="cloud_login"><?php if(SANTI_CLOUD == "dropbox") echo "App key:"; elseif(SANTI_CLOUD == "google") echo "CLIENT ID:"; else echo "Login:"; ?></label>
                                            <div class="col-sm-9">
                                                <input type="text" id="dbxkey" name="dbxkey" value="<?php echo SANTI_CLOUD_LOGIN ?>" class="form-control">
                                            </div>
                                        </div>
                                        <?php
                                            if(SANTI_CLOUD != "none")
                                                echo '<div id="set_password" class="form-group">';
                                            else
                                                echo '<div id="set_password" class="form-group" style="display:none">';
                                        ?>
                                            <label class="col-sm-3 control-label" id="cloud_passwd"><?php if(SANTI_CLOUD == "dropbox") echo "App secret:"; elseif(SANTI_CLOUD == "google") echo "CLIENT SECRET:"; else echo "Password:"; ?></label>
                                            <div class="col-sm-9">
                                                <input type="password" id="dbxsecret" name="dbxsecret" value="<?php echo SANTI_CLOUD_PASSWORD ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Исключаемые файлы, папки, расширения (мониторинг файлов):</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="stopfiles" name="stopfiles" value="<?php if(SANTI_START == 1) echo str_replace("/", "", dirname($_SERVER['PHP_SELF'])).', '.SANTI_STOPF; else echo SANTI_STOPF; ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Исключаемые файлы, папки, расширения (backup файлов):</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="stopbakfiles" name="stopbakfiles" value="<?php if(SANTI_START == 1) echo $path; else echo SANTI_STOPB; ?>" class="form-control">
                                                <input type="hidden" id="stoptables" name="stoptables" value="<?php echo SANTI_STOPT ?>">
                                            </div>
                                        </div>
                                        <div class="form-group" style="padding: 0px;">
                                            <label class="col-sm-3 control-label"></label>
                                            <div class="col-sm-9"></div>
                                        </div>
                                    </div>
                                    <div class="tab-pane form-horizontal bordered-row" id="step-3">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">SANTI ID:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="santiid" name="santiid" value="<?php echo SANTI_ID ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">E-mail:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="alert_emails" name="alert_emails" value="<?php echo SANTI_EMAIL ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Моб.телефон:</label>
                                            <div class="col-sm-9">
                                                <input type="text" id="phone" name="phone" value="<?php echo SANTI_PHONE ?>" class="input-mask form-control" data-inputmask="'mask':'+9 999 999 99999'" size="12"/>
                                                <span class="help-block">+9 999 999 99 99</span>
                                            </div>
                                        </div>
                                        <div class="form-group" style="padding: 0px;">
                                            <label class="col-sm-3 control-label"></label>
                                            <div class="col-sm-9"></div>
                                        </div>
                                    </div>
                                    <div class="tab-pane form-horizontal bordered-row" id="step-4">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Информировать на E-mail:</label>
                                            <div class="col-sm-9">
                                                <input type="checkbox" id="infomail" name="infomail" <?php if (SANTI_INFO_EMAIL) echo "checked"; ?> data-size="small" class="input-switch" data-on-text="Вкл" data-off-text="Выкл">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Информировать по СМС:</label>
                                            <div class="col-sm-9">
                                                <input type="checkbox" id="infosms" name="infosms" <?php if (SANTI_INFO_SMS) echo "checked"; ?> data-size="small" class="input-switch" data-on-text="Вкл" data-off-text="Выкл">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Логин СМС агрегатора:</label>
                                            <div class="col-sm-9">
                                                <span id="av_user"><?php echo SANTI_SMS_USER ?></span>
                                                <span class="help-block"><a href="http://smsc.ru/?pp386120" target="_blank">зарегистрировать</a> | <a href="#" data-target="#smsset_modal" data-toggle="modal">установить существующий</a></span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label">Пароль СМС агрегатора:</label>
                                            <div class="col-sm-9">
                                                <span id="av_password"><?php echo SANTI_SMS_PASSWORD ?></span>
                                            </div>
                                        </div>
                                        <div class="form-group" style="padding: 0px;">
                                            <label class="col-sm-3 control-label"></label>
                                            <div class="col-sm-9">                                                
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="pager wizard">
                                        <li class="finish"><a href="#" id="finish_btn" class="btn btn-default"><?= l('Finish');?></a></li>
                                        <li class="next"><a href="#" class="btn btn-default"><?= l('Next');?></a></li>                                        
                                        <li class="previous"><a href="#" class="btn btn-default"><?= l('Previous');?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- модальное окно диалога смс сервис ввод доступов -->
    <div class="modal fade" id="smsset_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">СМС уведомления от <a href="http://smsc.ru/?pp386120" target="_blank">SMS Центр</a></h4>
                </div>
                <div class="modal-body form-horizontal bordered-row">
                    <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                        <label class="col-sm-2 control-label">Логин:</label>
                        <div class="col-sm-10">
                            <input type="text" id="avm_user" name="avm_user" value="" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Пароль:</label>
                        <div class="col-sm-10">
                            <input type="text" id="avm_password" name="avm_password" value="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
                    <button type="button" class="btn btn-primary" id="avm_apply" data-dismiss="modal">Применить</button>
                </div>
            </div>
        </div>
    </div>
    <!-- конец модального окна диалога -->
    <!--модальное окно диалога облако-->
    <div class="modal fade bs-example-modal-sm" id="token_dialog" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Предупреждение</h4>
                </div>
                <div class="modal-body">
                    <p>В ваше облачное хранилище будет отправлен пустой файл test.txt. Нужно подтвердить его получение.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
                    <button type="button" class="btn btn-primary" id="get_token" data-dismiss="modal">Продолжить</button>
                </div>
            </div>
        </div>
    </div>
    <!-- конец модального окна диалога -->
    <script type="text/javascript">
        $(document).ready(function()
        {
            testhost();
        });
    </script>