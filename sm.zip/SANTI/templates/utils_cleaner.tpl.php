<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Поиск и удаление вредоносных вставок</h2>
                        <p>Поиск и удаление в файлах однострочных вредоносных вставок по маске</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="cleaner" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">Начало вредоносной вставки:</label>
                                    <div class="col-sm-3">
                                        <input type="text" name="startcode" id="startcode" class="form-control">
                                    </div>
                                    <label class="col-sm-3 control-label">Конец вредоносной вставки:</label>
                                    <div class="col-sm-3">
                                        <input type="text" name="finishcode" id="finishcode" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Расширения (через запятую):</label>
                                    <div class="col-sm-3">
                                        <input type="text" name="extensions" id="extensions" value="jpg, png, jpeg, bmp, gif" class="form-control">
                                    </div>
                                    <label class="col-sm-3 control-label">действия с этими расширениями:</label>
                                    <div class="col-sm-3">
                                        <select name="dofs" id="dofs" class="form-control">
                                            <option value="1" selected>Указанные исключить</option>
                                            <option value="2">Указанные обрабатывать</option>
                                            <option value="3">Не учитывать расширения</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Выберите действие:</label>
                                    <div class="col-sm-3">
                                        <select name="docl" id="docl" class="form-control">
                                            <option value="1" selected>Ищем</option>
                                            <option value="2">Ищем и лечим</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-3"></div>
                                    <div class="col-sm-6"><input type="submit" value="Выполнить" class="btn btn-warning"></div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Найдено файлов:</label>
                                    <div class="col-sm-6">
                                        <h3 id="result">0</h3>
                                    </div>
                                </div>
                                <div class="form-group">                                    
                                    <div class="col-sm-12">
                                        <table id="datatable-cleaner" class="dataTables table table-striped table-bordered responsive no-wrap dynamicTable_one" cellspacing="0" width="100%">
                                            <thead>
                                            <tr>
                                                <th>Файл</th>
                                                <th>Статус</th>
                                                <th>Действия</th>
                                            </tr>
                                            </thead>

                                            <tfoot>
                                            <tr>
                                                <td>Файл</td>
                                                <td>Статус</td>
                                                <td>Действия</td>
                                            </tr>
                                            </tfoot>
                                            
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    