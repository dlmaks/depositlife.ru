<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
            <div id="page-content-wrapper">
                <div id="page-content">
                    <div id="page-title">
                        <h2>Новости</h2>
                        <p>Новости развития проекта и новости уязвимостей</p>
                    </div>

                    <div class="panel">
                        <div class="panel-body">
                            <form id="news" class="form-horizontal bordered-row">
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <label class="col-sm-3 control-label">Выберите интересующие новости:</label>
                                    <div class="col-sm-4">
                                        <select class="form-control" onchange="showNEWS(this.value)">
                                            <option value="SEN">Новости уязвимостей</option>                                                                
                                            <option value="SAN" selected>Новости проекта</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group" style="border-top: 0px; padding-top: 0px;">
                                    <div class="col-sm-12">
                                        <div id="rssOutput">поле новостей...</div>
                                    </div>
                                </div>
                            </form>
                            <script type="text/javascript">
                                $(document).ready(function ()
                                {
                                    showNEWS("SAN");  
                                })
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    