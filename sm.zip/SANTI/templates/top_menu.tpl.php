<?php if(!defined('SANTI_NAME')) die("Доступ запрещен"); ?>
<div>
    <div id="loading">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>

    <div id="page-wrapper">
        <!-- header -->
        <div id="page-header" class="bg-gradient-2">
            <div id="mobile-navigation">
                <button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button>
                <a href="index.html" class="logo-content-small" title="<?= l('SANTI')?>"></a>
            </div>
            <div id="header-logo" class="logo-bg">
                <a href="index.php" class="logo-content-big" title="<?= l('SANTI')?>">
                </a>
                <a href="index.php" class="logo-content-small" title="<?= l('SANTI')?>">
                </a>
            </div>

            <!-- header-nav-left --><div id="header-nav-left"></div><!-- #header-nav-left -->

            <!-- top menu -->
            <div id="header-nav-right">                    
                <a id="logout-btn" class="header-btn-main<? if($page == 1) echo '-act'; ?>" href="index.php">
                    <i class="glyph-icon icon-home" style="font-size:21px; color: white;"></i>
                    <span class="font-white" style="font-size:16px;"><?= l('Dashboard');?></span>
                </a>
                <!-- utils -->
                <div class="header-btn-main<? if(($page != 1) && ($page != 19)) echo '-act'; ?>" id="dashnav-btn">
                    <a href="#" data-toggle="dropdown" data-placement="bottom" style="display:block;">
                        <i class="glyph-icon icon-crosshairs" style="font-size:21px; color: white;"></i>
                        <span class="font-white" style="font-size:16px;"><?= l('Utils');?> <?= l('SANTI');?></span>
                    </a>
                    <div class="dropdown-menu box-sm float-right-main" style="padding:0px !important;">
                        <div class="list-group" style="border-top:none; border-top-left-radius: 0px; border-top-right-radius: 0px;">
                            <a href="index.php?page=163" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-blue icon-cut"></i>
                                Удаление вредоносных вставок
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=13" class="list-group-item font-black" style="border-left:none; border-right:none;">
                                <i class="glyph-icon icon-key"></i>
                                <?= l('Password generator');?>
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=162" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-orange icon-calendar"></i>
                                Date-поиск файлов
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=15" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-blue-alt icon-cloud"></i>
                                <?=l('.ftpaccess configurator');?>
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=16" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-green icon-database"></i>
                                Бекап и восстановление файлов
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=161" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-purple icon-lock"></i>
                                .htaccess блокировка сайта
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=17" class="list-group-item font-black" style="border-left:none; border-right:none; ">
                                <i class="glyph-icon font-primary icon-info"></i>
                                <?=l('PHP info');?>
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                            <a href="index.php?page=18" class="list-group-item font-black" style="border:none; border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
                                <i class="glyph-icon font-red icon-rss"></i>
                                Новости
                                <i class="glyph-icon icon-chevron-right font-gray"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- #utils -->

                <!-- full screen -->
                <a href="#" class="hdr-btn" id="fullscreen-btn" title="Fullscreen">
                    <i class="glyph-icon icon-arrows-alt"></i>
                </a>
                <!-- #full screen -->

                <!-- messages -->
                <?php
                    if(SANTI_START == "0")
                    {
                        $notifiers = notifiers_get();
                        $not_num = 0;
                        $news_list = "";
                        foreach ($notifiers as $res)
                        {
                            $not_num++;

                            $news_list .= '<li>
                                    <span class="bg-blue-alt icon-notification glyph-icon icon-info"></span>
                                    <span class="notification-text"><a href="'.$res[1].'" target="_blank">'.$res[2].'</a></span>';

                            if($res[2] != "Скачайте обновленный САНТИ.")
                                $news_list .= '<span class="btn-link float-right"><a href="#" onclick="notifier_delete('.$res[0].'); var el=this.parentNode.parentNode; el.parentNode.removeChild(el);">скрыть</a></span>';
                            else
                                echo '<script type="text/javascript">$(document).ready(function() { showNoty("Ваша версия САНТИ устарела, обновитесь."); })</script>';

                            $news_list .= '</li>';                                            
                        }
                    }
                ?>
                <div class="dropdown" id="notifications-btn">
                    <a data-toggle="dropdown" href="#" title="Сообщения">
                        <?
                            if ($not_num > 0)
                                echo '<span class="small-badge bg-red"></span>';
                        ?>
                        <i class="glyph-icon icon-bullhorn"></i>
                    </a>
                    <div class="dropdown-menu box-md float-right">
                        <div class="popover-title display-block clearfix pad10A">
                            Сообщения
                            <a class="text-transform-none btn-link float-right" href="http://santivi.com/category/uvedomleniya-v-santi" target="_blank" title="все сообщения">все сообщения</a>
                        </div>
                        <div class="scrollable-content scrollable-slim-box">
                            <ul class="no-border notifications-box">                                
                            <?= $news_list; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- #messages -->
                <a class="header-btn" id="logout-btn" href="index.php?page=19" title="Настройки">
                    <i class="glyph-icon icon-cogs"></i>
                </a>
                <a class="header-btn" id="logout-btn" href="index.php?page=20" title="Выход">
                    <i class="glyph-icon icon-sign-out"></i>
                </a>
            </div>
            <!-- #header-nav-right -->
        </div>
        <!-- #header --> 