$(document).ready(function() {

    /* Datepicker */

    try{
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
        $('.dpicker').datepicker({
            format: 'dd.mm.yyyy',
            weekstart: '1',
            autoclose: true,
            language: 'ru'
        });
        
        $('.dpicker').datepicker("setDate" , now);
    } catch (e){}

    $.blockUI.defaults.css.border = '1px solid #0093DB'; 

    /* Datatables responsive */
    $('#datatable-alerts')
        .on( 'init.dt', function () {  } )

    $('#datatable-alerts').DataTable( {
                    responsive: true,                    
                    "sInfo": "Показано с _START_ по _END_ из _TOTAL_ записей",                    
                    "oLanguage": {
                        "sLengthMenu": "_MENU_ записей на страницу",
                        "sZeroRecords": "Ничего не найдено - извините",
                        "sInfo": "Показано с _START_ по _END_ из _TOTAL_ записей",
                        "sInfoEmpty": "Показано с 0 по 0 из 0 записей",
                        "sInfoFiltered": "(выбрано из _MAX_ записей)",
                        "sSearch": "Поиск:",
                        "oPaginate": { 
                             "sFirst": "Первая", 
                             "sPrevious": "Предыдущая", 
                             "sNext": "Следующая", 
                             "sLast": "Последняя" 
                             }
                }
    });    

    $('.dataTables_filter input').attr("placeholder", "Поиск...");
    $("#datatable-alerts_paginate").prepend('<a data-target="#alert_dialog" class="btn btn-default" data-toggle="modal" style="margin: 0px 10px 0px 0px; height: 33px; position:relative;top:1px;">очистить</a>');

    oTable = $('#datatable-cleaner').DataTable( {
        responsive: true,                    
        "sInfo": "Показано с _START_ по _END_ из _TOTAL_ записей",                    
        "oLanguage": {
            "sLengthMenu": "_MENU_ записей на страницу",
            "sZeroRecords": "Ничего не найдено - извините",
            "sInfo": "Показано с _START_ по _END_ из _TOTAL_ записей",
            "sInfoEmpty": "Показано с 0 по 0 из 0 записей",
            "sInfoFiltered": "(выбрано из _MAX_ записей)",
            "sSearch": "Поиск:",
            "oPaginate": { 
                 "sFirst": "Первая", 
                 "sPrevious": "Предыдущая", 
                 "sNext": "Следующая", 
                 "sLast": "Последняя" 
            }
        }
    }); 

    $('.input-switch').bootstrapSwitch();

    $('#form-wizard').bootstrapWizard({
        tabClass: 'nav nav-pills',
        onNext: function(tab, navigation, index) {
            if(!validateSteps(index))
                return false;
        },
        onTabShow: function(tab, navigation, index) {            
            if($('#step'+index).attr('class') == 'disabled')
                $('#step'+index).toggleClass('disabled');

            if((index == 4)&&($('#finish_btn').attr('class').indexOf('disabled') != -1))
                $('#finish_btn').toggleClass('disabled');
        },
        onInit: function(){
            $('#finish_btn').toggleClass('disabled');
        }
    });

    function validateSteps(step)
    {   
        alertClear();
        if(step == 1)
        {
        }

        if(step == 2)
        {
            if(($('#pwd').val() == $('#pwd1').val()))
            {
                if(($('#pwd').val().length <= 5)&&($('#pwd').val().trim() != '')&&($('#pwd1').val().trim() != ''))
                {
                    $("#pwd").css("border-color", "red");
                    $("#pwd1").css("border-color", "red");
                    showNoty('Длина пароля не должна быть меньше 5ти символов');
                    return false;
                }
            }
            else
            {
                $("#pwd").css("border-color", "red");
                $("#pwd1").css("border-color", "red");
                showNoty('Пожалуйста проверьте правильность ввода нового пароля и его повторения.');
                return false;
            }

            if($('#url').val().trim() == '')
            {
                $("#url").css("border-color", "red");
                showNoty('Поле необходимо заполнить.');
                return false;
            }

            if($('#path').val().trim() == '')
            {
                $("#path").css("border-color", "red");
                showNoty('Поле необходимо заполнить.');
                return false;
            }

            if($('#serverpath').val().trim() == '')
            {
                $("#serverpath").css("border-color", "red");
                showNoty('Поле необходимо заполнить.');
                return false;
            }      
        }

        if(step == 3)
        {            
        }

        if(step == 4)
        {            
            if($('#alert_emails').val().trim() == '')
            {
                //$("#alert_emails").css("border-color", "red");
                //showNoty('Поле необходимо заполнить.');
                //return false;
            }

            var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if(($('#alert_emails').val().trim() != '') && (!pattern.test($('#alert_emails').val().trim())))
            {
                $("#alert_emails").css("border-color", "red");
                showNoty('Указан не верный e-mail.');
                return false;
            }
        }

        return true;
    }

});

function pageTransitions() {
    var transitions = ['.pt-page-moveFromLeft', 'pt-page-moveFromRight', 'pt-page-moveFromTop', 'pt-page-moveFromBottom', 'pt-page-fade', 'pt-page-moveFromLeftFade', 'pt-page-moveFromRightFade', 'pt-page-moveFromTopFade', 'pt-page-moveFromBottomFade', 'pt-page-scaleUp', 'pt-page-scaleUpCenter', 'pt-page-flipInLeft', 'pt-page-flipInRight', 'pt-page-flipInBottom', 'pt-page-flipInTop', 'pt-page-rotatePullRight', 'pt-page-rotatePullLeft', 'pt-page-rotatePullTop', 'pt-page-rotatePullBottom', 'pt-page-rotateUnfoldLeft', 'pt-page-rotateUnfoldRight', 'pt-page-rotateUnfoldTop', 'pt-page-rotateUnfoldBottom'];
    for (var i in transitions) {
        var transition_name = transitions[i];
        if ($('.add-transition').hasClass(transition_name)) {

            $('.add-transition').addClass(transition_name + '-init page-transition');

            setTimeout(function() {
                $('.add-transition').removeClass(transition_name + ' ' + transition_name + '-init page-transition');
            }, 1200);
            return;
        }
    }

};

function alertClear()
{
    $.noty.closeAll();
    $("#serverpath").css("border-color", "#DFE8F1");
    $("#path").css("border-color", "#DFE8F1");
    $("#url").css("border-color", "#DFE8F1");
    $("#pwd").css("border-color", "#DFE8F1");
    $("#pwd1").css("border-color", "#DFE8F1");
    $("#email").css("border-color", "#DFE8F1");
}

function showNoty(message)
{
    noty({
                text: '<i class="glyph-icon icon-exclamation mrg5R"></i>&nbsp;'+message,
                type: 'error',
                dismissQueue: true,
                theme: 'agileUI',
                layout: 'bottom',
                timeout: 30000
            });
}

$(document).ready(function() {
    pageTransitions();
});

$(".input-mask").inputmask();
