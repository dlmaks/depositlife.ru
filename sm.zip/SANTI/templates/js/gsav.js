$(document).ready(function()
{
	$('#login_form').submit(function()
	{
		$.blockUI( { message: l('Waiting. Santi in working.') });

		var hash = hex_md5($("#password").val());

		$.ajax({
					type: "POST",
					url: "?util=auth",
					data: "login="+$("#login").val()+"&password="+ hash,
					success: function(html){
						$.unblockUI();
						if(html == "0")
						{
							$("#error").html("<p style='color: red;'>Неверный логин или пароль.</p>");
						}
						else if (html == "1")
						{						
							//window.location.href = "index.php?lang="+$('#language').val();
							location.reload();
						}
						else if (html == "2")
						{
							$("#error").html("<p style='color: red;'>Количество попыток исчерпано.</p>");
						}
				}
			});
		return false;
	});

	$('#language').change(function() {
		window.location.href = "?page=0&lang="+$('#language').val();		
	});

	$('#get_token').click(function()
	{
		document.location.href = "?util=gettoken";
	});

	$('#finish_btn').click(function()
	{
		$.blockUI( { message: l('Waiting. Santi in working.') });

		var new_pass = "";
		var stopb = "datas,autoconfig.php,install.php";
		new_pass = hex_md5($("#pwd").val());
		var result = "";
		$("#form-wizard").css("display", "none");

		$.ajax({
					type: "POST",
					url: "?util=settings",
					data: "login="+$("#login").val()+"&pwd="+new_pass+"&path="+$("#path").val()+"&url="+$("#url").val()+
							"&timezone="+$("#timezone").val()+"&cronhand="+$("#cronhand").is(':checked')+
							"&autoupdate="+$("#autoupdate").is(':checked')+"&serverpath="+$("#serverpath").val()+
							"&addressbd="+ $("#addressbd").val()+"&namebd="+ $("#namebd").val()+
							"&loginbd="+ $("#loginbd").val()+"&passwordbd="+ $("#passwordbd").val()+
							"&addresskopbd="+ $("#addresskopbd").val()+"&namekopbd="+ $("#namekopbd").val()+
							"&loginkopbd="+ $("#loginkopbd").val()+"&passwordkopbd="+ $("#passwordkopbd").val()+
							"&cod="+ $("#cod").val()+"&cloud="+ $("#cloud").val()+"&yadlogin="+ $("#dbxkey").val()+
							"&yadpassword="+ $("#dbxsecret").val()+"&stopfiles="+ $("#stopfiles").val()+
							"&stopbakfiles="+ $("#stopbakfiles").val()+"&stoptables="+ $("#stoptables").val()+
							"&santiid="+ $("#santiid").val()+"&email="+ $("#alert_emails").val()+"&phone="+ $("#phone").val()+
							"&av_user="+ $("#av_user").html()+"&av_password="+ $("#av_password").html()+
							"&infomail="+ $("#infomail").is(':checked')+"&infosms="+ $("#infosms").is(':checked')+
							"&cloud_url="+$("#cloud_url").val()+"&santi_start=1",
					success: function(html){
					$.unblockUI();
					if(html == "0")
					{
						$.blockUI({ message: 'Ошибка сохранения настроек в файл.'});
						$("#wizard-result").append('<p>Ошибка сохранения настроек в файл.</p>');
						setTimeout($.unblockUI, 3000);
					}
					else if (html == "1")
					{
						$("#wizard-result").append('<p>Настройки в файл сохранены.</p>');
						$.blockUI({message: 'Создание образа сайта.',});
						$.ajax({
							type: "POST",
							url: "?util=scanfiles",
							data: "dosf=1&silent=1",
							success: function(html1)
							{
								$.ajax({
									type: "POST",
									url: "?util=scanfiles",
									data: "dosf=2&silent=1",
									success: function(html2){										
										$.unblockUI();
										$("#wizard-result").append('<p>Образ сайта создан.</p>');
										$.blockUI({message: 'Сохраняем САНТИ.',});
										$.ajax({
											type: "POST",
											url: "?util=backup",
											data: "dobu=3&arhname=lastsanti.zip&startpath="+$("#serverpath").val()+"/"+$("#path").val()+"&stoppath="+stopb+"&rassh=&maxsize=&bufile=",
											success: function(html3){												
												$.unblockUI();
												if(html3 != "1")
												{
													$.blockUI({ message: 'Ошибка сохранения САНТИ.'});
													$("#wizard-result").append('<p>Ошибка сохранения САНТИ.</p>');

													setTimeout($.unblockUI, 3000);
												}
												else
												{
													$("#wizard-result").append('<p>Сохранение САНТИ завершено.</p>');
													$.blockUI({message: 'Запуск самозащиты.',});
													$.ajax({
														type: "POST",
														url: "?util=autosettings",
														data: "cron_hand="+$('#cronhand').is(':checked'),
														success: function(html4){
															$.unblockUI();															
															if(html4.indexOf("no_sid") != -1)
															{
																$.blockUI({ message: 'Неверный ID САНТИ, пройдите в настройки и укажите верный.'});
																$("#wizard-result").append('<p>Неверный ID САНТИ, пройдите в настройки и укажите верный.</p>');

																setTimeout($.unblockUI, 3000);
															}
															else if (html4.indexOf("ok_cron") != -1)
															{
																$.blockUI({ message: 'Самозащита включена.'});
																$("#wizard-result").append('<p>Самозащита включена.</p>');

																setTimeout($.unblockUI, 3000);
															}
															else if (html4.indexOf("ok_write") != -1)
															{
																$.blockUI({ message: 'Включен режим ручного cron сервера. Самозащита не активна.'});
																$("#wizard-result").append('<p>Включен режим ручного cron сервера. Самозащита не активна.</p>');
																setTimeout($.unblockUI, 1000);																
															}
															else
															{
																$.blockUI({ message: 'Ошибка cron сервера.'});
																$("#wizard-result").append('<p>Ошибка cron сервера.</p>');

																setTimeout($.unblockUI, 3000);
															}

															if($('#install_complete').length){
																$('#install_complete').css('display', 'block');
															}
														}
													});
												}
											}
										});
									}
								});
							}
						});
					}
				}
			});
		$.unblockUI();
		return false;
	});

	$('#generator').submit(function()
	{
		$.blockUI( { message: 'САНТИ работает. Подождите.', });

		$.ajax({
					type: "POST",
					url: "?util=generator",
					data: "passlength="+$("#passlength").val()+"&passtype="+$("#passtype").val(),
					success: function(data)
					{
						$.unblockUI();
						if(data == "0")
						{
							$.blockUI({ message: 'Ошибка генерации'});

							setTimeout($.unblockUI, 2000);
						}
						else if (data != "0")
						{
							$("#result").html(data);
						}
					}
			});
		return false;
	});

	$('#blocker').submit(function()
	{
		$.blockUI( { message: 'САНТИ работает. Подождите.', });

		$.ajax({
					type: "GET",
					url: "?util=blocker",
					data: "do="+$("#do").val()+"&ip="+$('#exclude_ip').val(),
					success: function(html){
					if(html == "0")
					{
						$("#blockstate").html("ошибка действия. обновите страницу.");
					}
					else if ((html != "0") && ($("#do").val() == "3"))
					{
						$("#blockstate").html("сайт разблокирован");
						$("#do").val("2");
						$("#blockBtn").val("Заблокировать");
						$('#excl_ip').css('display', 'block');
					}
					else if ((html != "0") && ($("#do").val() == "2"))
					{
						$("#blockstate").html("сайт заблокирован");
						$("#do").val("3");
						$("#blockBtn").val("Разблокировать");
						$('#excl_ip').css('display', 'none');
					}
					$.unblockUI();
				}
			});
		return false;
	});

	$('#ftpa').submit(function()
	{
		$.blockUI( { message: 'САНТИ работает. Подождите.', });
		$.ajax({
					type: "POST",
					url: "?util=ftpacc",
					data: "choose="+$('input[name="choose"]:checked').val()+"&dip="+$("#dip").val()+"&aip="+$("#aip").val()+"&deny_rewrite="+$('input[name="deny_rewrite"]:checked').val(),
					success: function(html){
					$.unblockUI();
					if(html == "0")
					{
						$.blockUI({ message: 'Ошибка генерации ftp файла'});

						setTimeout($.unblockUI, 2000);
					}
					else if (html != "0")
					{
						$("#result").html(html);
					}
				}
			});
		return false;
	});

	$('#fsearch').submit(function()
	{
		oTable.clear();
		oTable.draw();
		$.blockUI({ message: 'САНТИ работает. Подождите.', });
		$.ajax({
					type: "POST",
					url: "?util=datefinder",
					dataType: "json",
					data: "startdate="+$("#startdate").val()+"&finishdate="+$("#finishdate").val()+"&extensions="+$("#extensions").val()+"&dofs="+$("#dofs").val(),
					success: function(data){
						data = 	eval(data);
						var count = 0;
						for(f in data)
						{
							oTable.row.add([data[f].file, data[f].date, "<a style='cursor: pointer;' onclick='fileFromUtil(\""+data[f].file+"\");'>Просмотреть</a>"]).draw();
							count++;
						}

						$('#result').html(count);
						$.unblockUI();
				}
			});
		return false;
	});

	$('#cleaner').submit(function()
	{
		oTable.clear();
		oTable.draw();
		$.blockUI( { message: 'САНТИ работает. Подождите.', });
		$.ajax({
					type: "POST",
					url: "?util=cleaner",
					dataType: "json",
					data: "startcode="+encodeURIComponent($("#startcode").val())+"&finishcode="+encodeURIComponent($("#finishcode").val())+"&extensions="+$("#extensions").val()+"&dofs="+$("#dofs").val()+"&docl="+$("#docl").val(),
					success: function(data){
						$.unblockUI();
						data = 	eval(data);				
						var count = 0;
						for(f in data)
						{
							oTable.row.add([data[f].file, data[f].status, "<a style='cursor: pointer;' onclick='fileFromUtil(\""+data[f].file+"\");'>Просмотреть</a>"]).draw();
							count++;
						}

						$('#result').html(count);
						$.unblockUI();
				}
			});
		return false;
	});

	$('#buform').click(function()
	{
		$('.modal').modal('hide');
		$.blockUI(
		{
			message: 'САНТИ работает. Подождите.',
		});

		$.ajax({
					type: "POST",
					url: "?util=backup",
					data: "dobu="+$("#dobu").val()+"&arhname="+$("#arhname").val()+"&startpath="+$("#startpath").val()+"&stoppath="+$("#stoppath").val()+"&rassh="+$("#rassh").val()+"&maxsize="+$("#maxsize").val()+"&bufile="+$("#bufile").val(),
					success: function(html){
					$.unblockUI();
					if(html == "0")
					{
						$.blockUI({ message: 'Ошибка бекапинга'});

						setTimeout($.unblockUI, 2000);
					}
					else if (html == "1")
					{
					}
				}
			});
		return false;
	});

	$("#dobu").change(function ()
	{
		if($("#dobu").val() == "1")
		{
			$("#bunameblock").css("display","block");
			$("#startpathlbl").html("С какой папки бекапим:");
			$("#stoppathblock").css("display","block");
			$("#rasshblock").css("display","block");
			$("#maxsizeblock").css("display","block");
			$("#bufsblock").css("display","none");
		}
		else if($("#dobu").val() == "2")
		{
			$("#bunameblock").css("display","none");
			$("#startpathlbl").html("В какую папку восстанавливаем:");
			$("#startpath").val("new");
			$("#pathhelp").html("Распаковка в папку datas/unarchive/");
			$("#stoppathblock").css("display","none");
			$("#rasshblock").css("display","none");
			$("#maxsizeblock").css("display","none");
			$("#bufsblock").css("display","block");
		}
	});

	$('#status_files').on('switchChange.bootstrapSwitch', function () {autosave(1)});
	$('#status_db').on('switchChange.bootstrapSwitch', function () {autosave(2)});
	$('#status_sech').on('switchChange.bootstrapSwitch', function () {autosave(4)});
	$('#status_brch').on('switchChange.bootstrapSwitch', function () {autosave(5)});

	$("#status_bu").on('switchChange.bootstrapSwitch', function () {autosave(3)});
	$("#cron_bu").change(function () {autosave(3)});	

	$("#status_bud").on('switchChange.bootstrapSwitch', function () {autosave(7)});
	$("#cron_bud").change(function () {autosave(7)});

	$("#avm_apply").click(function ()
	{
		$("#av_user").html($("#avm_user").val());
		$("#av_password").html($("#avm_password").val());
		$('.modal').modal('hide');
	});

	$(window).scroll(function() {
		if($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();
		} else {
			$('#toTop').fadeOut();
		}
	});

	$('#toTop').click(function() {
		$('body,html').animate({scrollTop:0},800);
	});

	$('#feditor').submit(function()
	{
		var contents = editor.getSession().getValue();

		$.blockUI(
		{
			message: 'САНТИ работает. Подождите.',
		});

		$.ajax({
					type: "POST",
					url: "?util=file_editor",
					data: "fedo=2"+"&file_id="+$("#fileid").val()+"&contents="+encodeURIComponent(contents)+"&encoding="+$("#encoding").val(),
					success: function(data)
					{
						$.unblockUI();
						if(data == 0)
						{
							$.blockUI({ message: 'Ошибка сохранения'});

							setTimeout($.unblockUI, 2000);
						}
						else if (data != 0)
						{
							$.blockUI({ message: 'Файл сохранен'});

							setTimeout($.unblockUI, 2000);
						}
					}
			});
		return false;
	});

	$("#clear_notifi").click(function ()
		{
			$.blockUI({message: 'САНТИ работает. Подождите.'});

			$.ajax({
						type: "POST",
						url: "?util=database",
						data: "ca=1",
						success: function(html){
						setTimeout(function() {
							$.unblockUI();
							document.location.replace("?page=1");
						}, 2000);
					}
				});

	});


	$('#cloud').change(function() {
		var val = $(this).val();
		var str = $('#token_stat').val();
		switch(val) {
			case 'none':
				$('#cloud_login').text('Login:');
				$('#cloud_passwd').text('Password:');
				$('#token_btn').addClass('hidden');
				$('#token_lbl').addClass('hidden');
				$('#set_url').css('display', 'none');
				$('#set_login').css('display', 'none');
				$('#set_password').css('display', 'none');
			break;
			case 'yandex':
				$('#cloud_login').text('Login:');
				$('#cloud_passwd').text('Password:');
				$('#token_btn').addClass('hidden');
				$('#token_lbl').addClass('hidden');
				$('#set_url').css('display', 'none');
				$('#set_login').css('display', 'block');
				$('#set_password').css('display', 'block');
			break;
			case 'ftp':
				$('#cloud_login').text('Login:');
				$('#cloud_passwd').text('Password:');
				$('#token_btn').addClass('hidden');
				$('#token_lbl').addClass('hidden');
				$('#set_url').css('display', 'block');
				$('#set_login').css('display', 'block');
				$('#set_password').css('display', 'block');
			break;
			case 'google':
				$('#cloud_login').text('CLIENT ID:');
				$('#cloud_passwd').text('CLIENT SECRET:');
				$('#token_btn').removeClass('hidden');
				$('#set_url').css('display', 'none');
				$('#set_login').css('display', 'block');
				$('#set_password').css('display', 'block');
				if(str.search('google') == -1) {
					$('#token_lbl').addClass('hidden');
					$('#token_btn').text('Получить токен');
				} else {
					$('#token_lbl').removeClass('hidden');
					$('#token_btn').text('Получить токен заново');
				}
			break;
			case 'dropbox':
				$('#cloud_login').text('App key:');
				$('#cloud_passwd').text('App secret:');
				$('#token_btn').removeClass('hidden');
				$('#set_url').css('display', 'none');
				$('#set_login').css('display', 'block');
				$('#set_password').css('display', 'block');
				if(str.search('dropbox') == -1) {
					$('#token_lbl').addClass('hidden');
					$('#token_btn').text('Получить токен');
				} else {
					$('#token_lbl').removeClass('hidden');
					$('#token_btn').text('Получить токен заново');
				}
			break;
		}
	});

	$('#token_btn').click(function() {
		if($('#token_btn').hasClass('disabled')) return false;
		var new_pass = hex_md5($("#pwd").val());
		var str = $('#token_stat').val();
		if(str.search('dropbox') != -1 && $('#cloud').val()=='dropbox') {
			$.get('?util=gettoken&del=dropbox');
		}
		if(str.search('google') != -1 && $('#cloud').val()=='google') {
			$.get('?util=gettoken&del=google');
		}
		$.ajax({
			type: "POST",
			url: "?util=cloudsettings",
			data: "cloud="+ $("#cloud").val()+"&yadlogin="+ $("#dbxkey").val()+"&yadpassword="+ $("#dbxsecret").val(),
			success: function(html) {}
		});
	});

	$('#dbxkey, #dbxsecret').keyup(function() {
		if($('#dbxkey').val() != '' && $('#dbxsecret').val() != '')
			$('#token_btn').removeClass('disabled');
		else
			$('#token_btn').addClass('disabled');
	});

	if($('#dbxkey').val() != '' && $('#dbxsecret').val() != '')
		$('#token_btn').removeClass('disabled');
	else
		$('#token_btn').addClass('disabled');

	$('#cloud').change();
});

function l(txt)
{
	if(typeof(lang) !== 'undefined')
		for(var i in lang)
			if(i === txt)
				return lang[i];
	return txt;
}

function autosave(id)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
				type: "POST",
				url: "?util=autosettings",
				data: 	"auto_id="+id+
						"&status_files="+$("#status_files").is(':checked')+
						"&cron_files="+$("#cron_files").val()+
						"&status_db="+$("#status_db").is(':checked')+
						"&cron_db="+$("#cron_db").val()+
						"&status_bu="+$("#status_bu").is(':checked')+
						"&yadisk_bu="+$("#yadisk_bu").is(':checked')+
						"&cron_bu="+$("#cron_bu").val()+
						"&status_bud="+$("#status_bud").is(':checked')+
						"&yadisk_bud="+$("#yadisk_bud").is(':checked')+
						"&cron_bud="+$("#cron_bud").val()+
						"&status_sech="+$("#status_sech").is(':checked')+
						"&alert_sech="+$("#alert_sech").is(':checked')+
						"&cron_sech="+$("#cron_sech").val()+
						"&status_brch="+$("#status_brch").is(':checked')+
						"&cron_brch="+$("#cron_brch").val(),
				success: function(html)
				{
					$.unblockUI();
					
					if(html.indexOf("no_sid") != -1)
					{
						$.blockUI({ message: 'Неверный ID САНТИ, пройдите в настройки и укажите верный.'});
						setTimeout($.unblockUI, 3000);
					}
					else if (html.indexOf("ok_cron") != -1)
					{
						$.blockUI({ message: 'Изменения на CRON сервере внесены'});
						setTimeout($.unblockUI, 1000);
					}
					else if (html.indexOf("ok_write") != -1)
					{
						$.blockUI({ message: 'Настройки автопилота сохранены'});
						setTimeout($.unblockUI, 1000);
					}
					else
					{
						$.blockUI({ message: 'Ошибка cron сервера. Попробуйте ещё раз.'});
						setTimeout($.unblockUI, 2000);
					}
				}
			});
	return false;
}

function notifier_delete(id)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
	        type: "POST",
	        url: "?util=database",
	        data: "nd="+id,
	        success: function(html){
			$.unblockUI();
			var not_num = $("#not_counter").html() - 1;
            if(not_num > 0)
            {
                $("#not_counter").html(not_num);
            }
            else
            {
            	$("#not_counter").css("display","none");
            }
		}
	});
}

function object_ignore(id)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
		type: "POST",
		url: "?util=database",
		data: "oi="+id,
		success: function(html)
		{
			$.ajax({
				type: "POST",
				url: "?util=settings",
				data: "addstopf=" + $("#file_"+id).text(),
				success: function(html) {
					$.unblockUI();
					$("#action_"+id).html('<span style="display: inline-block; float: right;">игнорируется&nbsp;&nbsp;<a style="cursor: pointer;" onclick="object_null('+id+');" class="tips" title="отменить"><i class="glyph-icon font-orange icon-refresh"></i></a></span>');
				}
			});
		}
	});
}

function object_healed(id)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
	        type: "POST",
	        url: "?util=database",
	        data: "oh="+id,
	        success: function(html)
	        {
				$.unblockUI();
            	$("#action_"+id).html('<span style="display: inline-block; float: right;">не показывается&nbsp;&nbsp;<a  style="cursor: pointer;" onclick="object_null('+id+');" class="tips" title="отменить"><i class="glyph-icon font-orange icon-refresh"></i></a></span>');
			}
	});
}

function object_null(id)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
	        type: "POST",
	        url: "?util=database",
	        data: "on="+id,
	        success: function(html)
	        {
				$.unblockUI();
            	$("#action_"+id).html('<select class="form-control" style="border: none; box-shadow: none;"><option value="3" selected>выбрать</option><option value="4" onclick="object_healed('+id+');">не показывать</option><option value="5" onclick="alert(\'no\')">проверить</option><option value="6" onclick="object_ignore('+id+')">игнорировать</option></select>');
			}
	});
}

function fileFromUtil(file)
{
	$.blockUI(
	{
		message: 'САНТИ работает. Подождите.',
	});

	$.ajax({
	        type: "POST",
	        url: "?util=database",
	        data: "uf="+file,
	        success: function(html)
	        {
				$.unblockUI();
            	window.location.href = "index.php?page=121&file_id="+html;
			}
	});

	return false;
}

function getsmsbalance()
{
	$.ajax({
		type: "POST",
		url: "?util=smsbalance",
		data: "",
		success: function(html){
			if(html == "0")
			{
				$.blockUI({ message: 'Ошибка проверки СМС баланса'});

				setTimeout($.unblockUI, 2000);
			}
			else
			{
				$("#smsbalance").html(html);
			}
		}
	});
}

function phpinfopage()
{
		$.blockUI(
		{
			message: 'САНТИ работает. Подождите.',
		});

        $.ajax({
		    	type: "POST",
	    		url: "?util=phpinfo",
			    data: "",
			    success: function(html){
			    $.unblockUI();
				if(html == "0")
			    {
					$.blockUI({ message: 'Ошибка построения отчета'});

        			setTimeout($.unblockUI, 2000);
				}
				else if (html != "0")
				{
					$('.phpinfo').html(html);
				}
				$.unblockUI();
			}
		});
}

function showNEWS(str)
{
	if (str.length==0)
	  {
	  document.getElementById("rssOutput").innerHTML="";
	  return;
	  }
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
	    {
	    	document.getElementById("rssOutput").innerHTML=xmlhttp.responseText;
	    }
	  }
	xmlhttp.open("GET","?util=news&res="+str,true);
	xmlhttp.send();
}

function checkBlock()
{
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
	    {
	    	if(xmlhttp.responseText=="true")
	    	{
	    		document.getElementById("blockstate").innerHTML="сайт заблокирован";
	    		document.getElementById("blockBtn").value = "Разблокировать";
	    		document.getElementById("do").value = "3";
	    	}
	    	else
	    	{
	    		document.getElementById("blockstate").innerHTML="сайт разблокирован";
	    		document.getElementById("blockBtn").value = "Заблокировать";
	    		document.getElementById("do").value = "2";
	    	}
	    }
	  }
	xmlhttp.open("GET","?util=blocker&do=1",true);
	xmlhttp.send();
}

function chackbase_generate()
{
	$.blockUI(
		{
			message: 'Создаем образ сайта и БД для автоматического сканирования.',
		});

        $.ajax({
		    	type: "POST",
	    		url: "?util=scanfiles",
			    data: "",
			    success: function(html){
			    $.unblockUI();
				if(html == "0")
			    {
					$.blockUI({ message: 'Ошибка создания образа для автоматического сканирования. Обратитесь в поддержку за помощью'});

        			setTimeout($.unblockUI, 2000);
				}
				else if (html != "0")
				{
					$.blockUI({ message: 'Образ сайта и БД для автоматического сканирования создан'});

        			setTimeout($.unblockUI, 2000);
				}
			}
		});
}

function run_auto(util)
{
	$.blockUI( { message: l('Waiting. Santi in working.') });
	switch(util) {
		case "scanfiles":
			$.ajax({
				type: "POST",
				url: "?cron=scanfiles&dosf=1&force=1",
				success: function(html) {
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
		case "scandb":
			$.ajax({
				type: "POST",
				url: "?cron=scandb&force=1",
				success: function(html) {
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
		case "autobu":
			$.ajax({
				type: "POST",
				url: "?cron=autobu&force=1",
				success: function(html) {					
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
		case "dbbackup":
			$.ajax({
				type: "POST",
				url: "?cron=dbbackup&force=1",
				success: function(html) {
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
		case "avscan":
			$.ajax({
				type: "POST",
				url: "?cron=avscan&force=1",
				success: function(html) {
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
		case "autosech":
			$.ajax({
				type: "POST",
				url: "?cron=autosech&force=1",
				success: function(html) {
					$.blockUI({message: "Автопилот "+util+" закончил работу."});
        			setTimeout($.unblockUI, 2000);
				}
			});
		break;
	}
}

function testhost()
{	
	var string = "";
	$.blockUI({ message: 'САНТИ работает. Подождите.', });
	$.ajax({
				type: "POST",
				url: "?util=testhost",
				dataType: "json",
				success: function(data){
					data = 	eval(data);
					for(f in data)
					{
						string += '<div class="form-group '+data[f].type+'"><label class="col-sm-3 control-label" style="text-align: left;">'+data[f].name+'</label><div class="col-sm-3" style="padding-top:7px;">'+data[f].text+'</div><div class="col-sm-6" style="padding-top:7px;">'+data[f].note+'</div></div>';
					}

					$('#step-0').html(string);					
					$.unblockUI();
			}
		});
	return false;
}