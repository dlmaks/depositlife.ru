<?php

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

$min_php_ver = '4.3.2';
$max_execution_time = '30';
$min_memory_limit = '256';
$functions = array('abs', 'addcslashes', 'addslashes', 'array_keys', 'array_map', 'array_pop', 'array_push', 'array_sum', 'array_values', 'basename', 'ceil', 'chdir', 'chmod', 'chr', 'class_exists', 'clearstatcache', 'closedir', 'cos', 'count', 'curl_exec', 'curl_init', 'curl_setopt', 'date', 'define', 'defined', 'dir', 'dirname', 'each', 'end', 'ereg', 'error_log', 'error_reporting', 'exec', 'explode', 'extension_loaded', 'extract', 'fclose', 'feof', 'fgets', 'file', 'file_exists', 'file_get_contents', 'file_put_contents', 'filemtime', 'fileperms', 'filesize', 'flock', 'floor', 'flush', 'fopen', 'fputs', 'fread', 'fseek', 'fsockopen', 'ftell', 'func_get_args', 'function_exists', 'fwrite', 'get_class', 'get_object_vars', 'getcwd', 'getdate', 'gethostbyname', 'gettype', 'glob', 'gzclose', 'gzopen', 'gzread', 'gzwrite', 'header', 'hexdec', 'html_entity_decode', 'htmlentities', 'htmlspecialchars', 'iconv', 'ignore_user_abort', 'implode', 'in_array', 'ini_get', 'ini_set', 'intval', 'is_a', 'is_array', 'is_dir', 'is_file', 'is_null', 'is_numeric', 'is_object', 'is_readable', 'is_subclass_of', 'join', 'json_decode', 'json_encode', 'ksort', 'log', 'ltrim', 'mail', 'max', 'mb_convert_encoding', 'mb_internal_encoding', 'mb_strlen', 'microtime', 'min', 'mkdir', 'mktime', 'mt_rand', 'mt_srand', 'mysql_connect', 'mysql_error', 'mysql_fetch_array', 'mysql_fetch_assoc', 'mysql_fetch_row', 'mysql_free_result', 'mysql_get_server_info', 'mysql_query', 'mysql_real_escape_string', 'mysql_select_db', 'mysql_set_charset', 'mysql_unbuffered_query', 'next', 'ob_end_clean', 'ob_end_flush', 'ob_get_contents', 'ob_start', 'octdec', 'opendir', 'ord', 'pack', 'parse_ini_file', 'parse_url', 'pathinfo', 'pfsockopen', 'phpinfo', 'phpversion', 'pi', 'pow', 'preg_match', 'preg_match_all', 'preg_quote', 'preg_replace', 'prev', 'print_r', 'range', 'rawurlencode', 'readdir', 'realpath', 'rename', 'reset', 'round', 'rsort', 'rtrim', 'serialize', 'session_destroy', 'session_start', 'set_error_handler', 'set_time_limit', 'setcookie', 'sin', 'sizeof', 'sleep', 'socket_get_status', 'socket_set_blocking', 'socket_set_timeout', 'sort', 'split', 'sprintf', 'sqrt', 'stat', 'str_replace', 'strcmp', 'strftime', 'strip_tags', 'stripos', 'stripslashes', 'stristr', 'strlen', 'strpos', 'strrpos', 'strtolower', 'strtotime', 'strtoupper', 'strval', 'substr', 'substr_count', 'substr_replace', 'time', 'trigger_error', 'trim', 'unlink', 'unserialize', 'urldecode', 'urlencode', 'usort', 'var_dump', 'var_export', 'xml_error_string', 'xml_get_current_line_number', 'xml_get_error_code', 'xml_parse', 'xml_parser_create_ns', 'xml_parser_free', 'xml_parser_set_option', 'xml_set_character_data_handler', 'xml_set_element_handler', 'xml_set_object');

$text = phpversion();
if (@version_compare(phpversion(), $min_php_ver, ">=")) {
    $class = 'ok';
    $note = '';
} else {
    $class = 'err';
    $note = 'Требуется минимум ' . $min_php_ver;
}
$result[] = array("type"=>$class, "name"=>"Версия PHP", "text"=>$text, "note"=>$note);

$text = @ini_get('max_execution_time');
if (($text >= $max_execution_time) || ($text == 0)) {
    $class = 'ok';
    $note = '';
} else {
    $class = 'warn';
    $note = 'может вызвать проблемы при резервном копировании файлов/БД, при сканировании объёмных сайтов';
}
$text .= ' cек.'; 
$result[] = array("type"=>$class, "name"=>"Время исполнения скрипта", "text"=>$text, "note"=>$note);

$text = @ini_get('memory_limit');
if (strpos($text, 'M') !== false) {
    $text = str_replace('M', '', $text);
}
$note = 'требуемый объем памяти не прогнозируем, т.к. некоторые скрипты будут требовать памяти равноценно размеру сайта';
if ($text >= $min_memory_limit) $class = 'ok';
else  $class = 'warn';
$text .= 'M'; 
$result[] = array("type"=>$class, "name"=>"Объем памяти", "text"=>$text, "note"=>$note);

if (@extension_loaded('zip')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'не будет работать резервное копирование файлов/БД сайта';
} 
$result[] = array("type"=>$class, "name"=>"Расширение zip", "text"=>$text, "note"=>$note);

if (@extension_loaded('session')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'не будет работать авторизация';
} 
$result[] = array("type"=>$class, "name"=>"Расширение session", "text"=>$text, "note"=>$note);

if (@extension_loaded('curl')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'установите расширение curl';
}
//$result[] = array("type"=>$class, "name"=>"Расширение curl", "text"=>$text, "note"=>$note);

if (@extension_loaded('sockets')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'warn';
    $text = 'не установлено';
    $note = 'не будет удаленных автопилотов, проверки обновлений';
}
//$result[] = array("type"=>$class, "name"=>"Расширение sockets", "text"=>$text, "note"=>$note);

if (@extension_loaded('iconv')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'установите расширение iconv';
}
$result[] = array("type"=>$class, "name"=>"Расширение iconv", "text"=>$text, "note"=>$note);

if (@extension_loaded('json')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'установите расширение json';
} 
$result[] = array("type"=>$class, "name"=>"Расширение json", "text"=>$text, "note"=>$note);

if (@extension_loaded('mbstring')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'установите расширение mbstring';
} 
$result[] = array("type"=>$class, "name"=>"Расширение mbstring", "text"=>$text, "note"=>$note);

if (@extension_loaded('xml')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'err';
    $text = 'не установлено';
    $note = 'установите расширение xml';
} 
$result[] = array("type"=>$class, "name"=>"Расширение xml", "text"=>$text, "note"=>$note);

if (@extension_loaded('mysql')) {
    $class = 'ok';
    $text = 'установлено';
    $note = '';
} else {
    $class = 'warn';
    $text = 'не установлено';
    $note = 'не будет возможность резервного копирования БД';
} 
$result[] = array("type"=>$class, "name"=>"Расширение mysql", "text"=>$text, "note"=>$note);

$text = 'все функции присутствуют';
$note = array();
$class = 'ok';
foreach ($functions as $func) {
    if (!function_exists($func)) {
        $class = 'err';
        $note[] = $func;
    }
}
if (!empty($note)) {
    $text = 'отсуствуют некоторые функции';
    $note = implode('<br>', $note);
} else  $note = ''; 
$result[] = array("type"=>$class, "name"=>"Необходимые функции", "text"=>$text, "note"=>$note);

$text = @ini_get('disable_functions');
$text = explode(',', $text);
foreach ($text as &$func) {
    $func = trim(strtolower($func));
}
$note = array();
$class = 'ok';
foreach ($functions as $func) {
    if (array_search($func, $text)) {
        $class = 'err';
        $note[] = $func;
    }
}
if (!empty($note)) {
    $text = 'запрещены некоторые функции';
    $note = implode('<br>', $note);
} else  {
    $text = 'все необходимые функции включены';
    $note = '';
} 
$result[] = array("type"=>$class, "name"=>"Отключенные функции", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'доступ есть';
$note = '';
if (!is_writable('config.php')) {
    $class = 'err';
    $text = 'нет доступа';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
} 
$result[] = array("type"=>$class, "name"=>"Доступ к файлу конфигурации на запись", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'папка создана';
$note = '';
if (!@mkdir('datas/unarchive/test', octdec('0770'))) {
    $class = 'err';
    $text = 'не получилось создать папку';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
} 
$result[] = array("type"=>$class, "name"=>"Создание тестовой папки распаковки", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'файл открылся';
$note = '';
if (!@$fp = fopen('datas/unarchive/test/test.txt', 'xb')) {
    $class = 'err';
    $text = 'не получилось открыть файл';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
} 
$result[] = array("type"=>$class, "name"=>"Открытие тестового файла для записи распаковки", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'успешная запись';
$note = '';
if (!@fwrite($fp, '_stub')) {
    $class = 'err';
    $text = 'не получилось записать в файл';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
}
@fclose ($fp); 
$result[] = array("type"=>$class, "name"=>"Запись в тестовый файл", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'файл открылся';
$note = '';
if (!@$fp = fopen('datas/unarchive/test/test.txt', 'rb')) {
    $class = 'err';
    $text = 'не получилось открыть файл';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
} 
$result[] = array("type"=>$class, "name"=>"Открытие тестового файла для чтения", "text"=>$text, "note"=>$note);

$class = 'ok';
$text = 'ошибок нет';
$note = '';
if (!($buffer = @fread($fp, 5)) || $buffer != '_stub') {
    $class = 'err';
    $text = 'не получилось прочитать из тестового файла';
    $note = 'измените права папок — 755 и файлов — 644 или обратитесь в техподдержку своего хостинга';
}
@fflush($fp);
@fclose($fp);
@unlink('datas/unarchive/test/test.txt');
@rmdir('datas/unarchive/test'); 
$result[] = array("type"=>$class, "name"=>"Чтение из тестового файла", "text"=>$text, "note"=>$note);

if (!function_exists('json_encode')) {
    function json_encode($content) {
        require_once 'lib/JSON.php';
        $json = new Services_JSON;
        die($json->encode($content));
    }
}

die(json_encode($result));

?>