<?php

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

to_log(0);

if(isset($_POST['yadlogin']))
	$yadlogin = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadlogin'])))); 
else 
	$yadlogin = SANTI_CLOUD_LOGIN;

if(isset($_POST['yadpassword'])) 
	$yadpassword = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadpassword'])))); 
else 
	$yadpassword = SANTI_CLOUD_PASSWORD;

if(isset($_POST['cloud'])) 
	$cloud = addslashes(htmlspecialchars(strip_tags(trim($_POST['cloud'])))); 
else 
	$cloud = SANTI_CLOUD;

if(isset($_POST['cloud_url']))
	$cloud_url = addslashes(htmlspecialchars(strip_tags(trim($_POST['cloud_url']))));
else 
	$cloud_url = SANTI_CLOUD_URL;

$cronhand = SANTI_CRON_HAND ? "true" : "false";
$autoupdate = SANTI_AUTO_UPDATE ? "true" : "false";
$infomail = SANTI_INFO_EMAIL ? "true" : "false";
$infosms = SANTI_INFO_SMS ? "true" : "false";

$h = fopen("config.php","w");
$text = "<?php

/* Язык */
define('SANTI_LANG', '".SANTI_LANG."');

/** Имя администратора антивируса */
define('SANTI_NAME', '".SANTI_NAME."');

/** Пароль администратора антивируса */
define('SANTI_PASSWORD', '".SANTI_PASSWORD."');

/** KEY сканера по настольным антивирусам */
define('SANTI_4KEY', '".SANTI_4KEY."');

/** TOKEN сканера по настольным антивирусам */
define('SANTI_4TOKEN', '".SANTI_4TOKEN."');

/** URL сайта**/
define('SANTI_URL', '".SANTI_URL."');

/** Папка с SANTI/**/
define('SANTI_PATH', '".SANTI_PATH."');

/** Серверный путь к сайту/**/
define('SANTI_SERVERPATH', '".SANTI_SERVERPATH."');

/** Часовой пояс/**/
define('SANTI_TIMEZONE', '".SANTI_TIMEZONE."');

/** Ручной запуск автопилотов **/
define('SANTI_CRON_HAND', ".$cronhand.");

/** Автоматическое обновление баз сигнатур/**/
define('SANTI_AUTO_UPDATE', ".$autoupdate.");

/** Имя сервера активной MySQL */
define('SANTI_DB_HOST', '".SANTI_DB_HOST."');

/** Имя активной MySQL */
define('SANTI_DB_NAME', '".SANTI_DB_NAME."');

/** Имя пользователя активной MySQL */
define('SANTI_DB_USER', '".SANTI_DB_USER."');

/** Пароль доступа к активной MySQL */
define('SANTI_DB_PASSWORD', '".SANTI_DB_PASSWORD."');

/** Имя сервера копии MySQL */
define('SANTI_DBKOP_HOST', '".SANTI_DBKOP_HOST."');

/** Имя копии MySQL */
define('SANTI_DBKOP_NAME', '".SANTI_DBKOP_NAME."');

/** Имя пользователя копии MySQL */
define('SANTI_DBKOP_USER', '".SANTI_DBKOP_USER."');

/** Пароль доступа к копии MySQL */
define('SANTI_DBKOP_PASSWORD', '".SANTI_DBKOP_PASSWORD."');

/** Кодировка базы данных. */
define('SANTI_DB_CHARSET', '".SANTI_DB_CHARSET."');

/** Тип файлового хранилища (облака) */
define('SANTI_CLOUD', '$cloud');

/** Адрес файлового хранилища (облака) */
define('SANTI_CLOUD_URL', '$cloud_url');

/** логин к облаку */
define('SANTI_CLOUD_LOGIN', '$yadlogin');

/** Пароль к облаку */
define('SANTI_CLOUD_PASSWORD', '$yadpassword');

/** Папки и файлы исключения через , */
define('SANTI_STOPF', '".SANTI_STOPF."');

/** Папки и файлы исключения backup через , */
define('SANTI_STOPB', '".SANTI_STOPB."');

/** Таблицы исключения БД */
define('SANTI_STOPT', '".SANTI_STOPT."');

/** ID антивируса */
define('SANTI_ID', '".SANTI_ID."');

/** Почта администратора антивируса */
define('SANTI_EMAIL', '".SANTI_EMAIL."');

/** Телефона администратора антивируса */
define('SANTI_PHONE', '".SANTI_PHONE."');

/** Уведомлять ли по email */
define('SANTI_INFO_EMAIL', ".$infomail.");

/** Уведомлять ли по смс */
define('SANTI_INFO_SMS', ".$infosms.");

/** Логин к СМС агрегатору */
define('SANTI_SMS_USER', '".SANTI_SMS_USER."');

/** Пароль к СМС агрегатору */
define('SANTI_SMS_PASSWORD', '".SANTI_SMS_PASSWORD."');

/** Первый запуск**/
define('SANTI_START', '".SANTI_START."');

/** Первый запуск**/
define('SANTI_VERSION', '".SANTI_VERSION."');

/** Абсолютный путь автоматом **/
define('ABSPATH', dirname(__FILE__).'/');

set_time_limit(0);
date_default_timezone_set(SANTI_TIMEZONE);

?>";

if(fwrite($h,$text))
	fclose($h);
else
	die("0");

die("1");

?>