<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if (isset($_POST['startdate'])) $startdate = addslashes(htmlspecialchars(strip_tags(trim($_POST['startdate'])))); else die("0");
if (isset($_POST['finishdate'])) $finishdate = addslashes(htmlspecialchars(strip_tags(trim($_POST['finishdate'])))); else die("0");
if (isset($_POST['extensions'])) $extensions = addslashes(htmlspecialchars(strip_tags(trim($_POST['extensions'])))); else die("0");
if (isset($_POST['dofs'])) $dofs = addslashes(htmlspecialchars(strip_tags(trim($_POST['dofs'])))); else die("0");

$sdarr = explode(".", $startdate);
$startdate = mktime(0, 0, 0, $sdarr[1], $sdarr[0], $sdarr[2]);
$fdarr = explode(".", $finishdate);
$finishdate = mktime(24, 0, 0, $fdarr[1], $fdarr[0], $fdarr[2]);

chdir('../');
$dir = getcwd().'/';
$ext = array(); 
$results = array();
$ext = explode(",", str_replace(" ", "", $extensions));
$dofsb = false;

switch ($dofs) {
    case '1':
        break;
    case '2':
            $dofsb = true;
        break;
    case '3':
            $ext = null;
        break;    
    default:
        die("0");
        break;
}

dir_walk($dir, $ext, true, $dir, $startdate, $finishdate, $dofsb);

function dir_walk($dir, $types = null, $recursive = false, $baseDir = '', $start_date, $finish_date, $dofsb)
{
    global $results;
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh))!== false) 
        {

            if ($file === '.' || $file === '..') 
            {
                continue;
            }
            if (is_file($dir.$file)) 
            {

                if(strpos($dir.$file, SANTI_PATH) !== false)
                    continue;

                if (is_array($types)) 
                {
                    if($dofsb)
                    {
                        if (!in_array(strtolower(pathinfo($dir.$file, PATHINFO_EXTENSION)), $types, true)) 
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (in_array(strtolower(pathinfo($dir.$file, PATHINFO_EXTENSION)), $types, true)) 
                        {
                            continue;
                        }
                    }
                }

                $chang_date = filemtime($dir.$file);

                if (($start_date < $chang_date) && ($chang_date < $finish_date))
                    $results[] = array('file' => str_replace("\\", "/", $dir.$file), 'date' => date('d.m.Y H:i:s', $chang_date));
            }
            elseif($recursive && is_dir($dir . $file))
            {
                dir_walk($dir . $file . DIRECTORY_SEPARATOR, $types, $recursive, $baseDir . $file . DIRECTORY_SEPARATOR, $start_date, $finish_date, $dofsb);
            }
        }
        closedir($dh);
    }
}

if (!function_exists('json_encode')) {
    function json_encode($content) {
        require_once 'lib/JSON.php';
        $json = new Services_JSON;
        return $json->encode($content);
    }
}

echo json_encode($results);

?>