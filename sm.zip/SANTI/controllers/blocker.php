<?php

//     Типы действий:
//     1 - проверить статус;
//     2 - заблокировать;
//     3 - разблокировать
// вернуть -1 - ошибка чтения файла - допилить

if (!isset($_SESSION['auth']))
{
    die("0");
}

if(isset($_GET["do"])) $do = addslashes(htmlspecialchars(strip_tags(trim($_GET["do"])))); else die("0");
if(isset($_GET['ip']) && !empty($_GET['ip'])) $ip = addslashes(htmlspecialchars(strip_tags(trim($_GET['ip'])))); else $ip = '';

function checkState() {
    if(is_file('../.htaccess.bak'))
        return "true";
    else
        return "false";
}

function block($ip) {
	if(!is_file('../.htaccess')) file_put_contents('../.htaccess', '');
    if(is_file('../.htaccess') && !is_file('../.htaccess.bak')) rename('../.htaccess', '../.htaccess.bak');
    $f = fopen("../.htaccess", "a");
    $ips = explode(',', $ip);
    fwrite($f, "# santi-block\nRewriteEngine on\nRewriteCond %{REQUEST_URI} !".SANTI_PATH."/*\n");
    if($ip)
		foreach($ips as $i) fwrite($f, "RewriteCond %{REMOTE_ADDR} !^".trim($i)."\n");
    fwrite($f, "RewriteRule $ /".SANTI_PATH."/block/index.php [R=302,L]\n# /santi-block");
    fclose($f);
    return true;
}

function unblock() {
    unlink('../.htaccess');
    if(is_file('../.htaccess.bak'))
	rename('../.htaccess.bak', '../.htaccess');
    return true;
}

switch ($do)
{
    case "1":
    {
        die(checkState());
    } break;
    case "2":
    {
        die(block($ip));
    } break;
    case "3":
    {
        die(unblock());
    } break;
}


?>