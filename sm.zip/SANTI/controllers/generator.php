<?php

//     Типы генераций:
//     1 - любые символы в любом регистре;
//     2 - символы, цифры и буквы английского алфавита в нижнем и верхнем регистрах;
//     3 - буквы+цифры в верхнем и нижнем регистрах, исключая сочетания l10O, 
//     т.е. это буква 'L' в нижнем регистре, единичка, ноль, буква 'O' в верхнем регистре.

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if(isset($_POST['passlength'])) $passlength = addslashes(htmlspecialchars(strip_tags(trim($_POST['passlength'])))); else die("0");
if(isset($_POST['passtype'])) $passtype = addslashes(htmlspecialchars(strip_tags(trim($_POST['passtype'])))); else die("0");

function GeneratePassword($Length = 8, $Type = 3) {
  $limits='';
  switch ($Type) :
    case "1":
      $limits='40-59,61-91,93-126'; break;
    case "2":
      $limits='65-90,97-122,48-57'; break;
    case "3":
      $limits='65-78,80-90,97-107,109-122,50-57'; break;
    
  endswitch;
  if ($limits<>'') :
    $limit=explode(',',$limits);
    mt_srand(time());
    $res = '';
    for ($i = 1; $i <= $Length; $i++) :
      $nrand = mt_rand(0, count($limit)-1);
      list($min,$max) = explode('-', $limit[$nrand]);
      $res.=chr(mt_rand($min,$max));
    endfor;
    return $res;         
  endif;
}
    
die(GeneratePassword($passlength, $passtype));

?>