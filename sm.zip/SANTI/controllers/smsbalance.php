<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

$error = false;
function my_error_handler($code, $msg, $file, $line) 
{global $error; $error = true;}

//set_error_handler('my_error_handler');
$login = SANTI_SMS_USER;
$password = SANTI_SMS_PASSWORD;
			
$sms = new SMSClass($login, $password);
$result = $sms->GetBalance();
die(strip_tags($result));

?>
