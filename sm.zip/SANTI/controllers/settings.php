<?php

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

to_log(0);

if(isset($_POST['login'])) $login = addslashes(htmlspecialchars(strip_tags(trim($_POST['login'])))); else $login = SANTI_NAME;
if(isset($_POST['pwd'])) $pwd = addslashes(htmlspecialchars(strip_tags(trim($_POST['pwd'])))); else $pwd = SANTI_PASSWORD;
if(isset($_POST['lang'])) $lang = addslashes(htmlspecialchars(strip_tags(trim($_POST['lang'])))); else $lang = SANTI_LANG;
if(isset($_POST['url'])) $url = addslashes(htmlspecialchars(strip_tags(trim($_POST['url'])))); else $url = SANTI_URL;
if(isset($_POST['path'])) $path = addslashes(htmlspecialchars(strip_tags(trim($_POST['path'])))); else $path = SANTI_PATH;
if(isset($_POST['cronhand'])) $cronhand = addslashes(htmlspecialchars(strip_tags(trim($_POST['cronhand'])))); else $cronhand = SANTI_CRON_HAND ? "true" : "false";
if(isset($_POST['autoupdate'])) $autoupdate = addslashes(htmlspecialchars(strip_tags(trim($_POST['autoupdate'])))); else $autoupdate = SANTI_AUTO_UPDATE ? "true" : "false";
if(isset($_POST['addressbd'])) $addressbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['addressbd'])))); else $addressbd = SANTI_DB_HOST;
if(isset($_POST['namebd'])) $namebd = addslashes(htmlspecialchars(strip_tags(trim($_POST['namebd'])))); else $namebd = SANTI_DB_NAME;
if(isset($_POST['loginbd'])) $loginbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['loginbd'])))); else $loginbd = SANTI_DB_USER;
if(isset($_POST['passwordbd'])) $passwordbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['passwordbd'])))); else $passwordbd = SANTI_DB_PASSWORD;
if(isset($_POST['addresskopbd'])) $addresskopbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['addresskopbd'])))); else $addresskopbd = SANTI_DBKOP_HOST;
if(isset($_POST['namekopbd'])) $namekopbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['namekopbd'])))); else $namekopbd = SANTI_DBKOP_NAME;
if(isset($_POST['loginkopbd'])) $loginkopbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['loginkopbd'])))); else $loginkopbd = SANTI_DBKOP_USER;
if(isset($_POST['passwordkopbd'])) $passwordkopbd = addslashes(htmlspecialchars(strip_tags(trim($_POST['passwordkopbd'])))); else $passwordkopbd = SANTI_DBKOP_PASSWORD;
if(isset($_POST['cod'])) $cod = addslashes(htmlspecialchars(strip_tags(trim($_POST['cod'])))); else $cod = SANTI_DB_CHARSET;
if(isset($_POST['yadlogin'])) $yadlogin = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadlogin'])))); else $yadlogin = SANTI_CLOUD_LOGIN;
if(isset($_POST['yadpassword'])) $yadpassword = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadpassword'])))); else $yadpassword = SANTI_CLOUD_PASSWORD;
if(isset($_POST['stopfiles'])) $stopfiles = addslashes(htmlspecialchars(strip_tags(trim($_POST['stopfiles'])))); else $stopfiles = SANTI_STOPF;
if(isset($_POST['stopbakfiles'])) $stopbakfiles = addslashes(htmlspecialchars(strip_tags(trim($_POST['stopbakfiles'])))); else $stopbakfiles = SANTI_STOPB;
if(isset($_POST['stoptables'])) $stoptables = addslashes(htmlspecialchars(strip_tags(trim($_POST['stoptables'])))); else $stoptables = SANTI_STOPT;
if(isset($_POST['santiid'])) $santiid = addslashes(htmlspecialchars(strip_tags(trim($_POST['santiid'])))); else $santiid = SANTI_ID;
if(isset($_POST['email'])) $email = addslashes(htmlspecialchars(strip_tags(trim($_POST['email'])))); else $email = SANTI_EMAIL;
if(isset($_POST['phone'])) $phone = addslashes(htmlspecialchars(strip_tags(trim($_POST['phone'])))); else $phone = SANTI_PHONE;
if(isset($_POST['infomail'])) $infomail = addslashes(htmlspecialchars(strip_tags(trim($_POST['infomail'])))); else $infomail = SANTI_INFO_EMAIL ? "true" : "false";
if(isset($_POST['infosms'])) $infosms = addslashes(htmlspecialchars(strip_tags(trim($_POST['infosms'])))); else $infosms = SANTI_INFO_SMS ? "true" : "false";
if(isset($_POST['serverpath'])) $serverpath = addslashes(htmlspecialchars(strip_tags(trim($_POST['serverpath'])))); else $serverpath = SANTI_SERVERPATH;
if(isset($_POST['av_user'])) $av_user = addslashes(htmlspecialchars(strip_tags(trim($_POST['av_user'])))); else $av_user = SANTI_SMS_USER;
if(isset($_POST['av_password'])) $av_password = addslashes(htmlspecialchars(strip_tags(trim($_POST['av_password'])))); else $av_password = SANTI_SMS_PASSWORD;
if(isset($_POST['timezone'])) $timezone = addslashes(htmlspecialchars(strip_tags(trim($_POST['timezone'])))); else $timezone = SANTI_TIMEZONE;
if(isset($_POST['cloud'])) $cloud = addslashes(htmlspecialchars(strip_tags(trim($_POST['cloud'])))); else $cloud = SANTI_CLOUD;
if(isset($_POST['cloud_url'])) $cloud_url = addslashes(htmlspecialchars(strip_tags(trim($_POST['cloud_url'])))); else $cloud_url = SANTI_CLOUD_URL;
if(isset($_POST['santi_start'])) $santi_start = 0; else $santi_start = SANTI_START;
if(isset($_POST['addstopf'])) {
	$addstopf = addslashes(htmlspecialchars(strip_tags(trim($_POST['addstopf']))));
	$addstopf = str_replace(SANTI_SERVERPATH.'/', '', $addstopf);
	if(strpos(SANTI_STOPF, $addstopf) == false)
		$stopfiles .= ', '.$addstopf;
}

if ($pwd == "d41d8cd98f00b204e9800998ecf8427e")
	$pwd = SANTI_PASSWORD;

$s4u_key = "";
$s4u_token = "";

if($santiid != "")
{
	$post = "santi_id=".$santiid."&url=".$url."&email=".$email;

	$result = tcp_send("santivi.com", array(
	                            "POST /crons/avscanreg.php HTTP/1.1\r\n",
	                            "Host: santivi.com\r\n",
	                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
	                            "Content-Type: application/x-www-form-urlencoded\r\n",
	                            "Content-Length: ".strlen($post)."\r\n",
	                            "Connection: close\r\n\r\n",
	                            $post,
	                        )
	);

	if(strpos($result, "no_sid") || strpos($result, "no_url") || strpos($result, "no_email") || strpos($result, "sid_error"))
	{}
	else
	{
		$jsonpos = strpos($result, '{');
		$result = substr($result, $jsonpos, strpos($result, '}') - $jsonpos + 1);
		$answer = json_decode($result, 1);
		$s4u_key = $answer['s4y_id'];
		$s4u_token = $answer['s4y_token'];
	}
}

$h = fopen("config.php","w");
$text = "<?php

/* Язык */
define('SANTI_LANG', '$lang');

/** Имя администратора антивируса */
define('SANTI_NAME', '$login');

/** Пароль администратора антивируса */
define('SANTI_PASSWORD', '$pwd');

/** KEY сканера по настольным антивирусам */
define('SANTI_4KEY', '$s4u_key');

/** TOKEN сканера по настольным антивирусам */
define('SANTI_4TOKEN', '$s4u_token');

/** URL сайта**/
define('SANTI_URL', '$url');

/** Папка с SANTI/**/
define('SANTI_PATH', '$path');

/** Серверный путь к сайту/**/
define('SANTI_SERVERPATH', '$serverpath');

/** Часовой пояс/**/
define('SANTI_TIMEZONE', '$timezone');

/** Ручной запуск автопилотов **/
define('SANTI_CRON_HAND', $cronhand);

/** Автоматическое обновление баз сигнатур/**/
define('SANTI_AUTO_UPDATE', $autoupdate);

/** Имя сервера активной MySQL */
define('SANTI_DB_HOST', '$addressbd');

/** Имя активной MySQL */
define('SANTI_DB_NAME', '$namebd');

/** Имя пользователя активной MySQL */
define('SANTI_DB_USER', '$loginbd');

/** Пароль доступа к активной MySQL */
define('SANTI_DB_PASSWORD', '$passwordbd');

/** Имя сервера копии MySQL */
define('SANTI_DBKOP_HOST', '$addresskopbd');

/** Имя копии MySQL */
define('SANTI_DBKOP_NAME', '$namekopbd');

/** Имя пользователя копии MySQL */
define('SANTI_DBKOP_USER', '$loginkopbd');

/** Пароль доступа к копии MySQL */
define('SANTI_DBKOP_PASSWORD', '$passwordkopbd');

/** Кодировка базы данных. */
define('SANTI_DB_CHARSET', '$cod');

/** Тип файлового хранилища (облака) */
define('SANTI_CLOUD', '$cloud');

/** Адрес файлового хранилища (облака) */
define('SANTI_CLOUD_URL', '$cloud_url');

/** логин к облаку */
define('SANTI_CLOUD_LOGIN', '$yadlogin');

/** Пароль к облаку */
define('SANTI_CLOUD_PASSWORD', '$yadpassword');

/** Папки и файлы исключения через , */
define('SANTI_STOPF', '$stopfiles');

/** Папки и файлы исключения backup через , */
define('SANTI_STOPB', '$stopbakfiles');

/** Таблицы исключения БД */
define('SANTI_STOPT', '$stoptables');

/** ID антивируса */
define('SANTI_ID', '$santiid');

/** Почта администратора антивируса */
define('SANTI_EMAIL', '$email');

/** Телефона администратора антивируса */
define('SANTI_PHONE', '$phone');

/** Уведомлять ли по email */
define('SANTI_INFO_EMAIL', $infomail);

/** Уведомлять ли по смс */
define('SANTI_INFO_SMS', $infosms);

/** Логин к СМС агрегатору */
define('SANTI_SMS_USER', '$av_user');

/** Пароль к СМС агрегатору */
define('SANTI_SMS_PASSWORD', '$av_password');

/** Первый запуск**/
define('SANTI_START', '$santi_start');

/** Первый запуск**/
define('SANTI_VERSION', '0.6');

/** Абсолютный путь автоматом **/
define('ABSPATH', dirname(__FILE__).'/');

set_time_limit(0);
date_default_timezone_set(SANTI_TIMEZONE);

?>";

if(fwrite($h,$text))
	fclose($h);
else
	die("0");

die("1");

function tcp_send($board, $data)
{
        $answer = "";

        // Get IP
        $ip = gethostbyname($board);
        // Open socket
        $fp = fsockopen($ip, 80);

        if ( $fp )
        {
            // Set HTTP header
            foreach( $data as $row )
            {
                fputs($fp, $row);
            }

            // Get an answer
            while( !feof($fp) )
            {
                $answer .= fread($fp, 512);
            }

            fclose($fp);
        }

        return $answer;
}

?>