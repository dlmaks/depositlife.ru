<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

include_once('lib/clouds.php');

if(isset($_GET['del']) && $_GET['del']==='dropbox') {
	unlink('datas/tokens/dropbox.token');
	exit;
}
if(isset($_GET['del']) && $_GET['del']==='google') {
	unlink('datas/tokens/google.token');
	exit;
}

$file = 'datas/test.txt';
file_put_contents($file, 'test');
send_to_cloud($file);
