<?php
// 0- ошибка, 1 - сохранилось

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

if (isset($_POST['auto_id'])) $auto_id = addslashes(htmlspecialchars(strip_tags(trim($_POST['auto_id'])))); //1 - файловый скан, 2 - скан бд, 3 - бекап, 4 - скан пс, 5 - скан браузером.
if (isset($_POST['status_files'])) $status_files = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_files'])))); else { STATUS_FILES ? $status_files = 'true' : $status_files = 'false'; }
if (isset($_POST['cron_files'])) $cron_files = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_files'])))); else $cron_files = CRON_FILES;

if (isset($_POST['status_db'])) $status_db = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_db'])))); else { STATUS_DB ? $status_db = 'true' : $status_db = 'false'; }
if (isset($_POST['cron_db'])) $cron_db = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_db'])))); else $cron_db = CRON_DB;

if (isset($_POST['status_bu'])) $status_bu = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_bu'])))); else { STATUS_BU ? $status_bu = 'true' : $status_bu = 'false';}
if (isset($_POST['yadisk_bu'])) $yadisk_bu = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadisk_bu'])))); else { CLOUDDISK_BU ? $yadisk_bu = 'true' : $yadisk_bu = 'false'; }
if (isset($_POST['cron_bu'])) $cron_bu = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_bu'])))); else $cron_bu = CRON_BU;

if (isset($_POST['status_bud'])) $status_bud = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_bud'])))); else { STATUS_BUD ? $status_bud = 'true' : $status_bud = 'false';}
if (isset($_POST['yadisk_bud'])) $yadisk_bud = addslashes(htmlspecialchars(strip_tags(trim($_POST['yadisk_bud'])))); else { CLOUDDISK_BUD ? $yadisk_bud = 'true' : $yadisk_bud = 'false'; }
if (isset($_POST['cron_bud'])) $cron_bud = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_bud'])))); else $cron_bud = CRON_BUD;

if (isset($_POST['status_sech'])) $status_sech = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_sech'])))); else { STATUS_SECH ? $status_sech = 'true' : $status_sech = 'false'; }
if (isset($_POST['alert_sech'])) $alert_sech = addslashes(htmlspecialchars(strip_tags(trim($_POST['alert_sech'])))); else { ALERT_SECH ? $alert_sech = 'true' : $alert_sech = 'false'; }
if (isset($_POST['cron_sech'])) $cron_sech = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_sech'])))); else $cron_sech = CRON_SECH;

if (isset($_POST['status_brch'])) $status_brch = addslashes(htmlspecialchars(strip_tags(trim($_POST['status_brch'])))); else { STATUS_BRCH ? $status_brch = 'true' : $status_brch = 'false'; }
if (isset($_POST['cron_brch'])) $cron_brch = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_brch'])))); else $cron_brch = CRON_BRCH;

if (isset($_POST['cron_hand'])) $cron_hand = addslashes(htmlspecialchars(strip_tags(trim($_POST['cron_hand'])))); else $cron_hand = false;

$h = fopen("autoconfig.php","w");
$text = "<?php

/** Статус файлового сканера */
define('STATUS_FILES', $status_files);

/** Периодичность запуска**/
define('CRON_FILES', $cron_files);

/** Статус сканера БД**/
define('STATUS_DB', $status_db);

/** Периодичность сканирования БД */
define('CRON_DB', $cron_db);

/** Статус бекапинга */
define('STATUS_BU', $status_bu);

/** Бекапить ли в Yandex.DISK? */
define('CLOUDDISK_BU', $yadisk_bu);

/** Периодичность бекапинга */
define('CRON_BU', $cron_bu);

/** Статус бекапинга БД */
define('STATUS_BUD', $status_bud);

/** Бекапить ли БД в Yandex.DISK? */
define('CLOUDDISK_BUD', $yadisk_bud);

/** Периодичность бекапинга БД */
define('CRON_BUD', $cron_bud);

/** Статус проверки в ПС */
define('STATUS_SECH', $status_sech);

/** Сообщать ли о новых страницах в поиске */
define('ALERT_SECH', $alert_sech);

/** Периодичность проверки ПС */
define('CRON_SECH', $cron_sech);

/** Статус браузерной проверки */
define('STATUS_BRCH', $status_brch);

/** Периодичность браузерной проверки */
define('CRON_BRCH', $cron_brch);

?>";

fwrite($h, $text) or die('not_write');
fclose($h);
sleep(2);

$stats = array(
	$status_files,
	$status_db,
	$status_bu,
	$status_sech,
	$status_brch,
	'',
	$status_bud,
);
$chs = array(
	$cron_files,
	$cron_db,
	$cron_bu,
	$cron_sech,
	$cron_brch,
	'',
	$cron_bud,
);

//автопилоты(auto_id) - 1 - сканирование файлов, 2 - сканирование БД, 3 - бекапинг, 4 - сканирование ПС, 5 - браузерное сканирование,
//  6 - самозащита, 7 - бекапинг БД

if(isset($_POST['auto_id']) && !SANTI_CRON_HAND) {
	$result = autopilot_register($stats[$auto_id - 1]==='true' ? 1 : 0, $auto_id, $chs[$auto_id - 1]);
	die($result);
}

if (SANTI_CRON_HAND || $cron_hand==='true') {
	autopilot_register(0, 1);
	autopilot_register(0, 2);
	autopilot_register(0, 3);
	autopilot_register(0, 4);
	autopilot_register(0, 5);
	autopilot_register(0, 6);
	autopilot_register(0, 7);
	die('ok_write');
}

if(STATUS_FILES) autopilot_register(1, 1, CRON_FILES); else autopilot_register(0, 1, CRON_FILES);
if(STATUS_DB) autopilot_register(1, 2, CRON_DB); else autopilot_register(0, 2, CRON_DB);
if(STATUS_BU) autopilot_register(1, 3, CRON_BU); else autopilot_register(0, 3, CRON_BU);
if(STATUS_SECH) autopilot_register(1, 4, CRON_SECH); else autopilot_register(0, 4, CRON_SECH);
if(STATUS_BRCH) autopilot_register(1, 5, CRON_BRCH); else autopilot_register(0, 5, CRON_BRCH);
if(STATUS_BUD) autopilot_register(1, 7, CRON_BUD); else autopilot_register(0, 7, CRON_BUD);
$result = autopilot_register(1, 6, CRON_FILES);
die($result);

function autopilot_register($doc, $auto_id, $ch = 2)
{
	$data = "doc=".urlencode($doc)."&ids=".urlencode(SANTI_ID)."&ida=".urlencode($auto_id)."&url=".urlencode(SANTI_URL)."&path=".urlencode(SANTI_PATH)."&ch=".urlencode($ch)."&ver=".urlencode(SANTI_VERSION);

    $result = tcp_send("www.santivi.com", array(
                            "POST /crons/crons.php HTTP/1.1\r\n",
                            "Host: www.santivi.com\r\n",
                            "User-Agent: SANTI\r\n", 
                            "Content-Type: application/x-www-form-urlencoded\r\n",
                            "Content-Length: ".strlen($data)."\r\n",
                            "Connection: close\r\n\r\n",
                            $data,
                        )
    );

    return $result;
}

function tcp_send($board, $data)
{
        $answer = "";
        $ip = gethostbyname($board);
        $fp = fsockopen($ip, 80);

        if ( $fp )
        {
            foreach( $data as $row )
            {
                fputs($fp, $row);
            }

            while( !feof($fp) )
            {
                $answer .= fread($fp, 512);
            }

            fclose($fp);
        }

        return $answer;
} 

?>