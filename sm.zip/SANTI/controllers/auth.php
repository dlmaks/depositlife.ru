<?php
// 0- неправильный логин пароль, 1 - вы авторизованы, 2 - исчерпан лимит попыток

$login = addslashes(htmlspecialchars(strip_tags(trim($_POST['login']))));
$password = addslashes(htmlspecialchars(strip_tags(trim($_POST['password']))));
// время снятия блокировки. 3600 = час
$time = 3600;
// Количество попыток авторизоваться
$n = 3;
// время полной очистки файла 3600*24*4 = 4 дня
$expire_seconds = 3600*24*4;

$domen = str_replace('www.', '', $_SERVER['HTTP_HOST']);
$file_path = "datas/db/".$domen."__".$login.".ini";
$ip = $_SERVER['REMOTE_ADDR'];

// создаем файл
if( !file_exists($file_path) ){
	$fp = fopen($file_path, "w+");
	fclose($fp);
}

// парсим данные
$data = parse_ini_file($file_path);

if(isset($data[$ip]))
{
	$access_time = max($data[$ip]);

	if( $access_time+$time < time() ){
		// удаляем строки
		$content = file_get_contents($file_path);
		$content = preg_replace("~{$ip}\[\] = [0-9]+\n~", "", $content);
		file_put_contents($file_path, $content);
		$ipcount = 0;
	}
	else
	{
		$ipcount = count($data[$ip]);
	}
}
else
{
	$ipcount = 0;
}

if($ipcount < $n)
{
	if (($login == SANTI_NAME) && ($password == SANTI_PASSWORD))
	{
		$_SESSION['auth'] = 1;
		$_SESSION['last_page'] = 1;
		if(!SANTI_START) to_log(7);
		if(SANTI_START == "0")
		{
			include("lib/notifiersbar.php");
			check_notifiers();
		}

		die("1");
	}
	else
	{
		file_put_contents($file_path, $ip.'[] = '. time() . "\n", FILE_APPEND);
		die("0");
	}
}
else
{
	die("2");
}

?>