<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if(isset($_GET["res"])) $res=addslashes(htmlspecialchars(strip_tags(trim($_GET["res"])))); else die("0");

if($res=="SEN")
  {
    $xml=("http://www.securitylab.ru/_Services/Export/RSS/vulnerabilities");
  }
elseif($res=="SAN")
  {
    $xml=("http://santivi.com/category/blog-santi/feed");
  }

$xmlDoc = new DOMDocument();
$xmlDoc->load($xml);

$x=$xmlDoc->getElementsByTagName('item');
if( $x->length > 23 )
  $num = 23;
else
  $num = $x->length;

for ($i=0; $i<$num; $i++)
{
    $item_title=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('title')->item(0)->childNodes->item(0)->nodeValue));
    $item_link=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('link')->item(0)->childNodes->item(0)->nodeValue));
    $item_desc=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('description')->item(0)->childNodes->item(0)->nodeValue));
    $item_date=htmlspecialchars(strip_tags($x->item($i)->getElementsByTagName('pubDate')->item(0)->childNodes->item(0)->nodeValue));

    echo ("<h4><a href='" . $item_link . "'>" . $item_title . "</a></h4>");
    echo ("<h6>".Rfc2822ToTimestamp($item_date)."</h6>");
    echo ("");
    echo ("<p>".$item_desc . "</p><br>");
}

function Rfc2822ToTimestamp($date){
 $aMonth = array(
             "Jan"=>"1", "Feb"=>"2", "Mar"=>"3", "Apr"=>"4", "May"=>"5",
             "Jun"=>"6", "Jul"=>"7", "Aug"=>"8", "Sep"=>"9", "Oct"=>"10",
             "Nov"=>"11", "Dec"=>"12",
             "янв"=>"1", "фев"=>"2", "мар"=>"3", "апр"=>"4", "май"=>"5",
             "июн"=>"6", "июл"=>"7", "авг"=>"8", "сен"=>"9", "окт"=>"10",
             "ноя"=>"11", "дек"=>"12",
             );
    //26 Jul 2013 10:51:00 +0400
    if (strlen($date) <= 27){$date="Fri, ".$date;}
        
    list( , $day, $month, $year, $time) = explode(" ", $date);
    list($hour, $min, $sec) = explode(":", $time);
    $month = $aMonth[$month];
    return $year."-".$month."-".$day." ".$hour.":".$min.":".$sec;
}

?> 