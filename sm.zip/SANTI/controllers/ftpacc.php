<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if(isset($_POST['choose'])) $choose = addslashes(htmlspecialchars(strip_tags(trim($_POST['choose'])))); else die("0");
if(isset($_POST['dip'])) $dip = addslashes(htmlspecialchars(strip_tags(trim($_POST['dip'])))); else die("0");
if(isset($_POST['aip'])) $aip = addslashes(htmlspecialchars(strip_tags(trim($_POST['aip'])))); else die("0");
if(isset($_POST['deny_rewrite'])) $deny_rewrite = addslashes(htmlspecialchars(strip_tags(trim($_POST['deny_rewrite'])))); else die("0");

$result="";

if ($choose=="deny_all") 
{
  $result.="<Limit ALL>\r\n";
  $result.="Deny from all\r\n";
  $result.="</Limit>\r\n"; 
} 
elseif($choose=="deny_ip") 
{
   $result.="<Limit ALL>\r\n";
   $result.="Order deny,allow\r\n";
   $result.="Allow from all\r\n";
   $a_ip=explode(";", $dip); 
   for($i=0; $i<count($a_ip); $i++) 
   {
    $result.="Deny from ".$a_ip[$i]."\r\n";
   }
   $result.="</Limit>\r\n"; 
}
elseif($choose=="allow_ip") 
{
   $result.="<Limit ALL>\r\n";
   $d_ip=explode(";", $aip); 
   for($i=0; $i<count($d_ip); $i++)
   {
    $result.="Allow from ".$d_ip[$i]."\r\n";
   }
   $result.="Deny from all\r\n";
   $result.="</Limit>\r\n"; 
}
 
if($deny_rewrite=="rewrite")
{
  $result.="AllowOverwrite off\r\n"; 
}

die($result);

?>