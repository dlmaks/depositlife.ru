<?php

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

include("lib/notifier.php");

if(isset($_POST['dosf'])) $dosf = addslashes(htmlspecialchars(strip_tags(trim($_POST['dosf'])))); // 1 - сканинг всех файлов, 2 - подготовка образа САНТИ, 3 - selfdefense САНТИ, 4 - сканинг БД
elseif(isset($_GET['dosf'])) $dosf = addslashes(htmlspecialchars(strip_tags(trim($_GET['dosf']))));
else die(0);

if(isset($_POST['silent']))
	$silent = addslashes(htmlspecialchars(strip_tags(trim($_POST['silent'])))); // 1 - режим молчания, 0 - уведомления и бд
else
	$silent = 0;

$dirfrom = "";
$mask = 'error_log,';
$bads = array('.', '..');

switch ($dosf)
{
    case "1":
		$dirfrom = '../';
		$dbfile = "scfiles.sfa";
		$mask .= SANTI_STOPF;
		autopilots_add_time(1);
      break;
    case "2":
		$dirfrom='.';
		$dbfile = "sscfiles.sfa";
		$mask .= 'datas, config.php, autoconfig.php,install.php,';
      break;
    case "3":
        $dirfrom='.';
		$dbfile = "sscfiles.sfa";
		$mask .= 'datas, config.php, autoconfig.php,install.php,';
        break;
    default:
        die("2");
        break;
}

$far = '';
$out='';
$curdir='';
$ouf='';
$far1 = '';
$elapsed = '';
$error = false;
function my_error_handler($code, $msg, $file, $line)
{global $error; $error = true;}
set_error_handler('my_error_handler');

if (!function_exists('file_put_contents')) {
    function file_put_contents($filename, $data) {
        $f = fopen($filename, 'w');
        if (!$f) {
            return false;
        } else {
            $bytes = fwrite($f, $data);
            fclose($f);
            return $bytes;
        }
    }
}

scan_start();

function scan_start()
{
	global $dbfile, $far, $out, $dirfrom, $curdir, $ouf, $far1, $elapsed, $silent, $dosf, $buneed;
	$far=unserialize(file_get_contents('datas/scaninfo/'.$dbfile));

	foreach($far as $k=>$f) $far1[$k]=1;

	$curdir=realpath('.');
	chdir($dirfrom);
	$basdir=realpath('.');

	recurdir($basdir);

	$ouf='';
	foreach($far1 as $k=>$f) {
		$ouf.="$k<br>";
		unset($far[$k]);
	}
	if($ouf)
	{
		$out.="\nУдаленные файлы:<br>$ouf\n";
		if($silent != 1)
		{
			objects_add("-", 19, "удаление файлов: ".str_replace("<br>", " ", $ouf), 3, 0);
		}
	}

	if($out){
		if ($dosf == 3)
			$buneed = true;

		$out=str_replace("&nbsp;&nbsp;","",$out);

		$text = "Файловый автопилот зафиксировал изменения в файловой структуре:<br><br>".$out;
		if($silent != 1)
		{
			send_mail("Уведомление файлового автопилота", $text);
			send_sms("Событие от САНТИ ФС. Критичность: высокая!");
		}
	}

	chdir($curdir);
	file_put_contents('datas/scaninfo/'.$dbfile,serialize($far));
}

function is_contains($mask, $file)
{
	$masks = array_map('trim', explode(',', $mask));

	foreach($masks as $m) {
		if(empty($m)) continue;
		$m = preg_replace('/\//', '\/', $m);
		$m = preg_replace('/\./', '\.', $m);
		$m = preg_replace('/\*/', '.*', $m);
		if(preg_match("/^$m$/i", $file)) return true;
	}
	return false;
}

function recurdir($d){
	global $bads, $mask;

	$dh  = opendir($d);
	while (false !== ($filename = readdir($dh))) {
    	$aa[] = $filename;
	}

	foreach($aa as $f){
		if(in_array($f, $bads)) continue;
		if(is_contains($mask, $f)) continue;
		$d1=$d.'/'.$f;
		if(is_dir($d1)) {
			recurdir($d1);
		}
		else { // действие с файлом $d1
			chf($d1);
		}
	}
}

function mydate($nw){
	if (!$nw) { return "&nbsp;"; }
	if ($nw=="0000-00-00 00:00:00" || $nw=="0000-00-00") { return "---"; }

	if (substr_count($nw," ")==0) {
		$b = explode ("-", $nw);
		$dbdate = mktime(0,0,0,$b[1],$b[2],$b[0]);
		$nw = strftime("%d.%m.%Y",$dbdate);
	} else {
		$a = explode (" ",$nw);
		$b = explode ("-", $a[0]);
		$c = explode (":", $a[1]);

		$dbdate = mktime($c[0],$c[1],$c[2],$b[1],$b[2],$b[0]);
		$nw = strftime("%d.%m.%Y %H:%M",$dbdate);
	}
	if (!$nw) { return "---"; } else return $nw;
}

function chf($f){
	global $far,$far1,$out,$silent;;
	$now=time();
	$o='';
	$obd='';
	$mod=0;
	if(!isset($far[$f])) {
		$far[$f]['mtime']=filemtime($f);
		$far[$f]['size']=filesize($f);
		$far[$f]['crc']=crc32(file_get_contents($f));
		$far[$f]['timestamp']=$now;
		$o="<br>Новый файл - новое время: ".mydate(date('Y-m-d H:i:s', $far[$f]['mtime']))."<br><br>";
		if($silent != 1)
		{
			objects_add($f, 0, "новое время ".mydate(date('Y-m-d H:i:s', $far[$f]['mtime'])), 3, 0);
		}
	}
	else {
		unset($far1[$f]);
		if(($fsiz=filesize($f))!=$far[$f]['size'])
		{
			$mod=1;$o.="<br>Новый размер: ".filesize($f);$o.="<br>Старый размер: ".$far[$f]['size'];
			if($silent != 1)
			{
				objects_add($f, 1, "новый размер ".filesize($f)." | старый размер ".$far[$f]['size'], 3, 0);
			}
		}
		if(($ftim=filemtime($f))!=$far[$f]['mtime'])
		{
			$mod=1;$o.="<br>Новое время: ".mydate(date('Y-m-d H:i:s',$ftim));$o.="<br>Старое время: ".mydate(date('Y-m-d H:i:s',$far[$f]['mtime'])).";";
			if($silent != 1)
			{
				objects_add($f, 1, "новое время ".mydate(date('Y-m-d H:i:s',$ftim))."| старое время ".mydate(date('Y-m-d H:i:s',$far[$f]['mtime'])), 3, 0);
			}
		}
		if(($fcrc=crc32(file_get_contents($f)))!=$far[$f]['crc'])
		{
			$mod=1;$o.="<br>Изменилось содержимое файла. ";
			if($silent != 1)
			{
				objects_add($f, 1, "изменилось содержимое файла", 3, 0);
			}
		}
		if($mod==1)
		{
			$o.="<br>Права на файл: ".get_chmod($f)."<br><br>";
			if($silent != 1)
			{
				objects_add($f, 2, "права: ".get_chmod($f), 3, 0);
			}
		}
	}
	if($mod){
		$t['mtime']=     $far[$f]['mtime'];
		$t['size']=      $far[$f]['size'];
		$t['crc']=       $far[$f]['crc'];
		$t['timestamp']= $far[$f]['timestamp'];

		// храним 4 посл изменения
		if(@count($far[$f]['old'])>3){
			$ts='2019-01-01';
			foreach($far[$f]['old'] as $k=>$v){
				if(strtotime($k)<strtotime($ts))$ts=$k;
			}
			unset($far[$f]['old'][$ts]);
		}
		$far[$f]['old'][date('Y-m-d H:i:s',$now)]=$t;

		$far[$f]['mtime']=$ftim;
		$far[$f]['size']=$fsiz;
		$far[$f]['crc']=$fcrc;
		$far[$f]['timestamp']=$now;

	}

	if($o) $out.="\nФайл: $f\n$o\n";
}

function get_chmod($f){
	$perms = fileperms($f);

	if (($perms & 0xC000) == 0xC000) {
	    // Socket
	    $info = 's';
	} elseif (($perms & 0xA000) == 0xA000) {
	    // Symbolic Link
	    $info = 'l';
	} elseif (($perms & 0x8000) == 0x8000) {
	    // Regular
	    $info = '-';
	} elseif (($perms & 0x6000) == 0x6000) {
	    // Block special
	    $info = 'b';
	} elseif (($perms & 0x4000) == 0x4000) {
	    // Directory
	    $info = 'd';
	} elseif (($perms & 0x2000) == 0x2000) {
	    // Character special
	    $info = 'c';
	} elseif (($perms & 0x1000) == 0x1000) {
	    // FIFO pipe
	    $info = 'p';
	} else {
	    // Unknown
	    $info = 'u';
	}

	// Owner
	$info .= (($perms & 0x0100) ? 'r' : '-');
	$info .= (($perms & 0x0080) ? 'w' : '-');
	$info .= (($perms & 0x0040) ?
            (($perms & 0x0800) ? 's' : 'x' ) :
            (($perms & 0x0800) ? 'S' : '-'));

	// Group
	$info .= (($perms & 0x0020) ? 'r' : '-');
	$info .= (($perms & 0x0010) ? 'w' : '-');
	$info .= (($perms & 0x0008) ?
            (($perms & 0x0400) ? 's' : 'x' ) :
            (($perms & 0x0400) ? 'S' : '-'));

	// World
	$info .= (($perms & 0x0004) ? 'r' : '-');
	$info .= (($perms & 0x0002) ? 'w' : '-');
	$info .= (($perms & 0x0001) ?
            (($perms & 0x0200) ? 't' : 'x' ) :
            (($perms & 0x0200) ? 'T' : '-'));

	return $info;
}

?>
