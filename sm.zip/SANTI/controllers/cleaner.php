<?php

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if (isset($_POST['startcode'])) $startcode = trim($_POST['startcode']); else die("0");
if (isset($_POST['finishcode'])) $finishcode = trim($_POST['finishcode']); else die("0");
if (isset($_POST['extensions'])) $extensions = addslashes(htmlspecialchars(strip_tags(trim($_POST['extensions'])))); else die("0");
if (isset($_POST['dofs'])) $dofs = addslashes(htmlspecialchars(strip_tags(trim($_POST['dofs'])))); else die("0");
if (isset($_POST['docl'])) { if(addslashes(htmlspecialchars(strip_tags(trim($_POST['docl'])))) == 2) $docl = true; elseif(addslashes(htmlspecialchars(strip_tags(trim($_POST['docl'])))) == 1) $docl = false; } else die("0");

if((strlen($startcode) < 4) || (strlen($finishcode)<3))
    die("0");

chdir('../');
$dir = getcwd().'/';
$ext = array();
$results = array();
$ext = explode(",", str_replace(" ", "", $extensions));
$dofsb = false;
$skip_files = array("signatyri.ssdb"); //название файла - который следует проигнорировать при проверке

switch ($dofs) {
    case '1':
        break;
    case '2':
            $dofsb = true;
        break;
    case '3':
            $ext = null;
        break;    
    default:
        die("0");
        break;
}

dir_walk($dir, $ext, false, $dir, $dofsb);

function dir_walk($dir, $types = null, $recursive = false, $baseDir = '', $dofsb)
{
    global $results;
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh))!== false) 
        {
            if ($file === '.' || $file === '..') 
            {
                continue;
            }
            if (is_file($dir.$file)) 
            {
                if (is_array($types)) 
                {
                    if($dofsb)
                    {
                        if (!in_array(strtolower(pathinfo($dir.$file, PATHINFO_EXTENSION)), $types, true)) 
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (in_array(strtolower(pathinfo($dir.$file, PATHINFO_EXTENSION)), $types, true)) 
                        {
                            continue;
                        }
                    }                    
                }

                del_virus($baseDir, $file);
            }
            elseif($recursive && is_dir($dir.$file))
            {
                dir_walk($dir.$file.DIRECTORY_SEPARATOR, $types, $recursive, $baseDir.$file.DIRECTORY_SEPARATOR, $dofsb);
            }
        }
        closedir($dh);
    }
}

function del_virus($fdir, $ffile)
{
    $flag = false;
    $filename = $fdir.$ffile;
    global $results, $startcode, $finishcode, $docl, $skip_files;
    $status = "";
    $virus_text = "";
 
    $file=file($filename);
    foreach($file as $k=>$v)
    {
        $pos_start = stripos($v, $startcode);
        $pos_end = stripos($v, $finishcode);
    
        if(($pos_start !== false) && ($pos_end !== false))
        {
            $virus_text = substr($v, $pos_start, $pos_end);

            if (($virus_text != "") && (stristr($v, $virus_text)))
            {
                if (!$flag)
                {
                    $flag=true;
                    if (in_array($ffile, $skip_files))
                    {
                        $status = "пропущен";
                        $results[] = array('file' => str_replace("\\", "/", $fdir.$ffile), 'status' => $status);
                        $nfile[] = $v;
                        return;
                    }
                    elseif(!$docl)
                    {
                        $status = "заражен";
                        $results[] = array('file' => str_replace("\\", "/", $fdir.$ffile), 'status' => $status);
                    }
                }
            }
        }
        else
            $nfile[]=$v;
    }

    if(($docl) && ($virus_text!=""))
    {
        $file=fopen($filename,"w");
        fwrite($file,implode($nfile,""));
            fclose($file);
        $status = "вылечен";
        $results[] = array('file' => str_replace("\\", "/", $fdir.$ffile), 'status' => $status);
    }
}

if (!function_exists('json_encode')) {
    function json_encode($content) {
        require_once 'lib/JSON.php';
        $json = new Services_JSON;
        return $json->encode($content);
    }
}

echo json_encode($results);
?>