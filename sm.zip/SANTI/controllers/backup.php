<?php

if ((!isset($_SESSION['auth'])) && (!file_exists('install.php')))
{
    die("0");
}

if (isset($_POST['dobu'])) $dobu = addslashes(htmlspecialchars(strip_tags(trim($_POST['dobu'])))); else die("0"); //1 - бекапим, 2-восстанавливаем
if (isset($_POST['arhname'])) $archivename = addslashes(htmlspecialchars(strip_tags(trim($_POST['arhname'])))); else die("0"); //имя файла
if (isset($_POST['startpath'])) $path = addslashes(htmlspecialchars(strip_tags(trim(rtrim(preg_replace('/\\\+|\/+/', '/', $_POST['startpath']), '/'))))); else die("0"); //начальная папка бекапа/восстановления
if (isset($_POST['stoppath'])) $stoppath = addslashes(htmlspecialchars(strip_tags(trim($_POST['stoppath'])))); //пропуски
if (isset($_POST['rassh'])) $rassh = addslashes(htmlspecialchars(strip_tags(trim($_POST['rassh'])))); //расширения для пропусков
if (isset($_POST['maxsize'])) $maxsize = addslashes(htmlspecialchars(strip_tags(trim($_POST['maxsize'])))); //максимальный размер файлов в бекап
if (isset($_POST['bufile'])) $bufile = addslashes(htmlspecialchars(strip_tags(trim($_POST['bufile'])))); else die("0"); //файл для распаковки/упаковки

$path = str_replace("..", "", $path);
$this_script = $_SERVER["SCRIPT_FILENAME"];
$this_script_dir = dirname($this_script);

$cwd = getcwd();
$cwd = preg_replace('/\\\+|\/+/', '/', $cwd);

$wspl1 = chr(119).chr(105).chr(115).chr(112).chr(108);
$wspl2 = chr(119).chr(105).chr(36).chr(112).chr(108);

$wsfn1 = chr(119).chr(105).chr(115).chr(102).chr(110);
$wsfn2 = chr(119).chr(105).chr(36).chr(102).chr(110);

$hidden = array('.ftpquota', '.ftpaccess', '.htaccess');

if($stoppath == "")
    $exludethisdir=false; // - не эти каталоги TRUE/FALSE
else
    $exludethisdir=true; // - не эти каталоги TRUE/FALSE

$exludethisdirmode = $stoppath;

if($rassh == "")
    $onlythisext=false; // - только с расширением TRUE/FALSE
else
    $onlythisext=true;
$onlythisextmode = $rassh;

if($maxsize == "")
    $onlyfilesize=false; // - не более байт TRUE/FALSE
else
    $onlyfilesize=true;
$onlyfilesizemode = $maxsize;

$exludesubdirs=false; // - не обрабатывать подкаталоги

switch ($dobu)
{
    case "1":
        $site_root = SANTI_SERVERPATH;
        $path_result = compress(SANTI_SERVERPATH."/".SANTI_PATH.'/datas/backups/', $archivename);
        die($path_result);
      break;
    case "2":
        $site_root = SANTI_SERVERPATH."/".SANTI_PATH."/datas/unarchive/".$path;
        $path_result = decompress(SANTI_SERVERPATH."/".SANTI_PATH."/datas/unarchive/".$path, $bufile);
        die($path_result);
      break;
    case "3":
        $site_root = $path;
        $path_result = compress($path.'/datas/backups/', $archivename);
        die($path_result);
        break;
    default:
        die("0");
        break;
}

/*compress*/
function compress($path, $archivename)
{
	global $site_root;
	$zip = new ZipArchive();
	$zip->open($path.$archivename, ZipArchive::CREATE);
	$file_list = get_file_list($site_root);
	foreach($file_list as $file) {
		$zip->addFile($file, str_replace($site_root.'/', '', $file));
	}
	$zip->close();
	return "1";
}

/*compress*/

function get_file_list($dir)
{
	global $site_root, $exludethisdirmode, $hidden;
	$file_list = array();

	foreach($hidden as $hf)
		if(file_exists($dir.'/'.$hf))
			$file_list[] = $dir.'/'.$hf;

	foreach(glob($dir.'/*') as $file) {
		if(is_file($file)) {
			if(strpos($file, '.zip')) continue;
			if(is_contains($exludethisdirmode, str_replace($site_root.'/', '', $file))) continue;
			$file_list[] = $file;
		}
		elseif(is_dir($file)) {
			if(is_contains($exludethisdirmode, str_replace($site_root.'/', '', $file))) continue;
			$file_list = array_merge($file_list, get_file_list($file));
		}
	}
	return $file_list;
}

/*decompress*/
function decompress($path, $selarchive)
{
	if(!is_dir($path)) mkdir($path);
	$zip = new ZipArchive();
	$zip->open($selarchive);
	$zip->extractTo($path);
	$zip->close();
}
/*decompress*/

function is_contains($mask, $file)
{
	$mask = array_map('trim', explode(',', $mask));

	foreach($mask as $m) {
		if(empty($m)) continue;
		$m = preg_replace('/\//', '\/', $m);
		$m = preg_replace('/\./', '\.', $m);
		$m = preg_replace('/\*/', '.*', $m);
		if(preg_match("/^$m$/i", $file)) return true;
	}
	return false;
}

die("0");
?>