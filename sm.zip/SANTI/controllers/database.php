<?php

include_once('lib/flatfile.php');

// db files//
define('pilots', 'auto_pilots.txt');
define('objects', 'alert_objects.txt');
define('notifiers', 'notifiers.txt');
define('events', 'events.txt');
//! db files//

// pilots db //
define('AP_ID', 0);
define('AP_TYPE', 1);
define('AP_NAME', 2);
define('AP_DATE', 3);
//! pilots db //

// objects db //
define('OBJ_ID', 0);
define('OBJ_OBJ', 1);
define('OBJ_TYPE', 2);
define('OBJ_INFO', 3);
define('OBJ_CRITICALITY', 4);
define('OBJ_STATUS', 5);
define('OBJ_TIME', 6);
//! objects db //

// notifiers db //
define('N_ID', 0);
define('N_LINK', 1);
define('N_TITLE', 2);
define('N_DATE', 3);
define('N_STATUS', 4);
//! notifiers db //

// events db //
define('E_ID', 0);
define('E_DATE', 1);
define('E_TIME', 2);
define('E_EID', 3);
//! events db //


$db = new Flatfile();
$db->datadir = ABSPATH.'/datas/db/';

//обработка AJAX запросов
if(isset($_POST['nd']))
	notifiers_delete(addslashes(htmlspecialchars(strip_tags(trim($_POST['nd'])))));

if(isset($_POST['oi']))
	objects_ignore(addslashes(htmlspecialchars(strip_tags(trim($_POST['oi'])))));

if(isset($_POST['oh']))
	objects_healed(addslashes(htmlspecialchars(strip_tags(trim($_POST['oh'])))));

if(isset($_POST['on']))
	objects_null(addslashes(htmlspecialchars(strip_tags(trim($_POST['on'])))));

if(isset($_POST['uf']))
	objects_add(htmlspecialchars(strip_tags($_POST['uf'])), 22, "добавление файла от утилиты", 1, 1);

if(isset($_POST['ca']))
	$db->deleteAll(objects);

?>