<?php

//if (!isset($_SESSION)) session_start();

if (!isset($_SESSION['auth'])) 
{
    die("0");
}

if (isset($_POST["file_id"])) $file_id = addslashes(htmlspecialchars(strip_tags(trim($_POST["file_id"])))); else die("0");
if (isset($_POST["contents"])) $content = $_POST["contents"]; else die("0");
if (isset($_POST["fedo"])) $fedo = addslashes(htmlspecialchars(strip_tags(trim($_POST["fedo"])))); else die("0");
if (isset($_POST["encoding"])) $encoding = addslashes(htmlspecialchars(strip_tags(trim($_POST["encoding"])))); else die("0");

$file_path = get_objects_path($file_id);

switch ($fedo) {
	case 2:
			save_file($file_path, $content, $encoding);	
		break;
}

function save_file($file_path, $content, $encoding)
{
	switch ($encoding) {
        case 0:
                $fencode = "utf-8";
            break;
        case 1:
                $fencode = "windows-1251";
            break;
        case 2:
                $fencode = "koi-8";
            break;
        case 3:
                $fencode = "windows-1251";
            break;
    }
    
    if($encoding != 0)
    	$content = iconv("utf-8", $fencode, $content);

	$w = file_put_contents($file_path, $content) or die("0");
	die("1");
}

die("0");

?>