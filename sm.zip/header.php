﻿	<link rel="stylesheet" href="assets/css/main.css" />
	<header id="header">
				<h1><font color=green>DEPOSIT LIFE</font></h1>
				<nav>
					<ul>
						<li><a href="index.html"><font color=green>DEPOSIT LIFE</font></a></li>
						<li><a href="auth/login.php">Войти|Регистрация</a></li>
						<li><a href="contact.php">Обратная связь</a></li>
						<li><a href="comment.php">Отзывы</a></li>
						<li><a href="by.php">О Нас</a></li>
					</ul>
					
					
				</nav>
			</header>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1647152541986410'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1647152541986410&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->