<?php
isset($_POST["s_s"]);
$message2=$_POST["message"];
$adress=$_POST["adress"];
$client=$_POST["client"];
$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 
$message = "adress clienta ot obratniy svyazi: $adress | Client: $client | message: $message2";
$to="texdlifes@inbox.ru";
$subject="client_support";
mail ( $to, $subject, $message,"From: support@depositlife.ru \r\n", $headers );
?>

	<center>
<div style="border: 0.5px solid blue;
float: top;	padding: 5px; margin: 100px;
">
<center>
<font color="55cc55" FACE="times new roman" size=3>Вы не останетесь без Внимание!
<br></font></center></div>
<font color="777777" size=2 FACE="arial">Сообшение отправлено.<br></font></center>
<center><a href="/index.html">Назад</a></center>
<link rel="stylesheet" href="/assets/css/main.css" />
<head><title>Почта </title></head>


<?php include "foter.php";?>
